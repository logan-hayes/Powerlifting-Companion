package com.example.fishfreshnewengland

/**
 * @author Ashton Gabbeitt
 */

import com.example.fishfreshnewengland.external.AuthRepositoryImpl
import com.example.fishfreshnewengland.external.DatabaseRepositoryImpl
import com.example.fishfreshnewengland.external.entities.UserSetup
import io.github.jan.supabase.SupabaseClient
import io.github.jan.supabase.auth.Auth
import io.github.jan.supabase.auth.auth
import io.github.jan.supabase.createSupabaseClient
import io.github.jan.supabase.postgrest.Postgrest
import io.github.jan.supabase.postgrest.postgrest
import io.github.jan.supabase.storage.Storage
import kotlinx.coroutines.test.runTest
import kotlinx.datetime.LocalDate
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import kotlin.uuid.ExperimentalUuidApi
import kotlin.uuid.Uuid

class SupabaseTests {

    private lateinit var supabaseClient: SupabaseClient
    private lateinit var authRepo: AuthRepositoryImpl
    private lateinit var databaseRepo: DatabaseRepositoryImpl

    @Before
    fun setup() {
        supabaseClient = createSupabaseClient(
            supabaseUrl = BuildConfig.SUPABASE_URL,
            supabaseKey = BuildConfig.SUPABASE_KEY
        ) {
            install(Auth)
            install(Postgrest)
            install(Storage)
        }
        authRepo = AuthRepositoryImpl(supabaseClient.auth)
        databaseRepo = DatabaseRepositoryImpl(supabaseClient.postgrest)
    }

    @Test
    fun test_real_supabase_login() = runTest {

        val email = "ashtongabbeitt@proton.me"
        val pw = "LionsEatMeat90!"

        val result = authRepo.signIn(email, pw)

        assertTrue("Login should succeed with real credentials", result.success)
    }

    @OptIn(ExperimentalUuidApi::class)
    @Test
    fun submitUserSetup() = runTest {

        val email = "ashtongabbeitt@proton.me"
        val pw = "LionsEatMeat90!"

        val result = authRepo.signIn(email, pw)

        val userID = authRepo.getCurrentUserId()
        println("USERID: $userID")

        assertNotNull("User ID should not be null", userID)

        if(userID != null) {
            val parsedUuid = Uuid.parse(userID)
            val userSetup = UserSetup(
                userID = parsedUuid,
                username = "testuser",
                avatarURL = null,
                dateOfBirth = ("1991-07-06"),
            )
            val result = databaseRepo.submitUserSetup(userSetup)
            if(result.isFailure){
                println(result.exceptionOrNull())
            }
            assertTrue("User setup should succeed", result.isSuccess)
        }
    }

    @Test
    fun usernameValidator() = runTest {
        val username = "test123"
        val result = databaseRepo.usernameValidator(username)

        if(result.isFailure){
            println(result.exceptionOrNull())
        }

        assertTrue("Username should be available", result.isSuccess)
    }

    @Test
    fun usernameValidatorFail() = runTest {

        val username = "fishmcgee"
        val result = databaseRepo.usernameValidator(username)

        if(result.isFailure){
            println(result.exceptionOrNull())
        }
        assertTrue("Username should not be available", result.isFailure)
    }

}