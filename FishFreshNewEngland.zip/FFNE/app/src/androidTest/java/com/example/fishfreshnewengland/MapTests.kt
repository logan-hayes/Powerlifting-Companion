package com.example.fishfreshnewengland
/**
 * @author Ashton Gabbeitt
 */

import com.example.fishfreshnewengland.external.NOAARepository
import com.example.fishfreshnewengland.internal.entities.AccessPoints
import com.example.fishfreshnewengland.map.entities.LocationClient
import com.example.fishfreshnewengland.map.entities.LocationData
import com.example.fishfreshnewengland.internal.repositories.AccessPointRepository
import com.example.fishfreshnewengland.internal.repositories.CountyRepository
import com.example.fishfreshnewengland.internal.repositories.FishRepository
import com.example.fishfreshnewengland.internal.repositories.FishWaterBodiesRepository
import com.example.fishfreshnewengland.internal.repositories.StateRepository
import com.example.fishfreshnewengland.internal.repositories.TownRepository
import com.example.fishfreshnewengland.internal.repositories.WaterBodyRepository
import com.example.fishfreshnewengland.models.MapViewModel
import io.mockk.coEvery
import io.mockk.mockk
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.advanceUntilIdle
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Before
import org.junit.Test
import kotlinx.coroutines.test.runTest
import org.junit.Rule

class MapTests {

    @get:Rule
    val mainDispatcherRule = MainDispatcherRule()
    private val mockLocationClient = mockk<LocationClient>()
    private val mockRepository = mockk<AccessPointRepository>()
    private val mockNOAARepository = mockk<NOAARepository>()

    private val mockFishWaterBodiesRepository = mockk<FishWaterBodiesRepository>()
    private val mockFishRepository = mockk<FishRepository>()
    private val mockWaterBodyRepository = mockk<WaterBodyRepository>()
    private val mockTownRepository = mockk<TownRepository>()
    private val mockCountyRepository = mockk<CountyRepository>()
    private val mockStateRepository = mockk<StateRepository>()


    private lateinit var viewModel: MapViewModel


    @Before
    fun setup() {
        val testDispatcher = mainDispatcherRule.testDispatcher
        viewModel = MapViewModel(mockLocationClient, mockRepository, mockNOAARepository, mockFishWaterBodiesRepository, mockFishRepository, mockWaterBodyRepository, mockTownRepository, mockCountyRepository, mockStateRepository, testDispatcher, testDispatcher)
    }

    @OptIn(ExperimentalCoroutinesApi::class)
    @Test
    fun testGetUserLocation_updatesUiStateWithLocationData() = runTest {
        val fakeLocation = LocationData(43.61754, -72.967287)
        coEvery { mockLocationClient.getUserLocation() } returns fakeLocation

        viewModel.userLocation()

        advanceUntilIdle()

        val currentState = viewModel.uiState.value
        assertNotNull(currentState.userLocation)
        assertEquals(43.61754, currentState.userLocation?.latitude)
        assertEquals(-72.967287, currentState.userLocation?.longitude)
    }

    @OptIn(ExperimentalCoroutinesApi::class)
    @Test
    fun testGetUserLocation_getAccessPoints() = runTest {
        val rutlandVT = LocationData(43.6101, -72.9726)
        coEvery { mockLocationClient.getUserLocation() } returns rutlandVT

        val mockPoints = listOf(
            // Lake Bomoseen is ~12 miles from Rutland (Should STAY)
            AccessPoints(1, "Lake Bomoseen", 3029, 43.677, -73.20033),
            // Lake Lillinonah is in CT, ~150 miles away (Should be FILTERED)
            AccessPoints(2, "Lake Lillinonah", 2079, 41.45976217, -73.32494797)
        )
        coEvery { mockRepository.fetchAllAccessPoints() } returns mockPoints

        viewModel.userLocation()
        advanceUntilIdle()

        viewModel.getCloseAccesses()
        advanceUntilIdle()

        // 3. Assert

        val state = viewModel.uiState.value
        val markers = state.accessLocationMarkers

        assertNotNull(markers)
//        assertEquals(1, markers?.size) // Only 1 should remain
//        assertEquals("Lake Bomoseen", markers?.first()?.name)



    }

}
