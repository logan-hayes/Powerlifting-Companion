package com.example.fishfreshnewengland;

/**
 * @author Ashton Gabbeitt
 */

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import android.content.Context;

import androidx.room.Room;
import androidx.test.core.app.ApplicationProvider;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import com.example.fishfreshnewengland.internal.entities.Towns;
import com.example.fishfreshnewengland.internal.AppDatabase;
import com.example.fishfreshnewengland.internal.entities.Counties;
import com.example.fishfreshnewengland.internal.Dao.AccessPointDao;
import com.example.fishfreshnewengland.internal.Dao.CountyDao;
import com.example.fishfreshnewengland.internal.Dao.StateDao;
import com.example.fishfreshnewengland.internal.entities.States;
import com.example.fishfreshnewengland.internal.Dao.TownDao;
import com.example.fishfreshnewengland.internal.entities.Fish;
import com.example.fishfreshnewengland.internal.Dao.FishDao;
import com.example.fishfreshnewengland.internal.Dao.WaterBodyDao;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.io.IOException;
import java.util.List;

@RunWith(AndroidJUnit4.class)
public class ClientDBTests {
    private StateDao stateDao;
    private CountyDao countyDao;
    private TownDao townDao;
    private FishDao fishDao;
    private WaterBodyDao waterBodyDao;
    private AccessPointDao accessPointDao;
    private AppDatabase db;

    @Before
    public void setup() {
        Context context = ApplicationProvider.getApplicationContext();

        context.deleteDatabase("test_db");

        db = Room.databaseBuilder(context, AppDatabase.class, "test_db")
                .createFromAsset("database/FFNE_Client.db")
                .build();
        stateDao = db.stateDao();
        countyDao = db.countyDao();
        townDao = db.townDao();
        waterBodyDao = db.waterBodyDao();
        accessPointDao = db.accessPointDao();
        fishDao = db.fishDao();
    }

    @After
    public void closeDb() throws IOException {
        try {
            db.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    @Test
    public void testGetAllStates() {
        List<States> statesList = stateDao.getAll();
        assertNotNull(statesList);
        assertFalse(statesList.isEmpty());
    }

    @Test
    public void testGetAllCounties() {
        List<Counties> countyList = countyDao.getAll();
        assertNotNull(countyList);
        assertFalse(countyList.isEmpty());
    }


    @Test
    public void testGetAllCountiesByState() {
        List<Counties> countyList = countyDao.getAllByState(1);
        assertNotNull(countyList);
        assertFalse(countyList.isEmpty());
    }

    @Test
    public void testGetAllTowns() {
        List<Towns> townsList = townDao.getAll();
        assertNotNull(townsList);
        assertFalse(townsList.isEmpty());
    }

    @Test
    public void testGetAllFish() {
        List<Fish> fishList = fishDao.getAll();
        assertNotNull(fishList);
        assertFalse(fishList.isEmpty());
    }

}
