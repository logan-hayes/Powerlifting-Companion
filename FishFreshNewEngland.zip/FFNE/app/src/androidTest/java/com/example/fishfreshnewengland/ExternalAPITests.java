package com.example.fishfreshnewengland;


import androidx.test.ext.junit.runners.AndroidJUnit4;

import com.example.fishfreshnewengland.external.NOAARepository;
import com.example.fishfreshnewengland.external.NOAAService;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

@RunWith(AndroidJUnit4.class)
public class ExternalAPITests {

    @Before
    public void setup(){





    }

    @Test
    public void testGetHourlyLink(){

    }

}
