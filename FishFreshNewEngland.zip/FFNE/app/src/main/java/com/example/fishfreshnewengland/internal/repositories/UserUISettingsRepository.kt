package com.example.fishfreshnewengland.internal.repositories

import com.example.fishfreshnewengland.internal.entities.UserUISettings
import com.example.fishfreshnewengland.internal.Dao.UserUISettingsDao
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class UserUISettingsRepository @Inject constructor(
    private val userUISettingsDao : UserUISettingsDao,
) {

    // LOCAL DATABASE
    suspend fun getSettings(): UserUISettings? {
        return withContext(Dispatchers.IO) {
            userUISettingsDao.getSettings()
        }
    }

    suspend fun saveSettings(settings: UserUISettings) {
        withContext(Dispatchers.IO) {
            userUISettingsDao.insert(settings)
        }
    }

    suspend fun updateSettings(settings: UserUISettings) {
        withContext(Dispatchers.IO) {
            userUISettingsDao.update(settings)
        }
    }

}
