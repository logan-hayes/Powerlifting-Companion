package com.example.fishfreshnewengland.ui.theme

/**
 * @author Ashton Gabbeitt
 */
import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme = darkColorScheme(
    primary = baseBlueDark, // These variables come from your Color.kt
    onPrimary = black,          // Text color on top of primary
    secondary = baseBlueLight,
    tertiary = baseBlueDark,
    background = white,         // Change from baseBlue to white
    surface = baseBlueDark,            // Standard surface
    onBackground = black,       // Standard text color
    onSurface = black,
    error = error                   // error Red
)

private val LightColorScheme = lightColorScheme(
    primary = baseBlue,         // Your branding color
    onPrimary = white,          // Text color on top of primary
    secondary = baseBlueLight,
    tertiary = baseBlueDark,
    background = white,         // Change from baseBlue to white
    surface = baseBlueLight,            // Standard surface
    onBackground = black,       // Standard text color
    onSurface = black,          // Standard text color
    error = error               // error Red
)

@Composable
fun FishFreshTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    // Dynamic color is a feature on Android 12+ that pulls colors from wallpaper
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography, // Uses the variable from Type.kt
        content = content
    )
}