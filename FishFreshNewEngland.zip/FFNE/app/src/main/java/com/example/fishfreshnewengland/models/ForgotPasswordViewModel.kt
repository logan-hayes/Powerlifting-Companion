package com.example.fishfreshnewengland.models

/**
 * @author Ashton Gabbeitt
 */
import androidx.compose.runtime.Immutable
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.fishfreshnewengland.external.AuthRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject
import kotlin.time.ExperimentalTime


@Immutable
data class ForgotPasswordUIState(
    val email: String = "",
    val isLoading: Boolean = false,
    val formReady: Boolean = false,
    val requestSuccess: Boolean = false,
    val errorMessage: String? = null,
    val needConfirm: Boolean = false
)

@HiltViewModel
class ForgotPasswordViewModel @Inject constructor(
    private val authenticationRepository: AuthRepository,
) : ViewModel() {
    private val _uiState = MutableStateFlow(ForgotPasswordUIState())
    val uiState = _uiState.asStateFlow()

    fun onEmailChanged(emailChange: String) {
        _uiState.update {
            it.copy(
                email = emailChange,
                formReady = emailChange.isNotBlank()
            )
        }
    }
    @OptIn(ExperimentalTime::class)
    fun requestPasswordResetEmail() {
        viewModelScope.launch {

            val userEmail = _uiState.value.email
            _uiState.update { it.copy(isLoading = true, errorMessage = null) }

            try {

                    val requestResponse =
                        authenticationRepository.sendResetPasswordEmail(userEmail)

                    if (requestResponse.emailSent) {
                        _uiState.update {
                            it.copy(
                                isLoading = false,
                                requestSuccess = true,
                                needConfirm = requestResponse.confirmedUser,
                                errorMessage = null
                            )
                        }
                    }
                else {
                        _uiState.update {
                            it.copy(
                                isLoading = false,
                                requestSuccess = false,
                                errorMessage = requestResponse.errorMessage,
                                needConfirm = false,
                            )
                        }
                    }


            } catch (e: Exception) {
                _uiState.update {
                    it.copy(isLoading = false, errorMessage = e.message, requestSuccess = false, needConfirm = false)
                }

            }

        }

    }
}