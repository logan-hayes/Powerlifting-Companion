package com.example.fishfreshnewengland.models

/**
 * @author Ashton Gabbeitt
 */
import androidx.compose.runtime.Immutable
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.fishfreshnewengland.internal.entities.Counties
import com.example.fishfreshnewengland.internal.repositories.CountyRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

@Immutable
data class CountyUIState(
    val countyList : List<Counties> = emptyList(),
    val isLoading: Boolean = false,
    val errorMessage: String? = null
)
/**
 * Connection between County Repository and County Select Layout
 */
@HiltViewModel
class CountySelectViewModel @Inject constructor(private val repository: CountyRepository, savedStateHandle: SavedStateHandle) : ViewModel() {

    private val stateId: Int = checkNotNull(savedStateHandle["stateId"])
    private val _uiState = MutableStateFlow(CountyUIState())
    val uiState: StateFlow<CountyUIState> = _uiState.asStateFlow()

    init {
        loadCounties(stateId)
    }

    fun loadCounties(stateID: Int) {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, errorMessage = null) }
            try {
                val result = repository.fetchCountiesByState(stateID)
                _uiState.update { it.copy(countyList = result, isLoading = false )}
            } catch (e: Exception) {
                _uiState.update { it.copy(isLoading = false, errorMessage ="Failed to load counties: ${e.localizedMessage}")}
            }
        }
    }

}