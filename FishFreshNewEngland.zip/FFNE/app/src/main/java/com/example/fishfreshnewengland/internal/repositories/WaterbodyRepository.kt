package com.example.fishfreshnewengland.internal.repositories

import com.example.fishfreshnewengland.internal.entities.WaterBodies
import com.example.fishfreshnewengland.internal.Dao.WaterBodyDao
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import javax.inject.Inject

class WaterBodyRepository @Inject constructor(
    private val waterBodyDao : WaterBodyDao
) {



    suspend fun fetchWaterBodiesByTown(townID: Int): List<WaterBodies> {
        return withContext(Dispatchers.IO) {
            waterBodyDao.getAllByTown(townID)
        }
    }

    suspend fun fetchAllWaterBodies() : List<WaterBodies> {
        return withContext(Dispatchers.IO) {
            waterBodyDao.getAll()
        }
    }

    suspend fun fetchWaterBodyById(id: Int) : WaterBodies? {
        return withContext(Dispatchers.IO) {
            waterBodyDao.getById(id)
        }

    }
}