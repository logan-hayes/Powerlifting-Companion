package com.example.fishfreshnewengland.navigation

/**
 * @author Ashton Gabbeitt
 */
import androidx.activity.ComponentActivity
import androidx.activity.compose.LocalActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.fishfreshnewengland.models.MainLayoutViewModel
import com.example.fishfreshnewengland.ui.theme.FishFreshTheme


/**
 * App navigation controller function.
 * Uses a NavHost to navigate between screens.
 * Route objects are defined in Routes.kt
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppNavigation(
    initialLink: String? = null
) {


    val navController = rememberNavController()
    val activity = LocalActivity.current as ComponentActivity
    val mainViewModel: MainLayoutViewModel = hiltViewModel(activity)
    val uiState by mainViewModel.uiState.collectAsStateWithLifecycle()

    FishFreshTheme {
        Box(modifier = Modifier.fillMaxSize()) {

            NavHost(
                navController,
                startDestination = RootRoute
            ) {
                composable<RootRoute> {
                    LaunchedEffect(uiState.isLoading, uiState.signedIn) {
                        if (!uiState.isLoading) {
                            val destination = if (uiState.signedIn) MainGraph else AuthGraph
                            navController.navigate(destination) {
                                popUpTo<RootRoute> { inclusive = true }
                            }
                        }
                    }
                    LoadingScreen()
                }
                authGraph(navController)
                mainGraph(navController)
            }
            if (uiState.isLoading) {
                LoadingScreen()
            }

            LaunchedEffect(initialLink) {
                initialLink?.let { mainViewModel.handleDeepLink(it) }
            }

            LaunchedEffect(uiState.resetPWTriggered) {
                if (uiState.resetPWTriggered) {
                    navController.navigate(ResetPasswordRoute)
                }
            }


            LaunchedEffect(uiState.emailConfirming) {
                if (uiState.emailConfirming) {
                    navController.navigate(ConfirmEmailRoute)
                    mainViewModel.resetEmailConfirming()
                }
            }

        }

    }
}


fun startApp(activity: ComponentActivity, initialLink: String?) {
    activity.setContent {
        AppNavigation(initialLink = initialLink)
    }
}

@Composable
fun LoadingScreen(){
    Box(
        modifier = Modifier
            .fillMaxSize()
    ){
        CircularProgressIndicator(modifier = Modifier.align(Alignment.Center))
    }
}




