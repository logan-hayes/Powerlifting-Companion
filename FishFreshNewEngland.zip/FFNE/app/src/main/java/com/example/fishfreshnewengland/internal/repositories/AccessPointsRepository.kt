package com.example.fishfreshnewengland.internal.repositories

import com.example.fishfreshnewengland.internal.entities.AccessPoints
import com.example.fishfreshnewengland.internal.Dao.AccessPointDao
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import javax.inject.Inject

class AccessPointRepository @Inject constructor(
    private val accessPointDao : AccessPointDao
) {



    suspend fun fetchAccessPointsByWaterBody(waterbodyID: Int): List<AccessPoints> {
        return withContext(Dispatchers.IO) {
            accessPointDao.getAllByWaterBody(waterbodyID)
        }
    }

    suspend fun fetchAllAccessPoints() : List<AccessPoints> {
        return withContext(Dispatchers.IO) {
            accessPointDao.getAllAccessPoints()
        }
    }
}