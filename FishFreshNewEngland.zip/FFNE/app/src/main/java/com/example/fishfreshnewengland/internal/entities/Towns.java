package com.example.fishfreshnewengland.internal.entities;
import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.PrimaryKey;

@Entity(
        tableName = "towns",
        foreignKeys = @ForeignKey(
                entity = Counties.class,
                parentColumns = "id",
                childColumns = "countyID",
                onDelete = ForeignKey.CASCADE
        )
)
public class Towns {

    @PrimaryKey(autoGenerate = true)
    @NonNull
    public Integer id;

    @NonNull
    public String name;

    @NonNull
    public Integer countyID;

    public Towns(@NonNull Integer id, @NonNull String name,  @NonNull Integer countyID) {
        this.id = id;
        this.name = name;
        this.countyID = countyID;
    }
}