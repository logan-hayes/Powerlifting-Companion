package com.example.fishfreshnewengland.models

/**
 * @author Ashton Gabbeitt
 */
import androidx.compose.runtime.Immutable
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.fishfreshnewengland.internal.entities.Fish
import com.example.fishfreshnewengland.internal.repositories.FishRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject


/**
 * Data class for fish list data retrieval
 * feeds state to fish list view model
 * @param fishExternalList: List of fish
 * @param isLoading: Boolean indicating if data is loading
 * @param errorMessage: String containing error message
 */
@Immutable
data class FishUIState(
    val fishList: List<Fish> = emptyList(),
    val isLoading: Boolean = false,
    val errorMessage: String? = null
)


/**
 * ViewModel for fish list data retrieval
 */
@HiltViewModel
class FishSelectViewModel @Inject constructor(private val repository: FishRepository) : ViewModel() {

    private val _uiState = MutableStateFlow(FishUIState())
    val uiState: StateFlow<FishUIState> = _uiState.asStateFlow()

    init {
        fetchFishData()
    }
    fun fetchFishData() {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, errorMessage = null) }
            try {
                    val result = repository.fetchAllFish()
                    _uiState.update { it.copy(fishList = result, isLoading = false) }


            } catch (e: Exception) {
                _uiState.update { it.copy(isLoading = false, errorMessage = "Could not load fish data. ${e.message}") }
            }

        }
    }
}