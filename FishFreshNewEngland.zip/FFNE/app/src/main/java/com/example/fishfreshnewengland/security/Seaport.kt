package com.example.fishfreshnewengland.security

// Imports go to this list //

// End Imports List //
class Seaport {

}

// All Below will be implemented in the Gradle Build //
// This list is to keep track of whats been added //

// AndroidX Security Crypto
// implementation "androidx.security:security-crypto:1.1.0-alpha06" //

// Google Tink //
// A multi-language, high-level cryptography library from Google //
// implementation "com.google.crypto.tink:tink-android:1.13.0" //

// Authentication & Identity //
// App uses login, tokens, or OAuth //

// AppAuth for Android //
// Industry-standard OAuth2 + PKCE library //
// implementation "net.openid:appauth:0.11.1" //

// Network Security //
// Protecting API calls, TLS, and certificate pinning. //
// OkHttp (with Certificate Pinning) //
// OkHttp is the de facto HTTP client for Android. //
// implementation "com.squareup.okhttp3:okhttp:4.12.0" //

// Dependency & Supply Chain Security //
// Keeping your libraries safe. //
// OWASP Dependency-Check (Gradle Plugin) //
// Scans your dependencies for known vulnerabilities. //
// plugins { id "org.owasp.dependencycheck" version "9.0.9" } //

// Device Integrity / Root Detection //
// Useful if your app handles sensitive data or needs tamper detection. //
// Detects root, tampering, debuggers, emulators. //
// implementation "com.aheaditec.talsec.security:TalsecSecurity-Android:latest.release" //

// End Implementation List //