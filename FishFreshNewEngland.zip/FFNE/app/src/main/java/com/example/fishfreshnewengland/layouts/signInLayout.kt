package com.example.fishfreshnewengland.layouts

/**
 * @author Ashton Gabbeitt
 */
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.SnackbarResult
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.fishfreshnewengland.components.EmailField
import com.example.fishfreshnewengland.components.PasswordField
import com.example.fishfreshnewengland.models.SignInUIState


/**
 * Sign In Layout
 * @param uiState: SignInUIState containing sign in data
 * @param onEmailChange: Function to update email
 * @param onPasswordChange: Function to update password
 * @param onSignInClick: Function to initiate sign in
 * @param onNavigateToSignUp: Function to navigate to sign up
 * @param onNavigateToForgotPW: Function to navigate to forgot password
 * @param onNavigateToMain: Function to navigate to main
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SignInLayoutContent(
    uiState: SignInUIState,
    onEmailChange: (String) -> Unit,
    onPasswordChange: (String) -> Unit,
    onSignInClick: () -> Unit,
    onNavigateToSignUp: () -> Unit,
    onNavigateToForgotPW: () -> Unit,
    onNavigateToMain: () -> Unit,
    snackbarDismissed: () -> Unit,
    clearNeedConfirm : () -> Unit,
    clearNewUser : () -> Unit
) {

    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(uiState.loginSuccess) {
        if (uiState.loginSuccess) {
            onNavigateToMain()
        }
    }

    LaunchedEffect(uiState.newSignUp) {
        if(uiState.newSignUp){
            val snackbarAction = snackbarHostState.showSnackbar(
                message = "Check your email to confirm your account. Check your inbox!", withDismissAction = true
            )

            if(snackbarAction == SnackbarResult.Dismissed){
                snackbarDismissed()
                clearNewUser()
            }
        }
    }

    LaunchedEffect(uiState.needConfirm, uiState.errorMessage) {
        if (uiState.needConfirm) {
            val action = snackbarHostState.showSnackbar(
                message = uiState.errorMessage ?: "Need to confirm email before sign in. Check your inbox!",
                withDismissAction = true
            )

            if (action == SnackbarResult.Dismissed) {
                snackbarDismissed()
                clearNeedConfirm()
            }
        }

    }



    Scaffold(snackbarHost = {
        SnackbarHost(snackbarHostState)
    }, topBar = {
        CenterAlignedTopAppBar(
            title = { Text("Fish Fresh New England") },
            colors = TopAppBarDefaults.topAppBarColors(
                containerColor = MaterialTheme.colorScheme.primary,
                titleContentColor = MaterialTheme.colorScheme.onPrimary,
                navigationIconContentColor = MaterialTheme.colorScheme.onPrimary
            ),

            )
    }, content = { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                "Sign In",
                textAlign = TextAlign.Center,
                style = MaterialTheme.typography.headlineLarge,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.padding(top = 30.dp, bottom = 16.dp)
            )
            SignInForm(
                email = uiState.email,
                password = uiState.password,
                onEmailChanged = { onEmailChange(it) },
                onPasswordChanged = { onPasswordChange(it) },
                enabled = !uiState.isLoading
            )
            Button(
                onClick = { onSignInClick() },
                enabled = uiState.formReady,
                modifier = Modifier.padding(top = 16.dp)
            ) {
                Text(if (uiState.isLoading) "Signing in..." else "Sign In")
            }
            if (uiState.errorMessage != null) {
                Text(uiState.errorMessage, color = MaterialTheme.colorScheme.error)
            }




            Text(
                modifier = Modifier
                    .padding(top = 16.dp)
                    .clickable(onClick = {
                        onNavigateToForgotPW()
                    }), text = "Forgot Password?"
            )
            Text(
                modifier = Modifier
                    .padding(top = 16.dp)
                    .clickable(onClick = {
                        onNavigateToSignUp()
                    }), text = "Sign Up!"
            )


        }
    }

    )

}

@Composable
fun SignInForm(
    email: String,
    password: String,
    onEmailChanged: (String) -> Unit,
    onPasswordChanged: (String) -> Unit,
    enabled: Boolean = true
) {
    Column(
        modifier = Modifier.padding(horizontal = 16.dp),
    ) {
        EmailField(
            email = email, onEmailChanged = onEmailChanged, enabled = enabled
        )
        PasswordField(
            value = password, onValueChanged = onPasswordChanged, enabled = enabled
        )
    }
}



