package com.example.fishfreshnewengland.entities;
/**
 * @author Ashton Gabbeitt
 */
import java.util.Date;

public class StandardUser extends User {

    public StandardUser(String userID) {
        super(userID);
    }
}
