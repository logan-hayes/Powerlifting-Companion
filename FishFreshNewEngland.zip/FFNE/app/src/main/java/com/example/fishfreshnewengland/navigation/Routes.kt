package com.example.fishfreshnewengland.navigation

/**
 * @author Ashton Gabbeitt
 */
import kotlinx.serialization.Serializable


/***
 * Sealed interface to define app route points for navigation
 */
sealed interface AppRoute

@Serializable
object RootRoute : AppRoute

@Serializable
object AuthGraph : AppRoute

@Serializable
object MainGraph : AppRoute

@Serializable
object MainRoute : AppRoute

@Serializable
object MapScreenRoute : AppRoute

@Serializable
object InfoCatalogMainRoute : AppRoute

@Serializable
object InfoCatalogStateSelectRoute : AppRoute

@Serializable
object InfoCatalogFishSelectRoute : AppRoute

@Serializable
data class CountySelectRoute(val stateId: Int) : AppRoute

@Serializable
object ForumFeedRoute : AppRoute

@Serializable
data class SignInFormRoute(val needConfirm: Boolean = false, val newSignUp: Boolean = false) : AppRoute

@Serializable
data class ForecastRoute(val latitude: Double, val longitude: Double) : AppRoute

@Serializable
object SignUpFormRoute : AppRoute

@Serializable
object ForgotPasswordRoute : AppRoute

@Serializable
object ResetPasswordRoute : AppRoute

@Serializable
object ConfirmEmailRoute : AppRoute

@Serializable
object UserSetupRoute : AppRoute


@Serializable
data class ForumPostCommentRoute(val postId: Long) : AppRoute

@Serializable
object UserSettingsRoute : AppRoute

@Serializable
object UploadPicRoute : AppRoute



