package com.example.fishfreshnewengland.forum.data

import com.example.fishfreshnewengland.entities.CatchInfo
import com.example.fishfreshnewengland.entities.Comment
import com.example.fishfreshnewengland.entities.Post
import com.example.fishfreshnewengland.entities.PostLocation
import com.example.fishfreshnewengland.forum.models.FeedFilteringMode
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import java.time.LocalDateTime
import java.util.concurrent.atomic.AtomicLong
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class InMemoryForumRepository @Inject constructor() : ForumRepository {

    private val postIdGen = AtomicLong(2L)
    private val commentIdGen = AtomicLong(1L)

    // Seed posts (so the feed UI shows something immediately)
    private val postsFlow = MutableStateFlow(
        listOf(
            Post(
                1L,
                "user-1",
                "Seed post: Hello forum!",
                "test_image",
                LocalDateTime.now(),
                0,
                1,
                CatchInfo(5, 28.6f, 5.5f, "Night Crawlers"),
                PostLocation(123, "Goshen Dam", 43.91451, 73.00372)
            ),
            Post(
                2L,
                "user-2",
                "Seed post: Testing feed UI",
                null,
                LocalDateTime.now(),
                2,
                0,
                null,
                null
            ),
            Post(
                3L,
                "user-1",
                "Seed post: hello this is my other post!",
                null,
                LocalDateTime.now(),
                5,
                34,
                null,
                null
        ),
            Post(
                4L,
                "user-3",
                "Seed post: hello this is my other post!",
                null,
                LocalDateTime.now(),
                1,
                2,
                null,
                null
            ),
        )
    )

    // Comments stored per postId
    private val commentsByPostId: MutableMap<Long, MutableStateFlow<List<Comment>>> =
        mutableMapOf(
            1L to MutableStateFlow(
                listOf(
                    Comment(
                        1L,
                        1L,
                        "user-3",
                        "Nice post!",
                        LocalDateTime.now(),
                        0
                    )
                )
            ),
            2L to MutableStateFlow(emptyList())
        )

    override fun observePosts(sortMode: FeedFilteringMode): Flow<List<Post>> {
        return postsFlow.map {posts ->
            when (sortMode){
                FeedFilteringMode.RECENT -> {
                    posts.sortedByDescending {it.getTimeStamp()}
                }
                FeedFilteringMode.ENGAGEMENT -> {
                    posts.sortedByDescending {it.getLikes() + it.getCommentCount()}
                }

                FeedFilteringMode.USER -> {
                    posts.sortedByDescending {it.getAuthorID()}
                }
            }
        }
    }

    override fun observeComments(postId: Long): Flow<List<Comment>> {
        return commentsByPostId.getOrPut(postId) { MutableStateFlow(emptyList()) }.asStateFlow()
    }

    override suspend fun createPost(content: String,
                                    AuthorID: String,
                                    imageUrl: String?,
                                    catchInfo: CatchInfo?,
                                    postLocation: PostLocation?)
                                    :Boolean
    {
        val newId = postIdGen.incrementAndGet()

        val newPost = Post(
            newId,
            AuthorID,
            content,
            imageUrl,
            LocalDateTime.now(),
            0,
            0,
            catchInfo,
            postLocation
        )

        postsFlow.value = listOf(newPost) + postsFlow.value
        commentsByPostId.putIfAbsent(newId, MutableStateFlow(emptyList()))
        return true
    }

    override suspend fun createComment(postId: Long, content: String): Boolean {
        val flow = commentsByPostId.getOrPut(postId) { MutableStateFlow(emptyList()) }
        val newId = commentIdGen.incrementAndGet()

        val newComment = Comment(
            newId,
            postId,
            "local-user",
            content,
            LocalDateTime.now(),
            0
        )

        flow.value = flow.value + newComment

        // Increase commentCount on the post (uses your working increment method)
        postsFlow.value = postsFlow.value.map { post ->
            if (post.getPostID() == postId) {
                post.incrementCommentCount()
            }
            post
        }

        return true
    }

    override suspend fun likePost(postId: Long): Boolean {
        // Uses your working increment method (avoids broken setLikes())
        postsFlow.value = postsFlow.value.map { post ->
            if (post.getPostID() == postId) {
                Post(
                    post.getPostID(),
                    post.getAuthorID(),
                    post.getContent(),
                    post.getImageURL(),
                    post.getTimeStamp(),
                    post.getLikes() + 1,
                    post.getCommentCount(),
                    post.getCatchInfo(),
                    post.getPostLocation()
                )
            } else {
                post
            }
        }
        return true
    }

    override suspend fun likeComment(commentId: Long): Boolean {
        // Your Comment has setLikes(int), so we can safely use it
        commentsByPostId.values.forEach { flow ->
            flow.value = flow.value.map { c ->
                if (c.getCommentId() == commentId) {
                    c.setLikes(c.getLikes() + 1)
                }
                c
            }
        }
        return true
    }
}