package com.example.fishfreshnewengland.internal.entities;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

import com.example.fishfreshnewengland.entities.THEME;

@Entity(tableName = "user_ui_settings")
public class UserUISettings {

    @PrimaryKey
    private int id = 1;

    private String language;
    private THEME theme;


    public UserUISettings() {
        language = "English";
        theme = THEME.SYSTEM;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getLanguage() { return language; }
    public void setLanguage(String language) { this.language = language; }

    public THEME getTheme() { return theme; }
    public void setTheme(THEME theme) { this.theme = theme; }
}
