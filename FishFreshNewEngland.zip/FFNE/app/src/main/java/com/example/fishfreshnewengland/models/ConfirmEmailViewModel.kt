package com.example.fishfreshnewengland.models

import androidx.compose.runtime.Immutable
import androidx.lifecycle.ViewModel
import com.example.fishfreshnewengland.external.AuthRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import io.github.jan.supabase.auth.OtpType
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import javax.inject.Inject

@Immutable
data class ConfirmEmailUIState (
    val tokenHash: String? = null,
    val type : OtpType? = null
)

@HiltViewModel
class ConfirmEmailViewModel @Inject constructor(
    private val authenticationRepository: AuthRepository
) : ViewModel()
{

    private val _uiState = MutableStateFlow(ConfirmEmailUIState())
    val uiState: StateFlow<ConfirmEmailUIState> = _uiState.asStateFlow()









}