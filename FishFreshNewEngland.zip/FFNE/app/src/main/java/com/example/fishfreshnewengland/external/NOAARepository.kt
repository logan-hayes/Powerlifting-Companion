package com.example.fishfreshnewengland.external

/**
 * @author Ashton Gabbeitt
 */
import com.example.fishfreshnewengland.entities.ForecastPeriod
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import javax.inject.Inject

class NOAARepository @Inject constructor(private val noaaService: NOAAService) {

    suspend fun getForecastHourlyLink(latitude: Double, longitude: Double): String? =
        withContext(Dispatchers.IO) {
            runCatching {
                val response = noaaService.getForecastHourlyLink(latitude, longitude)
                response.properties.forecastHourly
            }.getOrNull()
        }

        suspend fun getForecastHourlyPeriods(forecastHourly: String): List<ForecastPeriod>? =
            withContext(Dispatchers.IO) {
                runCatching {
                    val response = noaaService.getForecastHourlyPeriods(forecastHourly)
                    response.properties.periods.take(10)
                }.getOrNull()
            }
    }

