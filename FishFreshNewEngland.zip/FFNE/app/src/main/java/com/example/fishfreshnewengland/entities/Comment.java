package com.example.fishfreshnewengland.entities;

/**
 * @author Logan Hayes
 * */

import java.time.LocalDateTime;

public class Comment {

    private long commentID;
    private long postID;
    private String authorID;
    private String content;
    private LocalDateTime timeStamp;
    private int likes;

    public Comment(
            long commentID,
            long postID,
            String authorID,
            String content,
            LocalDateTime timeStamp,
            int likes){

        this.commentID = commentID;
        this.postID = postID;
        this.authorID = authorID;
        this.content = content;
        this.timeStamp = timeStamp;
        this.likes = likes;
    }

    //Secondary constructor for locally stored comment
    public Comment(long postID, String authorID, String content){
        this.commentID = 0;
        this.postID = postID;
        this.authorID = authorID;
        this.content = content;
        this.timeStamp = timeStamp;
        this.likes = 0;
    }

    public long getCommentId(){
        return commentID;
    }

    public void setCommentID(){
        this.commentID = commentID;
    }

    public long getPostID(){
        return postID;
    }

    public void setPostID(long postID){
        this.postID = postID;
    }

    public String getAuthorID(){
        return authorID;
    }

    public void setAuthorID(String authorID){
        this.authorID = authorID;
    }

    public String getContent(){
        return content;
    }

    public void setContent(String content){
        this.content = content;
    }

    public LocalDateTime getTimeStamp(){
        return timeStamp;
    }

    public void timeStamp(LocalDateTime getTimeStamp){
        this.timeStamp = timeStamp;
    }

    public int getLikes(){
        return likes;
    }

    public void setLikes(int likes){
        this.likes = likes;
    }

    public void incrementLikes(){
        this.likes++;
    }

    public void decrementLikes(){
        if (this.likes > 0) this.likes--;
    }
}