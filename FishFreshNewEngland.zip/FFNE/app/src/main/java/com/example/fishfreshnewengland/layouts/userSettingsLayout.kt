package com.example.fishfreshnewengland.layouts

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.fishfreshnewengland.external.entities.UserProfileSettings
import com.example.fishfreshnewengland.internal.entities.UserUISettings
import com.example.fishfreshnewengland.entities.THEME
import com.example.fishfreshnewengland.models.UserSettingsUIState

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UserSettingsLayoutContent(
    uiState: UserSettingsUIState,
    onSaveSettings: (UserUISettings, UserProfileSettings) -> Unit,
    onNavigateBack: () -> Unit
) {
    // local mutable copies of settings for editing
    var selectedTheme by remember(uiState.uiSettings) {
        mutableStateOf(uiState.uiSettings?.theme ?: THEME.SYSTEM)
    }
    var selectedLanguage by remember(uiState.uiSettings) {
        mutableStateOf(uiState.uiSettings?.language ?: "English")
    }
    var emailNotifications by remember(uiState.profileSettings) {
        mutableStateOf(uiState.profileSettings?.isEmailNotifications ?: true)
    }
    var isPrivate by remember(uiState.profileSettings) {
        mutableStateOf(uiState.profileSettings?.isPrivate ?: false)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("User Settings") },
                navigationIcon = {
                    IconButton(onClick = { onNavigateBack() }) {
                        Icon(
                            imageVector = Icons.Filled.ArrowBack,
                            contentDescription = "Back"
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = MaterialTheme.colorScheme.onPrimary,
                    navigationIconContentColor = MaterialTheme.colorScheme.onPrimary
                )
            )
        }
    ) { innerPadding ->

        if (uiState.isLoading) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .padding(horizontal = 16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {

                // --- UI SETTINGS SECTION ---
                item {
                    Text(
                        "Display Settings",
                        style = MaterialTheme.typography.titleMedium,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 12.dp)
                    )
                }

                // Theme selector
                item {
                    Text("Theme", style = MaterialTheme.typography.labelLarge)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        THEME.entries.forEach { theme ->
                            FilterChip(
                                selected = selectedTheme == theme,
                                onClick = { selectedTheme = theme },
                                label = { Text(theme.name) }
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                }

                // Language selector
                item {
                    Text("Language", style = MaterialTheme.typography.labelLarge)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        listOf("English", "Spanish", "French").forEach { lang ->
                            FilterChip(
                                selected = selectedLanguage == lang,
                                onClick = { selectedLanguage = lang },
                                label = { Text(lang) }
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                }

                // --- PROFILE SETTINGS SECTION ---
                item {
                    HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))
                    Text(
                        "Profile Settings",
                        style = MaterialTheme.typography.titleMedium,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 12.dp)
                    )
                }

                // Email notifications toggle
                item {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Email Notifications")
                        Switch(
                            checked = emailNotifications,
                            onCheckedChange = { emailNotifications = it }
                        )
                    }
                }

                // Private profile toggle
                item {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Private Profile")
                        Switch(
                            checked = isPrivate,
                            onCheckedChange = { isPrivate = it }
                        )
                    }
                }

                // error message
                if (uiState.errorMessage != null) {
                    item {
                        Text(
                            uiState.errorMessage,
                            color = MaterialTheme.colorScheme.error,
                            modifier = Modifier.padding(vertical = 8.dp)
                        )
                    }
                }

                // Save button
                item {
                    Spacer(modifier = Modifier.height(16.dp))
                    Button(
                        onClick = {
                            val updatedUISettings = UserUISettings().apply {
                                language = selectedLanguage
                                theme = selectedTheme
                            }
                            val updatedProfileSettings = (uiState.profileSettings ?: UserProfileSettings()).apply {
                                setEmailNotifications(emailNotifications)
                                setPrivate(isPrivate)
                            }
                            onSaveSettings(updatedUISettings, updatedProfileSettings)
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Save Settings")
                    }
                }
            }
        }
    }
}