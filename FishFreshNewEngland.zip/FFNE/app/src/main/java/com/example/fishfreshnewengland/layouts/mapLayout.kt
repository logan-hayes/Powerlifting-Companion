package com.example.fishfreshnewengland.layouts

/**
 * @author Ashton Gabbeitt
 */


import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.outlined.FilterAlt
import androidx.compose.material3.BottomAppBar
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.fishfreshnewengland.map.entities.AccessPointItem
import com.example.fishfreshnewengland.internal.entities.AccessPoints
import com.example.fishfreshnewengland.models.MapUIState
import com.example.fishfreshnewengland.security.LocationPermGate
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.model.CameraPosition
import com.google.android.gms.maps.model.LatLng
import com.google.maps.android.compose.GoogleMap
import com.google.maps.android.compose.MapProperties
import com.google.maps.android.compose.MapUiSettings
import com.google.maps.android.compose.MapsComposeExperimentalApi
import com.google.maps.android.compose.Marker
import com.google.maps.android.compose.rememberCameraPositionState
import com.google.maps.android.compose.clustering.Clustering
import com.google.maps.android.compose.rememberUpdatedMarkerState


/**
 * Map Layout
 * @param navController: NavController for navigation
 * @param uiState: MapUIState containing map data
 * @param onMapLoaded: Function to be called when the map is loaded
 * @param userLocation: Function to get the user's location
 * @param getCloseAccesses: Function to get close access points
 *
 */
@OptIn(ExperimentalMaterial3Api::class, MapsComposeExperimentalApi::class)
@Composable
fun MapLayoutContent (
    navController: NavController,
    uiState : MapUIState,
    onMapLoaded: () -> Unit,
    userLocation: () -> Unit,
    getCloseAccesses: () -> Unit,
    getAccessData : (AccessPoints) -> Unit
) {
    val defaultPosition = LatLng(43.60854, -73.21758)

    val cameraPositionState = rememberCameraPositionState {
        position = CameraPosition.fromLatLngZoom(defaultPosition, 11f)
    }

    val clusterItems = remember(uiState.accessLocationMarkers) {
        uiState.accessLocationMarkers?.map { AccessPointItem(it) } ?: emptyList()
    }

    val sheetState = rememberModalBottomSheetState()
    var showBottomSheet by remember { mutableStateOf(false) }

    LocationPermGate(navController) {

        LaunchedEffect(Unit) {
            userLocation()
        }


        LaunchedEffect(uiState.userLocation) {
            uiState.userLocation?.let {
                val userLatLng = LatLng(it.latitude, it.longitude)

                getCloseAccesses()

                if (!uiState.isReady) {

                    cameraPositionState.move(
                        CameraUpdateFactory.newLatLngZoom(userLatLng, 11f)
                    )


                } else {

                    cameraPositionState.animate(
                        CameraUpdateFactory
                            .newLatLngZoom(userLatLng, 11f)

                    )

                }
            }
        }


            //TODO
            //create markers for each location
            //create onClick for each to load the data onto a modal
            //create a modal to display the data


            Scaffold(
                topBar = {
                    TopAppBar(
                        title = { Text("Fish Map") },
                        navigationIcon = {
                            IconButton(onClick = { navController.popBackStack() }) {
                                Icon(Icons.AutoMirrored.Filled.ArrowBack, "Go Back")
                            }
                        },
                        colors = TopAppBarDefaults.topAppBarColors(
                            containerColor = MaterialTheme.colorScheme.primary,
                            titleContentColor = MaterialTheme.colorScheme.onPrimary,
                            navigationIconContentColor = MaterialTheme.colorScheme.onPrimary
                        )
                    )
                },
                bottomBar = {
                    BottomAppBar(
                        actions = {
                            IconButton(onClick = { /* Filter logic */ }) {
                                Icon(Icons.Outlined.FilterAlt, "Filter")
                            }
                        },
                        containerColor = MaterialTheme.colorScheme.primary,
                        contentColor = MaterialTheme.colorScheme.onPrimary,
                    )
                }
            ) { innerPadding ->
                Box(
                    modifier = Modifier.fillMaxSize().padding(innerPadding),
                ) {
                    GoogleMap(
                        modifier = Modifier.fillMaxSize(),
                        cameraPositionState = cameraPositionState,
                        onMapLoaded = onMapLoaded,
                        uiSettings = MapUiSettings(myLocationButtonEnabled = true),
                        properties = MapProperties(isMyLocationEnabled = true)
                    ) {


                        Clustering(
                            items = clusterItems,
                            onClusterItemClick = { clusterItem ->


                               getAccessData(clusterItem.item)

                                showBottomSheet = true

                                true

                            }


                        )


                    }



                    AnimatedVisibility(
                        visible = !uiState.isReady,
                        enter = fadeIn(),
                        exit = fadeOut(animationSpec = tween(500))
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(MaterialTheme.colorScheme.background), // Covers the map
                            contentAlignment = Alignment.Center
                        ) {


                            Column(

                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(16.dp)
                            ) {
                                CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
                                Text(
                                    text = "Loading map...",
                                    style = MaterialTheme.typography.bodyMedium
                                )
                            }
                        }
                    }
                    if (showBottomSheet) {
                        ModalBottomSheet(
                            onDismissRequest = { showBottomSheet = false },
                            sheetState = sheetState
                        ) {
                            ForecastSheetContent(uiState)
                        }
                    }
                }


            }
        }
    }


@Composable
fun ForecastSheetContent(uiState: MapUIState) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp)
            .padding(bottom = 32.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        val forecast = uiState.forecast
        val fish = uiState.accessFish
        val fishNames = fish?.joinToString(", ") { it.species }



        if (forecast == null) {
            CircularProgressIndicator()
            Text("Fetching Access Info...", modifier = Modifier.padding(top = 8.dp))
        } else {
            Text(text = "Access: ${uiState.selectedAccess?.name}", style = MaterialTheme.typography.headlineMedium, modifier = Modifier.padding(bottom = 8.dp))
            Text(text = "Waterbody: ${uiState.accessWaterbody?.name}", style = MaterialTheme.typography.bodyLarge)
            Text(text="Location: ${uiState.accessTown}, ${uiState.accessState}", style = MaterialTheme.typography.bodyLarge)
            Text("${uiState.selectedAccess?.latitude}, ${uiState.selectedAccess?.longitude}", style = MaterialTheme.typography.bodyLarge, modifier = Modifier.padding(bottom = 8.dp))
            HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))
            Text(text = "Current Weather", style = MaterialTheme.typography.headlineSmall)
            Text(
                text = "${forecast.temperature}°${forecast.temperatureUnit}",
                style = MaterialTheme.typography.bodyLarge
            )
            forecast.shortForecast?.let { Text(text = it, style = MaterialTheme.typography.bodyLarge) }
            HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))
            Text(text = "Potential Fish: $fishNames", style = MaterialTheme.typography.bodyLarge)
        }
    }
}
