package com.example.fishfreshnewengland.external
/**
 * @author Ashton Gabbeitt
 */

import com.example.fishfreshnewengland.entities.CatchInfo
import com.example.fishfreshnewengland.entities.Comment
import com.example.fishfreshnewengland.entities.Post
import com.example.fishfreshnewengland.entities.PostLocation
import com.example.fishfreshnewengland.external.entities.FishExternal
import com.example.fishfreshnewengland.external.entities.ForumCommentCreation
import com.example.fishfreshnewengland.external.entities.ForumPostCreation
import com.example.fishfreshnewengland.external.entities.ProfilePicResponse
import com.example.fishfreshnewengland.external.entities.UserProfileSettings
import com.example.fishfreshnewengland.external.entities.UserSetup
import com.example.fishfreshnewengland.external.entities.UsernameResponse

interface DatabaseRepository {
    suspend fun getAllFish(): List<FishExternal>?
    suspend fun getUserProfileSettings(userId: String): UserProfileSettings?
    suspend fun saveUserProfileSettings(settings: UserProfileSettings): Boolean
    suspend fun usernameValidator(username: String) : Result<Boolean>

    suspend fun submitUserSetup(userSetupData: UserSetup) : Result<UserSetup>

    suspend fun getCurrentUserName(userId: String) : Result<UsernameResponse>

    suspend fun getUserProfilePicPath(userId: String) : Result<ProfilePicResponse>

    suspend fun createForumPost(post: ForumPostCreation): Result<Boolean>
    suspend fun createForumComment(comment: ForumCommentCreation): Result<Boolean>

    suspend fun likePost(postId: Long, userId: String): Result<Boolean>
    suspend fun likeComment(postId: Long, userId: String): Result<Boolean>

    suspend fun getForumPosts(): Result<List<Post>>
    suspend fun getForumPost(postID: Long): Result<Post?>
    suspend fun getForumComments(postId: Long): Result<List<Comment>>
}