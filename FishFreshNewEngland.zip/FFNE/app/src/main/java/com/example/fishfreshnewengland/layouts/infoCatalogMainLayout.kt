package com.example.fishfreshnewengland.layouts

/**
 * @author Ashton Gabbeitt
 */
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.fishfreshnewengland.navigation.InfoCatalogFishSelectRoute
import com.example.fishfreshnewengland.navigation.InfoCatalogStateSelectRoute


/**
 * Display layout for information catalog. Routes to fish list, water body list, region list, and regulation list.
 * @param navController: NavHostController for navigation
 */
@ExperimentalMaterial3Api
@Composable
fun InfoCatalogMainLayoutContent(navController: NavController) {
    val choices =
        mapOf<Int, String>(1 to "Fish", 2 to "Water Bodies", 3 to "Regions", 4 to "Regulations")

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        "Info Catalog"
                    )
                },
                navigationIcon = {
                    IconButton(onClick = {
                        navController.popBackStack()
                    }) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Go Back"
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = MaterialTheme.colorScheme.onPrimary,
                    navigationIconContentColor = MaterialTheme.colorScheme.onPrimary

                )
            )
        },
        content = { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding),
                contentAlignment = Alignment.Center
            ) {

                CatalogList(choices, navController)

            }
        },
    )
}

@Composable
fun CatalogOptions(entry: Map.Entry<Int, String>, onItemClick: (Int) -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onItemClick(entry.key) }
            .padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(text = entry.value, style = MaterialTheme.typography.titleMedium)
    }
}

@Composable
fun CatalogList(options: Map<Int, String>, navController: NavController) {
    val entries = options.entries.toList()
    LazyColumn(modifier = Modifier.fillMaxSize()) {

        items(entries) { entry ->
            CatalogOptions(
                entry = entry,
                onItemClick = { id ->
                    if (id == 1) {
                        navController.navigate(InfoCatalogFishSelectRoute)
                    } else if (id == 3) {
                        navController.navigate(InfoCatalogStateSelectRoute)

                    }
                }
            )
            HorizontalDivider()
        }
    }
}