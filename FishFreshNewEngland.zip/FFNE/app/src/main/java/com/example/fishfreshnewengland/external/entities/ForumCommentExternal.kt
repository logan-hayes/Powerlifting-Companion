package com.example.fishfreshnewengland.external.entities

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class ForumCommentExternal(
    @SerialName("comment_id")
    val commentId: Long,
    @SerialName("post_id")
    val postId: Long,
    val content: String,
    @SerialName("user_id")
    val userId: String,
    @SerialName("created_at")
    val createdAt: String? = null,
    @SerialName("parent_comment_id")
    val parentCommentId: Long? = null,
    val depth: Int? = null,
    @SerialName("updated_at")
    val updatedAt: String? = null
)