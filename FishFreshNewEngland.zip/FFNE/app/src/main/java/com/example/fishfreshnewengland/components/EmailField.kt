package com.example.fishfreshnewengland.components

/**
 * @author Ashton Gabbeitt
 */

import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier

@Composable
fun EmailField(email: String, onEmailChanged: (String) -> Unit, enabled : Boolean = true) {
    OutlinedTextField(
        value = email,
        onValueChange = onEmailChanged,
        label = { Text("Email") },
        modifier = Modifier.fillMaxWidth(),
        enabled = enabled
    )
}
