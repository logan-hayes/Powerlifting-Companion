package com.example.fishfreshnewengland.models

import androidx.compose.runtime.Immutable
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.fishfreshnewengland.external.DatabaseRepositoryImpl
import com.example.fishfreshnewengland.external.entities.UserProfileSettings
import com.example.fishfreshnewengland.internal.entities.UserUISettings
import com.example.fishfreshnewengland.internal.repositories.UserUISettingsRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

@Immutable
data class UserSettingsUIState(
    val uiSettings: UserUISettings? = null,
    val profileSettings: UserProfileSettings? = null,
    val isLoading: Boolean = false,
    val errorMessage: String? = null
)

@HiltViewModel
class UserSettingsViewModel @Inject constructor(
    private val uiRepository: UserUISettingsRepository,
    private val database: DatabaseRepositoryImpl
) : ViewModel() {

    private val _uiState = MutableStateFlow(UserSettingsUIState())
    val uiState: StateFlow<UserSettingsUIState> = _uiState.asStateFlow()

    fun loadSettings(userId: String) {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            try {
                // load local UI settings
                val localSettings = uiRepository.getSettings()

                // load remote profile settings
                val remoteSettings = database.getUserProfileSettings(userId)

                _uiState.update {
                    it.copy(
                        uiSettings = localSettings,
                        profileSettings = remoteSettings,
                        isLoading = false
                    )
                }
            } catch (e: Exception) {
                _uiState.update { it.copy(isLoading = false, errorMessage = e.message) }
            }
        }
    }

    fun saveSettings(uiSettings: UserUISettings, profileSettings: UserProfileSettings) {
        viewModelScope.launch {
            try {
                // save UI settings locally
                uiRepository.saveSettings(uiSettings)

                // save profile settings to Supabase
                database.saveUserProfileSettings(profileSettings)

                _uiState.update {
                    it.copy(uiSettings = uiSettings, profileSettings = profileSettings)
                }
            } catch (e: Exception) {
                _uiState.update { it.copy(errorMessage = e.message) }
            }
        }
    }
}