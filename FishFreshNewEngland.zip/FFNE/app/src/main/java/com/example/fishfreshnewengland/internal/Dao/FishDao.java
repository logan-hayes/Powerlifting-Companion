package com.example.fishfreshnewengland.internal.Dao;

/**
 * @author Ashton Gabbeitt
 */
import androidx.room.Dao;
import androidx.room.Query;


import com.example.fishfreshnewengland.internal.entities.Fish;

import java.util.List;

@Dao
public interface FishDao {
    @Query("SELECT * FROM fish")
    List<Fish> getAll();

    @Query("SELECT * FROM fish WHERE id = :id")
    Fish getById(int id);
}
