package com.example.fishfreshnewengland.models

import androidx.compose.runtime.Immutable
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.fishfreshnewengland.external.AuthRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

@Immutable
data class SignUpUIState(
    val email: String = "",
    val password: String = "",
    val confirmPassword: String = "",
    val isLoading: Boolean = false,
    val formReady: Boolean = false,
    val createSuccess: Boolean = false,
    val errorMessage: String? = null
)

@HiltViewModel
class SignUpViewModel @Inject constructor(
    private val authenticationRepository: AuthRepository,
) : ViewModel() {

    private val _uiState = MutableStateFlow(SignUpUIState())
    val uiState = _uiState.asStateFlow()

    fun onEmailChanged(emailChange: String) {
        _uiState.update {
            it.copy(
                email = emailChange,
                formReady = emailChange.isNotBlank() && _uiState.value.password.isNotBlank() && _uiState.value.confirmPassword.isNotBlank()
            )
        }
    }

    fun onPasswordChanged(passwordChanged: String) {
        _uiState.update {
            it.copy(
                password = passwordChanged,
                formReady = passwordChanged.isNotBlank() && _uiState.value.email.isNotBlank() && _uiState.value.confirmPassword.isNotBlank() && passwordChanged == _uiState.value.confirmPassword
            )
        }
    }

    fun onPasswordConfirmChanged(passwordConfirmChanged: String) {
        _uiState.update {
            it.copy(
                confirmPassword = passwordConfirmChanged,
                formReady = passwordConfirmChanged.isNotBlank() && _uiState.value.password.isNotBlank() && _uiState.value.email.isNotBlank() && passwordConfirmChanged == _uiState.value.password
            )
        }
    }

    fun signUpWithEmail() {
        viewModelScope.launch {
            try {

                val result = authenticationRepository.signUp(_uiState.value.email, _uiState.value.password)

                result.onSuccess {
                    _uiState.update { it.copy(createSuccess = true, errorMessage = null) }
                }
                result.onFailure { error ->
                    _uiState.update { it.copy(errorMessage = error.localizedMessage) }
                }

            }
            catch (e: Exception) {
                _uiState.update {
                    it.copy(isLoading = false, errorMessage = e.message, createSuccess = false)
                }
            }

}
    }

}