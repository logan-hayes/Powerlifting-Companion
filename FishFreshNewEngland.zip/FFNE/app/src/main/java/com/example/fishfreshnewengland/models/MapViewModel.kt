package com.example.fishfreshnewengland.models


/**
 * @author Ashton Gabbeitt
 */
import android.util.Log
import androidx.compose.runtime.Immutable
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.fishfreshnewengland.entities.ForecastPeriod
import com.example.fishfreshnewengland.external.NOAARepository
import com.example.fishfreshnewengland.internal.Dao.WaterBodyDao
import com.example.fishfreshnewengland.internal.entities.AccessPoints
import com.example.fishfreshnewengland.internal.entities.Counties
import com.example.fishfreshnewengland.internal.entities.Fish
import com.example.fishfreshnewengland.internal.entities.States
import com.example.fishfreshnewengland.internal.entities.Towns
import com.example.fishfreshnewengland.internal.entities.WaterBodies
import com.example.fishfreshnewengland.map.entities.LocationClient
import com.example.fishfreshnewengland.map.entities.LocationData
import com.example.fishfreshnewengland.internal.repositories.AccessPointRepository
import com.example.fishfreshnewengland.internal.repositories.CountyRepository
import com.example.fishfreshnewengland.internal.repositories.FishRepository
import com.example.fishfreshnewengland.internal.repositories.FishWaterBodiesRepository
import com.example.fishfreshnewengland.internal.repositories.StateRepository
import com.example.fishfreshnewengland.internal.repositories.TownRepository
import com.example.fishfreshnewengland.internal.repositories.WaterBodyRepository
import com.example.fishfreshnewengland.navigation.DefaultDispatcher
import com.example.fishfreshnewengland.navigation.IoDispatcher
import com.example.fishfreshnewengland.processors.isWithinRadius
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.datetime.TimeZone
import kotlinx.datetime.toLocalDateTime
import javax.inject.Inject
import kotlin.time.Clock
import kotlin.time.ExperimentalTime


@Immutable
data class MapUIState(
    val isReady: Boolean = false,
    val userLocation : LocationData? = null,
    val accessLocationMarkers : List<AccessPoints>? = null,
    val forecastLink : String? = null,
    val forecast: ForecastPeriod? = null,
    val accessFish : List<Fish>? = null,
    val allFish : List<Fish>? = null,
    val selectedAccess : AccessPoints? = null,
    val accessWaterbody : WaterBodies? = null,
    val accessTown : Towns? = null,
    val accessCounty : Counties? = null,
    val accessState : States? = null
)

/**
 * ViewModel for map setup
 * creates delay to allow map to load before UI is updated
 */
@HiltViewModel
class MapViewModel @Inject constructor(
    private val locationClient: LocationClient,
    private val accessRepository: AccessPointRepository,
    private val noaa : NOAARepository,
    private val fishWaterbodyRepository: FishWaterBodiesRepository,
    private val fishRepository: FishRepository,
    private val waterbodyRepository: WaterBodyRepository,
    private val townRepository : TownRepository,
    private val countyRepository : CountyRepository,
    private val stateRepository: StateRepository,
    @DefaultDispatcher private val defaultDispatcher: CoroutineDispatcher,
    @IoDispatcher private val ioDispatcher: CoroutineDispatcher

): ViewModel() {
    private val _uiState = MutableStateFlow(MapUIState())
    val uiState : StateFlow<MapUIState> = _uiState.asStateFlow()

    init {
        if(_uiState.value.allFish == null) {
            viewModelScope.launch(defaultDispatcher) {
                val fetchedFish = withContext(ioDispatcher) {
                    fishRepository.fetchAllFish()
                }
                if(fetchedFish != null) {
                    _uiState.update { it.copy(allFish = fetchedFish) }
                }
            }
        }
    }

    fun setMapReady(ready: Boolean) {
        _uiState.update { it.copy(isReady = ready) }
    }

    fun userLocation() {
        viewModelScope.launch {
            val location = locationClient.getUserLocation()
            _uiState.update { it.copy(userLocation = location) }
        }
    }

    fun getCloseAccesses(){

        viewModelScope.launch(defaultDispatcher) {
            val userLocation = uiState.value.userLocation ?: return@launch

            val accessPoints = withContext(ioDispatcher) {
                accessRepository.fetchAllAccessPoints()
            }

                val closeAccessPoints = accessPoints.filter { accessPoint ->
                    isWithinRadius(
                        userLocation.latitude,
                        userLocation.longitude,
                        accessPoint.latitude,
                        accessPoint.longitude,
                        50.0
                    )
                }

                _uiState.update { it.copy(accessLocationMarkers = ArrayList(closeAccessPoints)) }
            }

        }


    @OptIn(ExperimentalTime::class)
    fun getAccessData(access: AccessPoints) {
        viewModelScope.launch (defaultDispatcher) {

            val currentTime = Clock.System.now()
            val currentTimeHour = currentTime.toLocalDateTime(TimeZone.currentSystemDefault()).hour

            _uiState.update { it.copy(selectedAccess = access) }

            // 2. Chain the fetches using local variables to avoid reading 'null' from state
            val waterBody = withContext(ioDispatcher) {
                waterbodyRepository.fetchWaterBodyById(access.waterbodyID)
            }

            if (waterBody != null) {
                _uiState.update { it.copy(accessWaterbody = waterBody) }

                val tId = waterBody.townID
                if (tId != null) {
                    val town = withContext(ioDispatcher) { townRepository.fetchTownById(tId) }

                    if (town != null) {
                        _uiState.update { it.copy(accessTown = town) }

                        val county = withContext(ioDispatcher) { countyRepository.fetchCountyByID(town.countyID) }
                        if (county != null) {
                            _uiState.update { it.copy(accessCounty = county) }

                            val state = withContext(ioDispatcher) { stateRepository.fetchStateByID(county.stateID) }
                            _uiState.update { it.copy(accessState = state) }
                        }
                    }
                } else {
                    Log.w("MapViewModel", "Waterbody ${waterBody.id} has no associated townID")
                }
            }


            val fetchedLink = withContext(ioDispatcher) {
                noaa.getForecastHourlyLink(access.latitude, access.longitude)
            } ?: return@launch

            if(_uiState.value.forecastLink != fetchedLink || _uiState.value.forecast == null) {
                _uiState.update { it.copy(forecastLink = fetchedLink) }
                val fetchedForecast = withContext(ioDispatcher) {
                    noaa.getForecastHourlyPeriods(fetchedLink)
                } ?: return@launch

                val matchingHour = fetchedForecast.find { it.startTimeHour == currentTimeHour }
                    _uiState.update { it.copy(forecast = matchingHour) }
                }


            val fetchedFishWaterbodies = withContext(ioDispatcher) {
                fishWaterbodyRepository.fetchFishForWaterBody(access.waterbodyID)
            } ?: return@launch

            if(_uiState.value.accessFish != fetchedFishWaterbodies) {
                val fetchedFish = ArrayList<Fish>()
                for (fishWaterbody in fetchedFishWaterbodies) {
                    _uiState.value.allFish?.find { it.id == fishWaterbody.fishID }?.let {
                        fetchedFish.add(it)
                    }
                }

                _uiState.update { it.copy(accessFish = fetchedFish) }
            }

            }
        }

    }
