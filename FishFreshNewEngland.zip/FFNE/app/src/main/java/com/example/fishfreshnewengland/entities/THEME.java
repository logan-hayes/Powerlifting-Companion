package com.example.fishfreshnewengland.entities;
/**
 * @author Ashton Gabbeitt
 */
public enum THEME {
    LIGHT,
    DARK,
    SYSTEM
}
