package com.example.fishfreshnewengland.internal.Dao;

/**
 * @author Ashton Gabbeitt
 */

import androidx.room.Dao;
import androidx.room.Query;

import com.example.fishfreshnewengland.internal.entities.States;

import java.util.List;

/**
 * Data access object for states
 */
@Dao
public interface StateDao {
    @Query("SELECT * FROM states")
    List<States> getAll();

    @Query("SELECT * FROM states WHERE id = :id")
    States getById(int id);

}
