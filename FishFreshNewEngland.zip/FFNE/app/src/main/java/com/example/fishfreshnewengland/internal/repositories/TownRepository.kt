package com.example.fishfreshnewengland.internal.repositories

import com.example.fishfreshnewengland.internal.entities.Towns
import com.example.fishfreshnewengland.internal.Dao.TownDao
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import javax.inject.Inject

class TownRepository @Inject constructor(
    private val townDao : TownDao
) {
    suspend fun fetchTownsByCounty(countyID: Int): List<Towns> {
        return withContext(Dispatchers.IO) {
            townDao.getAllByCounty(countyID)
        }
    }

    suspend fun fetchAllTowns() : List<Towns> {
        return withContext(Dispatchers.IO) {
            townDao.getAll()
        }
    }

    suspend fun fetchTownById(id: Int) : Towns? {
        return withContext(Dispatchers.IO) {
            townDao.getById(id)
        }
    }
}