package com.example.fishfreshnewengland.forum.models

enum class FeedFilteringMode {
    RECENT,
    ENGAGEMENT,
    USER
}