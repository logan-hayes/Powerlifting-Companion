package com.example.fishfreshnewengland.layouts

/**
 * @author Ashton Gabbeitt
 */
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.fishfreshnewengland.internal.entities.Fish
import com.example.fishfreshnewengland.models.FishUIState


/**
 * Display layout for fish list in information catalog. Routes to fish data card.
 * @param navController: NavHostController for navigation
 * @param uiState: FishUIState containing data for fish list
 */
@ExperimentalMaterial3Api
@Composable
fun InfoCatalogFishSelectLayoutContent(
    navController: NavController,
    uiState: FishUIState,
) {

        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("Fish List") },
                    navigationIcon = {
                        IconButton(onClick = { navController.popBackStack() }) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, "Go Back")
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.primary,
                        titleContentColor = MaterialTheme.colorScheme.onPrimary,
                        navigationIconContentColor = MaterialTheme.colorScheme.onPrimary
                    )
                )
            },
            content = { innerPadding ->
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                ) {
                    if (uiState.isLoading) {
                        CircularProgressIndicator(modifier = Modifier.align(Alignment.Center))
                    } else {
                        // THE LIST
                        LazyColumn(modifier = Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally) {
                            items(uiState.fishList) { fish ->
                                FishRow(fish)
                                HorizontalDivider()
                            }
                        }
                    }
                }
            },
        )
    }


@Composable
fun FishRow(fish: Fish) {
    Column(modifier = Modifier.padding(16.dp)) {
        Text(text = fish.species, style = MaterialTheme.typography.titleMedium)
        // Add other fish fields here
    }
}