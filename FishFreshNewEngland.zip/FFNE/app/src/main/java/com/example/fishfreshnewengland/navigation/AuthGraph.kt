package com.example.fishfreshnewengland.navigation

/**
 * @author Ashton Gabbeitt
 */

import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.navigation.NavController
import androidx.navigation.NavGraphBuilder
import androidx.navigation.compose.composable
import androidx.navigation.navigation
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.fishfreshnewengland.layouts.ConfirmEmailLayoutContent
import com.example.fishfreshnewengland.layouts.ForgotPasswordLayoutContent
import com.example.fishfreshnewengland.layouts.ResetPasswordLayoutContent
import com.example.fishfreshnewengland.layouts.SignInLayoutContent
import com.example.fishfreshnewengland.layouts.SignUpLayoutContent
import com.example.fishfreshnewengland.layouts.UploadPicLayoutContent
import com.example.fishfreshnewengland.layouts.UserSetupLayoutContent

import com.example.fishfreshnewengland.models.ForgotPasswordViewModel
import com.example.fishfreshnewengland.models.ResetPasswordViewModel
import com.example.fishfreshnewengland.models.SignInViewModel
import com.example.fishfreshnewengland.models.SignUpViewModel
import com.example.fishfreshnewengland.models.UploadPicViewModel
import com.example.fishfreshnewengland.models.UserSetupViewModel


/**
 * Navigation graph for authentication routes
 * @param navController: NavController for navigation
 */
fun NavGraphBuilder.authGraph(navController: NavController) {
    navigation<AuthGraph>(startDestination = SignInFormRoute()) {

        composable<SignUpFormRoute> {
            val signUpViewModel: SignUpViewModel = hiltViewModel()
            SignUpLayoutContent(navController, signUpViewModel)
        }

        composable<ConfirmEmailRoute>{
            ConfirmEmailLayoutContent(navigateToSetup = { navController.navigate(UserSetupRoute) })
        }

        composable<UserSetupRoute>{
            val userSetupViewModel : UserSetupViewModel = hiltViewModel()
            val uiState by userSetupViewModel.uiState.collectAsStateWithLifecycle()

            UserSetupLayoutContent(
                navigateToMain = { navController.navigate(MainRoute) },
                uiState = uiState,
                onUsernameChanged = userSetupViewModel::onUsernameChanged,
                onBirthDateChanged = userSetupViewModel::onBirthDateChanged,
                onAvatarChanged = userSetupViewModel::onAvatarChanged,
                submitUserSetup = userSetupViewModel::submitUserSetup
            )
        }

        composable<UploadPicRoute>{
            val uploadPicViewModel : UploadPicViewModel = hiltViewModel()
            val uiState by uploadPicViewModel.uiState.collectAsStateWithLifecycle()

            UploadPicLayoutContent(
                navigateToMain = { navController.navigate(MainRoute) },
                uiState = uiState,
                onAvatarChanged = uploadPicViewModel::onAvatarChanged,
                submitUpload = uploadPicViewModel::submitUpload
            )

        }

        composable<SignInFormRoute> {

            val signInViewModel: SignInViewModel = hiltViewModel()
            val uiState by signInViewModel.uiState.collectAsStateWithLifecycle()

            LaunchedEffect(uiState.loginSuccess) {
                if (uiState.loginSuccess) {
                    navController.navigate(MainRoute) {
                        popUpTo<AuthGraph> { inclusive = true }
                    }
                }
            }

            SignInLayoutContent(
                uiState = uiState,
                onEmailChange = signInViewModel::onEmailChanged,
                onPasswordChange = signInViewModel::onPasswordChanged,
                onSignInClick = signInViewModel::signInUser,
                snackbarDismissed = signInViewModel::onSnackbarDismissed,
                clearNeedConfirm = signInViewModel::clearNeedConfirm,
                clearNewUser = signInViewModel::clearNewUser,
                onNavigateToSignUp = { navController.navigate(SignUpFormRoute) },
                onNavigateToForgotPW = { navController.navigate(ForgotPasswordRoute) },
                onNavigateToMain = { navController.navigate(MainRoute) },
            )
        }

        composable<ForgotPasswordRoute> {
            val forgotPasswordViewModel: ForgotPasswordViewModel = hiltViewModel()
            val uiState by forgotPasswordViewModel.uiState.collectAsStateWithLifecycle()
            ForgotPasswordLayoutContent(
                uiState,
                navigateBackStack = {navController.popBackStack() },
                onEmailChanged = { forgotPasswordViewModel.onEmailChanged( it ) },
                requestPasswordResetEmail = { forgotPasswordViewModel.requestPasswordResetEmail() },
                navigateToSignIn = { navController.navigate(SignInFormRoute(newSignUp = false)) })
        }

        composable<ResetPasswordRoute> {
            val resetPasswordViewModel: ResetPasswordViewModel = hiltViewModel()
            val uiState by resetPasswordViewModel.uiState.collectAsStateWithLifecycle()
            ResetPasswordLayoutContent(
                uiState,
                navigateToMain = { navController.navigate(MainRoute) },
                onEmailChanged = { resetPasswordViewModel.onEmailChanged(it) },
                onPasswordChanged = { resetPasswordViewModel.onPasswordChanged(it) },
                onPasswordConfirmChanged = { resetPasswordViewModel.onPasswordConfirmChanged(it) },
                resetPassword = { resetPasswordViewModel.resetPW()}
            )
        }



    }
    }
