package com.example.fishfreshnewengland.external

/**
 * @author Ashton Gabbeitt
 */
import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
abstract class RepoModule {

    @Binds
    @Singleton
    abstract fun bindAuthRepo(
        authRepositoryImpl: AuthRepositoryImpl
    ): AuthRepository


    @Binds
    @Singleton
    abstract fun bindDatabaseRepo(
        dbRepositoryImpl: DatabaseRepositoryImpl
    ): DatabaseRepository

    @Binds
    @Singleton
    abstract fun bindStorageRepo(
        storageRepositoryImpl: StorageRepositoryImpl
    ): StorageRepository

}