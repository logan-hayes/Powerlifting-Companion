package com.example.fishfreshnewengland.external

/**
 * @author Ashton Gabbeitt
 */
import com.example.fishfreshnewengland.entities.ForecastPeriod
import kotlinx.serialization.Serializable
import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Url

@Serializable
data class PointResponse(
    val properties: ForecastHourly,
)
@Serializable
data class ForecastHourly(
    val forecastHourly: String,
)

@Serializable
data class ForecastResponse(
    val properties: ForecastPeriodsWrapper
)

@Serializable
data class ForecastPeriodsWrapper(
    val periods: List<ForecastPeriod>
)

interface NOAAService {

    @GET("points/{latitude},{longitude}")
    suspend fun getForecastHourlyLink(
        @Path("latitude") latitude: Double,
        @Path("longitude") longitude: Double
    ): PointResponse


    @GET
    suspend fun getForecastHourlyPeriods(
       @Url forecastHourly: String
    ): ForecastResponse


}