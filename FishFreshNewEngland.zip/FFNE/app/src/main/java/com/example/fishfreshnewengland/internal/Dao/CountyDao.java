package com.example.fishfreshnewengland.internal.Dao;

/**
 * @author Ashton Gabbeitt
 */
import androidx.room.Dao;
import androidx.room.Query;

import com.example.fishfreshnewengland.internal.entities.Counties;

import java.util.List;


/**
 * Data access object for counties
 */
@Dao
public interface CountyDao {

    @Query("SELECT * FROM counties")
    List<Counties> getAll();

    @Query("SELECT * FROM counties WHERE stateID = :id")
    List<Counties> getAllByState(int id);

    @Query("SELECT * FROM counties WHERE id = :id")
    Counties getById(int id);

}
