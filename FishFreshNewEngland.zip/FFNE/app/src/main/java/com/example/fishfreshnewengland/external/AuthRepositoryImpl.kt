package com.example.fishfreshnewengland.external


/**
 * @author Ashton Gabbeitt
 */
import io.github.jan.supabase.annotations.SupabaseInternal
import io.github.jan.supabase.auth.Auth
import io.github.jan.supabase.auth.OtpType
import io.github.jan.supabase.auth.parseFragmentAndImportSession
import io.github.jan.supabase.auth.providers.builtin.Email
import io.github.jan.supabase.auth.status.SessionStatus
import kotlinx.coroutines.flow.Flow
import io.github.jan.supabase.auth.user.UserInfo
import io.github.jan.supabase.exceptions.RestException
import javax.inject.Inject
import kotlin.time.ExperimentalTime

data class ResetPasswordProcessing (
    val confirmedUser : Boolean = true,
    val emailSent : Boolean = false,
    val errorMessage : String? = null
)

data class SignInProcessing(
    val confirmedUser : Boolean = true,
    val emailSent : Boolean = false,
    val success : Boolean = false,
    val errorMessage : String? = null
)

@OptIn(ExperimentalTime::class)
class AuthRepositoryImpl @Inject constructor(
    private val auth: Auth,
) : AuthRepository {

    override val sessionStatus: Flow<SessionStatus> = auth.sessionStatus


    override suspend fun signIn(email: String, password: String): SignInProcessing {

        val processingResult = SignInProcessing()

        return try {
            auth.signInWith(Email) {
                this.email = email
                this.password = password
            }
            processingResult.copy(success = true, errorMessage = null, confirmedUser = true, emailSent = false)


        } catch (e: RestException) {
            if (e.description?.contains("Email not confirmed", ignoreCase = true) == true) {
                val resend = resendEmailConfirmation(email)

                return if(resend){
                    processingResult.copy(success = false, errorMessage = null, confirmedUser = false, emailSent = true)
                } else{
                    processingResult.copy(success = false, errorMessage = "Email not confirmed and could not be resent", confirmedUser = false, emailSent = false)
                }

            } else {
                processingResult.copy(success = false, errorMessage = e.localizedMessage, confirmedUser = true)
            }
        }
    }


    override suspend fun signUp(email: String, password: String): Result<UserInfo> {
        return try {

            val user = auth.signUpWith(Email, redirectUrl = "ffne-app://confirm-email") {
                this.email = email
                this.password = password
            }
            if (user != null) {
                Result.success(user)
            } else {
                Result.failure(Exception("Sign up rejected"))
            }

        } catch (e: RestException) {
            Result.failure(Exception(e))
        }
    }


    override suspend fun resendEmailConfirmation(email: String): Boolean {
        return try {
            auth.resendEmail(
                type = OtpType.Email.SIGNUP,
                email = email,
                redirectUrl = "ffne-app://confirm-email",
            )
            true
        } catch (e: Exception) {
            false
        }
    }



    override suspend fun sendResetPasswordEmail(email: String): ResetPasswordProcessing {

        val emailProcessing = ResetPasswordProcessing()

        return try {

            auth.resetPasswordForEmail(email = email, redirectUrl = "ffne-app://reset-password")

            emailProcessing.copy(emailSent = true)
        } catch (e: RestException) {
            if (e.description?.contains("Email not confirmed", ignoreCase = true) == true) {
                emailProcessing.copy(confirmedUser = false)
                  val resendSuccess = resendEmailConfirmation(email)
                return if (resendSuccess) {
                    emailProcessing.copy(emailSent = true)
                } else {
                    emailProcessing.copy(errorMessage = "Email not confirmed and could not be resent")
                }
            } else {
                return emailProcessing.copy(errorMessage = e.localizedMessage)
            }
        }
    }

    override fun getCurrentUserId(): String? {
        return auth.currentUserOrNull()?.id
    }


    override suspend fun submitPasswordUpdate(newPassword: String): Boolean {
        return try {
            auth.updateUser {
                password = newPassword
            }
            true
        } catch (e: RestException) {
            false
        }
    }

    override suspend fun signOut() {
        auth.signOut()
    }


    @OptIn(SupabaseInternal::class)
    override suspend fun handleDeeplink(url: String): Boolean {
        return try {
            auth.parseFragmentAndImportSession(url)
            true

        } catch (e: Exception) {
            false
        }

    }
}


