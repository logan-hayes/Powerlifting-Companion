package com.example.fishfreshnewengland.internal.entities;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.Index;
import androidx.room.PrimaryKey;

@Entity(
        tableName = "accesses",
        foreignKeys = @ForeignKey(
                entity = WaterBodies.class,
                parentColumns = "id",
                childColumns = "waterbodyID",
                onDelete = ForeignKey.CASCADE
        ),
        indices = {@Index("id")}
)
public class AccessPoints {

    @PrimaryKey(autoGenerate = true)
    @NonNull
    public Integer id;

    @NonNull
    public String name;

    @NonNull
    public Integer waterbodyID;
    @NonNull
    public Double latitude;
    @NonNull
    public Double longitude;

    public AccessPoints(@NonNull Integer id, @NonNull String name, @NonNull Integer waterbodyID, @NonNull Double latitude, @NonNull Double longitude) {
        this.id = id;
        this.name = name;
        this.waterbodyID = waterbodyID;
        this.latitude = latitude;
        this.longitude = longitude;
    }
}