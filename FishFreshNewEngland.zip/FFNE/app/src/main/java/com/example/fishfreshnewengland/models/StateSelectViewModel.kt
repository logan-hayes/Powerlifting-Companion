package com.example.fishfreshnewengland.models


/**
 * @author Ashton Gabbeitt
 */
import androidx.compose.runtime.Immutable
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.fishfreshnewengland.internal.entities.States
import com.example.fishfreshnewengland.internal.repositories.StateRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject


/**
 * Data class for state list data retrieval
 * feeds state to state list view model
 */
@Immutable
data class StateUIState(
    val stateList: List<States> = emptyList(),
    val isLoading: Boolean = false,
    val errorMessage: String? = null,
)


/**
 * Connection between State Repository and State Select Layout
 * @param repository : StateRepository for API calls
 */
@HiltViewModel
class StateSelectViewModel @Inject constructor(
    private val repository: dagger.Lazy<StateRepository>,
) : ViewModel() {

    private val _uiState = MutableStateFlow(StateUIState())

    val uiState: StateFlow<StateUIState> = _uiState.asStateFlow()

    init {
        loadStates()
    }

    fun loadStates() {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, errorMessage = null) }
            try {
                val result = repository.get().fetchAllStates()
                _uiState.update { it.copy(stateList = result) }
            } catch (e: Exception) {
                _uiState.update { it.copy( errorMessage = "Failed to load states: ${e.localizedMessage}") }
            } finally {
                _uiState.update {
                    it.copy(isLoading = false)
                }
            }
        }
    }
}