package com.example.fishfreshnewengland.internal.repositories

import com.example.fishfreshnewengland.internal.entities.Counties
import com.example.fishfreshnewengland.internal.Dao.CountyDao
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import javax.inject.Inject

/**
 * Repository for fetching counties from the database
 */
class CountyRepository @Inject constructor(
    private val countyDao : CountyDao,
) {

    suspend fun fetchCountiesByState(stateID: Int): List<Counties> {
        return withContext(Dispatchers.IO) {
            countyDao.getAllByState(stateID)
        }
    }

    suspend fun fetchCountyByID(id: Int): Counties? {
        return withContext(Dispatchers.IO) {
            countyDao.getById(id)
        }
    }
}
