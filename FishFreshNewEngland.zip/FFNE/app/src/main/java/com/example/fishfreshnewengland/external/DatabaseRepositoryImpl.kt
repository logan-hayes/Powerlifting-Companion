package com.example.fishfreshnewengland.external

/**
 * @author Ashton Gabbeitt
 */

import com.example.fishfreshnewengland.entities.Comment
import com.example.fishfreshnewengland.entities.Post
import com.example.fishfreshnewengland.external.entities.FishExternal
import com.example.fishfreshnewengland.external.entities.ForumCommentCreation
import com.example.fishfreshnewengland.external.entities.ForumCommentExternal
import com.example.fishfreshnewengland.external.entities.ForumLikesExternal
import com.example.fishfreshnewengland.external.entities.ForumPostCreation
import com.example.fishfreshnewengland.external.entities.ForumPostExternal
import com.example.fishfreshnewengland.external.entities.ProfilePicResponse
import com.example.fishfreshnewengland.external.entities.UserProfileSettings
import com.example.fishfreshnewengland.external.entities.UserSetup
import com.example.fishfreshnewengland.external.entities.UsernameResponse
import io.github.jan.supabase.postgrest.Postgrest
import io.github.jan.supabase.postgrest.query.Columns
import java.time.LocalDateTime
import javax.inject.Inject

class DatabaseRepositoryImpl @Inject constructor(
    private val db: Postgrest,
) : DatabaseRepository {

    override suspend fun getAllFish(): List<FishExternal>? {
        return try {
            db.from("fish").select().decodeList<FishExternal>()
        } catch (e: Exception) {
            null
        }
    }

    override suspend fun getUserProfileSettings(userId: String): UserProfileSettings? {
        return try {
            db.from("user_profile_settings")
                .select { filter { eq("user_id", userId) } }
                .decodeSingleOrNull<UserProfileSettings>()
        } catch (e: Exception) {
            null
        }
    }

    override suspend fun saveUserProfileSettings(settings: UserProfileSettings): Boolean {
        return try {
            db.from("user_profile_settings").upsert(settings)
            true
        } catch (e: Exception) {
            false
        }
    }

    override suspend fun usernameValidator(username: String): Result<Boolean> {
        return try {
            val username = db.from("users")
                .select { filter { eq("username", username) } }
                .decodeSingleOrNull<UserSetup>() == null

            if (username) {
                Result.success(true)
            } else {
                Result.failure(Exception("Username taken"))
            }
        } catch (e: Exception) {
            Result.failure(Exception(e))
        }
    }

    override suspend fun submitUserSetup(
        userSetupData: UserSetup
    ): Result<UserSetup> {
        return try {
            val resultUser = db.from("users")
                .insert(userSetupData)
                {
                    select()
                }.decodeSingleOrNull<UserSetup>()

            if (resultUser != null) {
                Result.success(resultUser)
            } else {
                Result.failure(Exception("User setup rejected"))
            }
        } catch (e: Exception) {
            Result.failure(Exception(e))

        }
    }

    override suspend fun getCurrentUserName(userId: String): Result<UsernameResponse> {
        return try {
            val resultUsername = db.from("users")
                .select(columns = Columns.list("username")) { filter { eq("user_id", userId) } }
                .decodeSingleOrNull<UsernameResponse>()

            if (resultUsername != null) {
                Result.success(resultUsername)
            } else {
                Result.failure(Exception("Failed to fetch username"))
            }
        } catch (e: Exception) {
            Result.failure(Exception(e))

        }
    }

    override suspend fun getUserProfilePicPath(userId: String): Result<ProfilePicResponse> {
        return try {
            val resultPath = db.from("users")
                .select(columns = Columns.list("profile_picture")) {
                    filter {
                        eq(
                            "user_id",
                            userId
                        )
                    }
                }.decodeSingleOrNull<ProfilePicResponse>()

            if (resultPath != null) {
                Result.success(resultPath)
            } else {
                Result.failure(Exception("Failed to fetch path"))
            }
        } catch (e: Exception) {
            Result.failure(Exception(e))

        }
    }

    override suspend fun createForumPost(post: ForumPostCreation): Result<Boolean> {
        return try {
            db.from("posts").insert(post)
            Result.success(true)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun createForumComment(comment: ForumCommentCreation): Result<Boolean> {
        return try {
            db.from("comments").insert(comment)
            Result.success(true)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun likePost(postId: Long, userId: String): Result<Boolean> {
        return try {
            val like = ForumLikesExternal(
                userId = userId,
                postId = postId
            )
            db.from("likes").insert(like)
            Result.success(true)
        }catch (e: Exception) {
            Result.failure(e)
        }
    }


    override suspend fun likeComment(postId: Long, userId: String): Result<Boolean> {
        return Result.failure(Exception("Comment likes not implemented"))
    }

    override suspend fun getForumPosts(): Result<List<Post>> {
        return try {
            val rows = db.from("posts").select().decodeList<ForumPostExternal>()

            val posts = rows.map {row ->
                Post(
                    row.postId,
                    row.userId,
                    row.content,
                    row.contentImage,
                    LocalDateTime.now(),
                    0,
                    0,
                    null,
                    null
                )
            }

            Result.success(posts)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun getForumPost(postID: Long): Result<Post?> {
        return try {
            val row = db.from("posts").select {
                filter { eq("post_id", postID) }
            }
                .decodeSingleOrNull<ForumPostExternal>()

            val post = row?.let {
                Post(
                    it.postId,
                    it.userId,
                    it.content,
                    it.contentImage,
                    LocalDateTime.now(),
                    0,
                    0,
                    null,
                    null
                )
            }
            Result.success(post)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun getForumComments(postId: Long): Result<List<Comment>> {
        return try {
            val rows = db.from("comments")
                .select {
                    filter { eq("post_id", postId) }
                }
                .decodeList<ForumCommentExternal>()

            val comments = rows.map {row ->
                Comment(
                    row.commentId,
                    row.postId,
                    row.userId,
                    row.content,
                    LocalDateTime.now(),
                    0
                )
            }
            Result.success(comments)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

}