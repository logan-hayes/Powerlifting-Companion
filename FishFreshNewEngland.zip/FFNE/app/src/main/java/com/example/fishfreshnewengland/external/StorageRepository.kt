package com.example.fishfreshnewengland.external

/**
 * @author Ashton Gabbeitt
 */

interface StorageRepository {

    suspend fun getAvatarURL(path: String): Result<String>
    suspend fun uploadAvatar(path: String, file: ByteArray?): Result<String>
    suspend fun deleteAvatar(path: String): Boolean

}