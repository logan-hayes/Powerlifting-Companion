package com.example.fishfreshnewengland.layouts

/**
 * @author Ashton Gabbeitt
 */

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import com.example.fishfreshnewengland.components.EmailField
import com.example.fishfreshnewengland.components.PasswordField
import com.example.fishfreshnewengland.models.ResetPasswordUIState


@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ResetPasswordLayoutContent(
    uiState : ResetPasswordUIState,
    navigateToMain : () -> Unit,
    onEmailChanged : (String) -> Unit,
    onPasswordChanged : (String) -> Unit,
    onPasswordConfirmChanged : (String) -> Unit,
    resetPassword : () -> Unit,

    ) {

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Reset Password", textAlign = TextAlign.Center) },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = MaterialTheme.colorScheme.onPrimary,
                    navigationIconContentColor = MaterialTheme.colorScheme.onPrimary
                )
            )
        },
        content = { innerPadding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                ResetPWForm(
                    email = uiState.email,
                    password = uiState.password,
                    confirmPassword = uiState.confirmPassword,
                    onEmailChanged = { onEmailChanged(it) },
                    onPasswordChanged = { onPasswordChanged(it) },
                    onPasswordConfirmChanged = { onPasswordConfirmChanged(it) }
                )
                Button(
                    onClick = { resetPassword() },
                    enabled = uiState.formReady
                ){
                    Text(if (uiState.isLoading) "Submitting..." else "Reset Password")
                }
                if (uiState.errorMessage != null) {
                    Text(uiState.errorMessage, color = MaterialTheme.colorScheme.error)
                }

                LaunchedEffect(uiState.resetSuccess) {
                    if (uiState.resetSuccess) {
                        navigateToMain()
                    }
                }
            }
        }

    )

}

@Composable
fun ResetPWForm(
    email: String,
    password: String,
    confirmPassword: String,
    onEmailChanged: (String) -> Unit,
    onPasswordChanged: (String) -> Unit,
    onPasswordConfirmChanged: (String) -> Unit
) {

    Column {
        EmailField(
            email = email,
            onEmailChanged = onEmailChanged
        )
        PasswordField(
            label = "New Password",
            value = password,
            onValueChanged = onPasswordChanged
        )
        PasswordField(
            label = "Confirm Password",
            value = confirmPassword,
            onValueChanged = onPasswordConfirmChanged
        )
    }
}
