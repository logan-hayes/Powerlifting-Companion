package com.example.fishfreshnewengland.internal.Dao;

import androidx.room.Dao;
import androidx.room.Query;

import com.example.fishfreshnewengland.internal.entities.WaterBodies;

import java.util.List;

@Dao
public interface WaterBodyDao {

    @Query("SELECT * FROM waterbodies")
    List<WaterBodies> getAll();

    @Query("SELECT * FROM waterbodies WHERE id = :id")
    WaterBodies getById(Integer id);


    @Query("SELECT * FROM waterbodies WHERE townID = :id")
    List<WaterBodies> getAllByTown(Integer id);
}
