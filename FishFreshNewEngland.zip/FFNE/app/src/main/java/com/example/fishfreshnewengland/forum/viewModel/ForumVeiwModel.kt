package com.example.fishfreshnewengland.forum.viewmodel

import androidx.compose.runtime.Immutable
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.fishfreshnewengland.entities.CatchInfo
import com.example.fishfreshnewengland.forum.data.ForumRepository
import com.example.fishfreshnewengland.entities.Comment
import com.example.fishfreshnewengland.forum.models.FeedFilteringMode
import com.example.fishfreshnewengland.entities.Post
import com.example.fishfreshnewengland.entities.PostLocation
import com.example.fishfreshnewengland.external.AuthRepository
import com.example.fishfreshnewengland.external.AuthRepositoryImpl
import com.example.fishfreshnewengland.external.DatabaseRepository
import com.example.fishfreshnewengland.external.entities.ForumCommentCreation
import com.example.fishfreshnewengland.external.entities.ForumCommentExternal
import com.example.fishfreshnewengland.external.entities.ForumPostCreation
import com.example.fishfreshnewengland.forum.data.InMemoryForumRepository
import com.example.fishfreshnewengland.internal.entities.Fish
import com.example.fishfreshnewengland.internal.entities.AccessPoints
import com.example.fishfreshnewengland.internal.repositories.AccessPointRepository
import com.example.fishfreshnewengland.internal.repositories.FishRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.Collections.emptyList
import javax.inject.Inject

@Immutable
data class ForumUIState(
    val posts: List<Post> = emptyList(),
    val selectedPost: Post? = null,
    val comments: List<Comment> = emptyList(),
    val isPosting: Boolean = false,
    val errorMessage: String? = null,
    val sortMode: FeedFilteringMode = FeedFilteringMode.RECENT)

@HiltViewModel
class ForumViewModel @Inject constructor(
    private val fishRepository: FishRepository,
    private val accessPointRepository: AccessPointRepository,
    private val authRepository: AuthRepository,
    private val databaseRepository: DatabaseRepository,


    ) : ViewModel() {

    private val _UIState = MutableStateFlow(ForumUIState())
    val UIState: StateFlow<ForumUIState> = _UIState.asStateFlow()

    // posts for the feed view
    private val _posts = MutableStateFlow<List<Post>>(emptyList())
    val posts: StateFlow<List<Post>> = _posts.asStateFlow()

    private val _comments = MutableStateFlow<List<Comment>>(emptyList())
    val comments: StateFlow<List<Comment>> = _comments.asStateFlow()

    private val fishSpecies = MutableStateFlow<List<Fish>>(emptyList())
    val fishOptions: StateFlow<List<Fish>> = fishSpecies.asStateFlow()

    private val locations = MutableStateFlow<List<AccessPoints>>(emptyList())
    val locationOptions = locations.asStateFlow()

    // Track current post id
    private val selectedPostId = MutableStateFlow<Long?>(null)

    private val _usernames = MutableStateFlow<Map<String, String>>(emptyMap())
    val usernames: StateFlow<Map<String, String>> = _usernames.asStateFlow()

    fun loadComments(postId: Long) {
        viewModelScope.launch{
            val result = databaseRepository.getForumComments(postId)

            if (result.isSuccess) {
                _comments.value = result.getOrNull().orEmpty()
            }else{
                _UIState.value = _UIState.value.copy(
                    errorMessage = result.exceptionOrNull()?.message ?: "unable to load comments"
                )
            }
        }
    }

    fun loadUserName(userID: String) {
        viewModelScope.launch {
            val result = databaseRepository.getCurrentUserName(userID)
            val currentUserName = result.getOrNull()?.username ?: "Not available"
            _usernames.value = _usernames.value + (userID to currentUserName)

            _usernames.value = _usernames.value + (userID to currentUserName)
        }
    }

    fun loadFishSpecies() {
        viewModelScope.launch {
            try {
                fishSpecies.value = fishRepository.fetchAllFish()
            } catch (e: Exception) {
                _UIState.value = _UIState.value.copy(
                    errorMessage = "Unable to load fish data. ${e.message}"
                )
            }
        }
    }

    init {
        loadAccessPoints()
        loadFishSpecies()
        loadPosts()
    }

    fun loadAccessPoints() {
        viewModelScope.launch {
            try {
                locations.value = accessPointRepository.fetchAllAccessPoints()
            } catch (e: Exception) {
                _UIState.value = _UIState.value.copy(
                    errorMessage = "Unable to load fish data. ${e.message}"
                )
            }
        }
    }


    fun selectPost(postId: Long) {
        selectedPostId.value = postId
        loadComments(postId)
    }

    fun setSortMode(mode: FeedFilteringMode) {
        _UIState.value = UIState.value.copy(sortMode = mode)
        loadPosts()
    }

    // Select post object
    val selectedPost: StateFlow<Post?> =
        combine(posts, selectedPostId) { postsList, id ->
            if (id == null) null else postsList.firstOrNull { it.getPostID() == id }
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)


    fun createPost(
        content: String,
        catchInfo: CatchInfo?,
        postLocation: PostLocation?
    ) {

        val cleaned = content.trim()


        if (cleaned.isBlank()) {
            _UIState.value = _UIState.value.copy(
                errorMessage = "Cannot leave blank"
            )

            return
        }
        if (cleaned.length > 500) {
            _UIState.value = _UIState.value.copy(
                errorMessage = "Text must be 500 characters or less"
            )
            return
        }

        _UIState.value = _UIState.value.copy(errorMessage = null)

        viewModelScope.launch {
            val currentUserId = authRepository.getCurrentUserId()

            if (currentUserId == null) {
                _UIState.value = _UIState.value.copy(
                    errorMessage = "User sign-in required"
                )

                return@launch
            }

            val postCreation = ForumPostCreation(
                userId = currentUserId,
                content = cleaned,
                contentImage = null,
                locationId = postLocation?.waterBodyID)

            val result = databaseRepository.createForumPost(postCreation)

            if (result.isFailure) {
                _UIState.value = _UIState.value.copy(
                    errorMessage = result.exceptionOrNull()?.message ?: "Post Creation Failed"
                )
            }else{
                loadPosts()
            }
        }
    }

    fun createComment(postId: Long, content: String) {

        val cleaned = content.trim()

        if (cleaned.isBlank()) {
            _UIState.value = _UIState.value.copy(
                errorMessage = "Cannot leave blank"
            )
            return
        }
        if (cleaned.length > 300) {
            _UIState.value = _UIState.value.copy(
                errorMessage = "Text must be 500 characters or less"
            )
            return
        }

        _UIState.value = _UIState.value.copy(errorMessage = null)

        viewModelScope.launch {
            val currentUserId = authRepository.getCurrentUserId()

            if (currentUserId == null) {
                _UIState.value = _UIState.value.copy(
                    errorMessage = "Sign in required"
                )
                return@launch
            }

            val commentCreation = ForumCommentCreation(
                postID = postId,
                userId = currentUserId,
                content = cleaned
            )

            val result = databaseRepository.createForumComment(commentCreation)

            if (result.isFailure) {
                _UIState.value = _UIState.value.copy(
                    errorMessage = result.exceptionOrNull()?.message
                        ?: "Comment Creation Failed"
                )
            }else {
                loadComments(postId)
                loadPosts()
            }
        }

    }

        fun likePost(postId: Long) {
            viewModelScope.launch {
                val currentUserId = authRepository.getCurrentUserId()

                if(currentUserId == null) {
                    _UIState.value = _UIState.value.copy(
                        errorMessage = "Sign in required"
                    )
                    return@launch
                }

                val result = databaseRepository.likePost(postId, currentUserId)

                if (result.isFailure) {
                    _UIState.value = _UIState.value.copy(
                        errorMessage = result.exceptionOrNull()?.message
                            ?: "Action Failed")
                }
            }
        }

        fun likeComment(commentId: Long) {
            viewModelScope.launch {
                val currentUserId = authRepository.getCurrentUserId()

                if(currentUserId == null) {
                    _UIState.value = _UIState.value.copy(
                        errorMessage = "Sign in required"
                    )
                    return@launch
                }

                val result = databaseRepository.likeComment(commentId, currentUserId)

                if (result.isFailure) {
                    _UIState.value = _UIState.value.copy(
                        errorMessage = result.exceptionOrNull()?.message
                            ?: "Action Failed")
                }
            }
        }

    fun loadPosts() {
        viewModelScope.launch {
            val result = databaseRepository.getForumPosts()

            if(result.isSuccess){
                val loadedPosts = result.getOrNull().orEmpty()

                _posts.value = when (UIState.value.sortMode){
                    FeedFilteringMode.RECENT ->{
                        loadedPosts.sortedByDescending {it.getTimeStamp()}
                    }
                    FeedFilteringMode.ENGAGEMENT -> {
                        loadedPosts.sortedByDescending {it.getLikes() + it.getCommentCount()}
                    }
                    FeedFilteringMode.USER -> {
                        loadedPosts.sortedByDescending {it.getLikes() + it.getCommentCount()}
                    }
                }

                _posts.value.forEach { post ->
                    loadUserName(post.getAuthorID())
                }

            } else {
                _UIState.value = _UIState.value.copy(
                    errorMessage = result.exceptionOrNull()?.message ?: "unable to load posts"
                )
            }
        }
    }
    }