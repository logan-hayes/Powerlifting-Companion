package com.example.fishfreshnewengland.external.entities

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class ForumPostExternal(
    @SerialName("post_id")
    val postId: Long,

    @SerialName("user_id")
    val userId: String,

    val content: String,

    @SerialName("location_id")
    val locationId: Int? = null,

    @SerialName("content_image")
    val contentImage: String? = null,

    @SerialName("created_at")
    val createdAt: String? = null,

    @SerialName("updated_at")
    val updatedAt: String? = null


)
