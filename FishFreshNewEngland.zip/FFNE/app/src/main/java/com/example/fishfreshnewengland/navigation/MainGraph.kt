package com.example.fishfreshnewengland.navigation

/**
 * @author Ashton Gabbeitt
 */
import androidx.activity.ComponentActivity
import androidx.activity.compose.LocalActivity
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import androidx.navigation.NavGraphBuilder
import androidx.navigation.compose.composable
import androidx.navigation.navigation
import androidx.navigation.toRoute
import com.example.fishfreshnewengland.forum.ui.ForumPostCommentScreen
import com.example.fishfreshnewengland.forum.data.InMemoryForumRepository
import com.example.fishfreshnewengland.forum.ui.ForumFeedScreen
import com.example.fishfreshnewengland.forum.viewmodel.ForumViewModel
import com.example.fishfreshnewengland.layouts.*
import com.example.fishfreshnewengland.models.*
import kotlin.reflect.typeOf

@OptIn(ExperimentalMaterial3Api::class)
fun NavGraphBuilder.mainGraph(navController: NavController) {
    navigation<MainGraph>(startDestination = MainRoute) {

        composable<MainRoute> { it ->
            val parentEntry = remember(it) {
                navController.getBackStackEntry<MainGraph>()
            }
            val sharedDataViewModel: SharedDataViewModel = hiltViewModel(parentEntry)
            val sharedData by sharedDataViewModel.sharedData.collectAsStateWithLifecycle()

            val activity = LocalActivity.current as ComponentActivity
            val mainLayoutViewModel: MainLayoutViewModel = hiltViewModel(activity)
            val uiState by mainLayoutViewModel.uiState.collectAsStateWithLifecycle()
            MainLayoutContent(
                sharedData.username,
                sharedData.error,
                sharedData.profilePicURL,
                uiState,
                onNavigateToSignIn = { navController.navigate(AuthGraph) {
                    popUpTo<MainGraph> { inclusive = true }
                } },
                onNavigateToRoute = { navController.navigate(it)} ,
                signOut = { mainLayoutViewModel.signOut()}
            )
        }

        composable<MapScreenRoute> {

            val mapViewModel: MapViewModel = hiltViewModel()
            val uiState by mapViewModel.uiState.collectAsStateWithLifecycle()
            MapLayoutContent(navController, uiState, onMapLoaded = { mapViewModel.setMapReady(true) }, userLocation = { mapViewModel.userLocation() }, getCloseAccesses = { mapViewModel.getCloseAccesses() }, getAccessData = { mapViewModel.getAccessData(it)})
        }

        composable<InfoCatalogMainRoute> {
            InfoCatalogMainLayoutContent(navController)
        }

        composable<ForumFeedRoute> {
            val forumViewModel: ForumViewModel = hiltViewModel()
            ForumFeedScreen(viewModel = forumViewModel, navController)
        }

        composable<ForumPostCommentRoute> { backStackEntry ->
            val route = backStackEntry.toRoute<ForumPostCommentRoute>()
            val forumViewModel: ForumViewModel = hiltViewModel()

            LaunchedEffect(route.postId) {
                forumViewModel.selectPost(route.postId)
            }

            ForumPostCommentScreen(
                viewModel = forumViewModel,
                navController = navController
            )
        }

        composable<InfoCatalogStateSelectRoute> {
            val stateViewModel: StateSelectViewModel = hiltViewModel()
            val uiState by stateViewModel.uiState.collectAsStateWithLifecycle()
            InfoCatalogStateSelectLayoutContent(navController, uiState)
        }

        composable<InfoCatalogFishSelectRoute> {

            val fishViewModel: FishSelectViewModel = hiltViewModel()
            val uiState by fishViewModel.uiState.collectAsStateWithLifecycle()

            LaunchedEffect(Unit) { fishViewModel.fetchFishData() }
            InfoCatalogFishSelectLayoutContent(navController, uiState)
        }

        composable<CountySelectRoute> {

            val countyViewModel: CountySelectViewModel = hiltViewModel()
            val uiState by countyViewModel.uiState.collectAsStateWithLifecycle()
            InfoCatalogCountySelectLayoutContent(navController, uiState)
        }

        composable<ForecastRoute>(
            typeMap = mapOf(typeOf<Double>() to DoubleNavType)
        ) {

            val forecastViewModel: ForecastViewModel = hiltViewModel()
            val uiState by forecastViewModel.uiState.collectAsStateWithLifecycle()
            DisplayForecastLayoutContent(uiState, navigateBackStack = { navController.popBackStack() })
        }


        composable<UserSettingsRoute> {
            val viewModel: UserSettingsViewModel = hiltViewModel()
            val uiState by viewModel.uiState.collectAsStateWithLifecycle()

            LaunchedEffect(Unit) {
                viewModel.loadSettings("")
            }

            UserSettingsLayoutContent(
                uiState = uiState,
                onSaveSettings = { uiSettings, profileSettings ->
                    viewModel.saveSettings(uiSettings, profileSettings)
                },
                onNavigateBack = { navController.popBackStack() }
            )
        }


    }
}