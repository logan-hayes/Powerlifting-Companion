package com.example.fishfreshnewengland.entities;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "user_settings")
public class UserSettings {

    @PrimaryKey
    public int id;

    public String preferredState;
    public String preferredFish;
    public boolean notificationsEnabled;


    public UserSettings(int id,
                        String preferredState,
                        String preferredFish,
                        boolean notificationsEnabled) {
        this.id = id;
        this.preferredState = preferredState;
        this.preferredFish = preferredFish;
        this.notificationsEnabled = notificationsEnabled;
    }
}