package com.example.fishfreshnewengland.internal.entities;

/**
 * @author Ashton Gabbeitt
 */
import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.PrimaryKey;

@Entity(
        tableName = "counties",
        foreignKeys = @ForeignKey(
                entity = States.class,
                parentColumns = "id",
                childColumns = "stateID",
                onDelete = ForeignKey.CASCADE
        )
)
public class Counties {
    @PrimaryKey(autoGenerate = true)
    @NonNull
    public Integer id;


    @NonNull
    public String name;

    @NonNull
    public Integer stateID;

    public Counties(@NonNull Integer id, @NonNull String name, @NonNull Integer stateID) {
        this.id = id;
        this.name = name;
        this.stateID = stateID;
    }
}


