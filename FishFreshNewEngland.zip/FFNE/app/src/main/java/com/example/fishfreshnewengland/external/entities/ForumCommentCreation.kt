package com.example.fishfreshnewengland.external.entities

import com.example.fishfreshnewengland.entities.CatchInfo
import com.example.fishfreshnewengland.entities.PostLocation
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class ForumCommentCreation(
    @SerialName("post_id")
    val postID: Long,
    @SerialName("author_id")
    val userId: String,
    val content: String,
)