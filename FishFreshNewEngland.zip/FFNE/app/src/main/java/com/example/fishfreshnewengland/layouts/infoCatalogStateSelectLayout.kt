package com.example.fishfreshnewengland.layouts

/**
 * @author Ashton Gabbeitt
 */
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.fishfreshnewengland.navigation.CountySelectRoute
import com.example.fishfreshnewengland.internal.entities.States
import com.example.fishfreshnewengland.models.StateUIState


/**
 * Display layout for state list in information catalog. Routes to county list in information catalog.
 * @param navController: NavHostController for navigation
 * @param uiState: StateUIState containing state view data from view model
 */
@ExperimentalMaterial3Api
@Composable
fun InfoCatalogStateSelectLayoutContent(
    navController: NavController,
    uiState : StateUIState
) {


    Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("State List") },
                    navigationIcon = {
                        IconButton(onClick = { navController.popBackStack() }) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, "Go Back")
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.primary,
                        titleContentColor = MaterialTheme.colorScheme.onPrimary,
                        navigationIconContentColor = MaterialTheme.colorScheme.onPrimary
                    )
                )
            },
            content = { innerPadding ->
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                ) {
                    if (uiState.isLoading) {
                        CircularProgressIndicator(modifier = Modifier.align(Alignment.Center))
                    } else if (uiState.errorMessage != null && uiState.errorMessage.isNotEmpty()) {
                        Text(uiState.errorMessage, modifier = Modifier.align(Alignment.Center), color = MaterialTheme.colorScheme.error)
                    } else {
                        StateList(uiState.stateList, navController)
                    }
                }
            },
        )
    }


@Composable
fun StateRow(state: States,  onItemClick: (Int) -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clickable {onItemClick(state.id) }
                .padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
                )
    {
        Text(text = state.name, style = MaterialTheme.typography.titleMedium)
    }
}

@Composable
fun StateList(states: List<States>, navController: NavController) {
    // THE LIST
    LazyColumn(modifier = Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally) {
        items(states) { state ->
            StateRow(state) {
                navController.navigate(CountySelectRoute(state.id))
            }
            HorizontalDivider()
        }
    }
}