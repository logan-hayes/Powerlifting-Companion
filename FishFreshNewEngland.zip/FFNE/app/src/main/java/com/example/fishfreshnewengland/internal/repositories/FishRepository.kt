package com.example.fishfreshnewengland.internal.repositories


import com.example.fishfreshnewengland.internal.entities.Fish
import com.example.fishfreshnewengland.internal.Dao.FishDao
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import javax.inject.Inject

class FishRepository @Inject constructor(
    private val fishDao : FishDao
) {
    suspend fun fetchAllFish(): List<Fish> {
        return withContext(Dispatchers.IO) {
            fishDao.getAll()
        }
    }
}