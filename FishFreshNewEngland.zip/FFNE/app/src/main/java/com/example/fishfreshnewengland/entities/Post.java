package com.example.fishfreshnewengland.entities;

/**
 * @author Logan Hayes
 * */

import java.time.LocalDateTime;


public class Post {

    private long postID;
    private String authorID;
    private String content;
    private String imageURL;
    private LocalDateTime timeStamp;
    private int likes;
    private int commentCount;
    private CatchInfo catchInfo;
    private PostLocation postLocation;


    public Post(long postId,
                String authorId,
                String content,
                String imageURL,
                LocalDateTime timestamp,
                int likes,
                int commentCount,
                CatchInfo catchInfo,
                PostLocation postLocation)


        {
        this.postID = postId;
        this.authorID = authorId;
        this.content = content;
        this.timeStamp = timestamp;
        this.imageURL = imageURL;
        this.likes = likes;
        this.commentCount = commentCount;
        this.catchInfo = catchInfo;
        this.postLocation = postLocation;
    }

    //Secondary constructor for locally stored posts
    public Post(String authorID, String content){
        this.postID = 0;
        this.authorID = authorID;
        this.content = content;
        this.timeStamp = LocalDateTime.now();
        this.imageURL = null;
        this.likes = 0;
        this.commentCount = 0;
        this.catchInfo = null;
        this.postLocation = null;
    }

    public long getPostID(){
        return postID;
    }

    public void setPostID(long postID){
        this.postID = postID;
    }

    public String getAuthorID(){
        return authorID;
    }

    public void setAuthorID(String authorID){
        this.authorID = authorID;
    }

    public String getContent(){
        return content;
    }

    public void setContent(){
        this.content = content;
    }

    public LocalDateTime getTimeStamp(){
        return timeStamp;
    }

    public void setTimeStamp(LocalDateTime timeStamp){
        this.timeStamp = timeStamp;
    }

    public String getImageURL(){
        return imageURL;
    }

    public void setImageURL(String ImageURL){
        this.imageURL = imageURL;
    }

    public int getLikes(){
        return likes;
    }

    public void setLikes(String Likes){
        this.likes = likes;
    }

    public int getCommentCount(){
        return commentCount;
    }

    public void setCommentCount(int commentCount) {
        this.commentCount = commentCount;
    }

    public void incrementLikes(){
        this.likes++;
    }

    public void decrementLikes(){
        if(this.likes > 0) this.likes--;
    }

    public void incrementCommentCount(){
        this.commentCount++;
    }

    public CatchInfo getCatchInfo(){
        return catchInfo;
    }

    public void setCatchInfo(CatchInfo catchInfo){
        this.catchInfo = catchInfo;
    }

    public PostLocation getPostLocation(){
        return postLocation;
    }

    public void setPostLocation(PostLocation postLocation){
        this.postLocation = postLocation;
    }

}
