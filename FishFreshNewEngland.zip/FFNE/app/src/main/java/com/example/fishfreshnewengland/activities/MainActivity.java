package com.example.fishfreshnewengland.activities;

/**
 * @author Ashton Gabbeitt
 */
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;


import androidx.activity.ComponentActivity;
import androidx.annotation.NonNull;
import androidx.lifecycle.ViewModelProvider;


import com.example.fishfreshnewengland.models.MainLayoutViewModel;
import com.example.fishfreshnewengland.navigation.AppNavigationKt;
import dagger.hilt.android.AndroidEntryPoint;

/**
 * Main activity for the app.
 * Starts app navigator which will handle navigation/data sharing between screens.
 */
@AndroidEntryPoint
public class MainActivity extends ComponentActivity {

    private MainLayoutViewModel mainViewModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mainViewModel = new ViewModelProvider(this).get(MainLayoutViewModel.class);

        Uri data = getIntent().getData();
        String initialLink = (data != null) ? data.toString() : null;

        AppNavigationKt.startApp(this, initialLink);
    }

    @Override
    protected void onNewIntent(@NonNull Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);

        Uri data = intent.getData();
        if (data != null && mainViewModel != null) {
            mainViewModel.handleDeepLink(data.toString());
        }
    }
}