package com.example.fishfreshnewengland.models

/**
 * @author Ashton Gabbeitt
 */

import android.util.Log
import androidx.compose.runtime.Immutable
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.navigation.toRoute
import com.example.fishfreshnewengland.navigation.DoubleNavType
import com.example.fishfreshnewengland.entities.ForecastPeriod
import com.example.fishfreshnewengland.navigation.ForecastRoute
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import com.example.fishfreshnewengland.external.NOAARepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.reflect.typeOf


/**
 * Data class for forecast data retrieval
 * feeds state to forecast view model
 * @param forecastPeriods: List of forecast periods
 * @param isLoading: Boolean indicating if data is loading
 * @param errorMessage: String containing error message
 */
@Immutable
data class ForecastUIState(
    val forecastPeriods: List<ForecastPeriod> = emptyList(),
    val isLoading: Boolean = false,
    val errorMessage: String? = null
)


/**
 * ViewModel for forecast data retrieval
 * @param repository: NOAARepository for API calls
 * @param savedStateHandle: SavedStateHandle for navigation
 */
@HiltViewModel
class ForecastViewModel @Inject constructor(
    private val repository: dagger.Lazy<NOAARepository>,
    savedStateHandle: SavedStateHandle
) : ViewModel() {

    private val route = savedStateHandle.toRoute<ForecastRoute>(
        typeMap = mapOf(typeOf<Double>() to DoubleNavType)
    )
    private val _uiState = MutableStateFlow(ForecastUIState())
    val uiState: StateFlow<ForecastUIState> = _uiState.asStateFlow()

    init {
        fetchForecastData(route.latitude, route.longitude)
    }

    fun fetchForecastData(latitude: Double, longitude: Double) {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, errorMessage = null) }

            try {
                val forecastPeriods = withContext(Dispatchers.IO) {

                    val hourlyLink = repository.get().getForecastHourlyLink(latitude, longitude)
                    if (hourlyLink != null) {
                        repository.get().getForecastHourlyPeriods(hourlyLink)
                    }
                    else {
                        emptyList()
                    }
                }

                if (forecastPeriods != null) {
                    _uiState.update {
                        it.copy(forecastPeriods = forecastPeriods, isLoading = false)
                    }
                }


            } catch (e: Exception) {
                _uiState.update {
                    it.copy(
                        isLoading = false,
                        errorMessage = "Could not load forecast hourly link."
                    )
                }

            }
        }
    }
}