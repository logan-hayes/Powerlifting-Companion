package com.example.fishfreshnewengland.internal;

/**
 * @author Ashton Gabbeitt
 */
import android.content.Context;
import androidx.room.Room;

import com.example.fishfreshnewengland.internal.Dao.AccessPointDao;
import com.example.fishfreshnewengland.internal.Dao.CountyDao;
import com.example.fishfreshnewengland.internal.Dao.FishDao;
import com.example.fishfreshnewengland.internal.Dao.FishWaterBodiesDao;
import com.example.fishfreshnewengland.internal.Dao.StateDao;
import com.example.fishfreshnewengland.internal.Dao.TownDao;
import com.example.fishfreshnewengland.internal.Dao.UserUISettingsDao;
import com.example.fishfreshnewengland.internal.Dao.WaterBodyDao;

import dagger.Module;
import dagger.Provides;
import dagger.hilt.InstallIn;
import dagger.hilt.android.qualifiers.ApplicationContext;
import dagger.hilt.components.SingletonComponent;
import javax.inject.Singleton;

@Module
@InstallIn(SingletonComponent.class)
public class DatabaseModule {

    @Provides
    @Singleton
    public static AppDatabase provideAppDatabase(@ApplicationContext Context context) {
        return Room.databaseBuilder(
                        context.getApplicationContext(),
                        AppDatabase.class,
                        "ffne_database.db"
                )
                .createFromAsset("database/FFNE_Client.db")
                .build();
    }

    @Provides
    public static UserUISettingsDao UserUISettingsDao(AppDatabase db) {
        return db.userUISettingsDao();
    }


    @Provides
    public static StateDao StateDao(AppDatabase db) {
        return db.stateDao();
    }


    @Provides
    public static CountyDao CountyDao(AppDatabase db) {
        return db.countyDao();
    }


    @Provides
    public static TownDao TownDao(AppDatabase db) {
        return db.townDao();
    }

    @Provides
    public static AccessPointDao AccessPointDao(AppDatabase db) {
        return db.accessPointDao();
    }

    @Provides
    public static FishDao FishDao(AppDatabase db) {
        return db.fishDao();
    }

    @Provides
    public static FishWaterBodiesDao FishWaterBodiesDao(AppDatabase db) {
        return db.fishWaterBodiesDao();
    }

    @Provides
    public static WaterBodyDao WaterBodyDao(AppDatabase db) {
        return db.waterBodyDao();
    }

}