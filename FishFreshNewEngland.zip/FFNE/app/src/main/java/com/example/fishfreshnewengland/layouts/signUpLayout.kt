package com.example.fishfreshnewengland.layouts

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import com.example.fishfreshnewengland.components.EmailField
import com.example.fishfreshnewengland.components.PasswordField
import com.example.fishfreshnewengland.models.SignUpViewModel
import com.example.fishfreshnewengland.navigation.SignInFormRoute

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SignUpLayoutContent(
    navController: NavController,
    viewModel: SignUpViewModel
) {

    val uiState by viewModel.uiState.collectAsStateWithLifecycle()

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = { Text("Fish Fresh New England", textAlign = TextAlign.Center) },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = MaterialTheme.colorScheme.onPrimary,
                    navigationIconContentColor = MaterialTheme.colorScheme.onPrimary
                )
            )
        },
        content = { innerPadding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    "Sign Up",
                    textAlign = TextAlign.Center,
                    style = MaterialTheme.typography.headlineLarge,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(top = 30.dp, bottom = 16.dp)
                )
                SignUpForm(
                    email = uiState.email,
                    password = uiState.password,
                    confirmPassword = uiState.confirmPassword,
                    onEmailChanged = { viewModel.onEmailChanged(it) },
                    onPasswordChanged = { viewModel.onPasswordChanged(it) },
                    onPasswordConfirmChanged = { viewModel.onPasswordConfirmChanged(it) }
                )
                Button(
                    onClick = { viewModel.signUpWithEmail() },
                    enabled = uiState.formReady
                ){
                    Text(if (uiState.isLoading) "Submitting..." else "Submit")
                }
                if (uiState.errorMessage != null) {
                    Text(uiState.errorMessage!!, color = MaterialTheme.colorScheme.error)
                }

                LaunchedEffect(uiState.createSuccess) {
                    if (uiState.createSuccess) {
                        navController.navigate(SignInFormRoute(needConfirm = true))
                    }
                }
            }
        }

    )

}

@Composable
fun SignUpForm(
    email: String,
    password: String,
    confirmPassword: String,
    onEmailChanged: (String) -> Unit,
    onPasswordChanged: (String) -> Unit,
    onPasswordConfirmChanged: (String) -> Unit
) {

    Column (
        modifier = Modifier.padding(horizontal = 16.dp),
    ){
        EmailField(
            email = email,
            onEmailChanged = onEmailChanged
        )
        PasswordField(
            label = "Password",
            value = password,
            onValueChanged = onPasswordChanged
        )
        PasswordField(
            label = "Confirm Password",
            value = confirmPassword,
            onValueChanged = onPasswordConfirmChanged
        )
    }
}