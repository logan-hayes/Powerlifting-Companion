package com.example.fishfreshnewengland.entities;

/**
 * @author Ashton Gabbeitt
 */
import java.time.LocalDateTime;

public class Badge {

    private BADGETYPE badgeType;
    private String criteria;
    private LocalDateTime dateEarned;
    private User awardedBy;

    public Badge(BADGETYPE badgeType, String criteria, StandardUser awardedBy) {
        this.badgeType = badgeType;
        this.criteria = criteria;
        this.awardedBy = awardedBy;
        this.dateEarned = LocalDateTime.now();
    }

    public BADGETYPE getBadgeType() {
        return badgeType;
    }

    public String getCriteria() {
        return criteria;
    }

    public LocalDateTime getDateEarned() {
        return dateEarned;
    }

}
