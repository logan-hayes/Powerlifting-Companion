package com.example.fishfreshnewengland.components


import androidx.compose.foundation.layout.Column
import androidx.compose.material3.BasicAlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun InformationDialog(
    onDismiss: () -> Unit,
    onConfirm: () -> Unit,
    dialogMessage: String,
    confirmButtonText: String,
    dismissButtonText: String? = null,
) {

    BasicAlertDialog(
        onDismissRequest = onDismiss,
    ) {
        Column {
            Text(dialogMessage)
            Button(onClick = { onConfirm() }) {
                Text(confirmButtonText)
            }
        }
    }
}