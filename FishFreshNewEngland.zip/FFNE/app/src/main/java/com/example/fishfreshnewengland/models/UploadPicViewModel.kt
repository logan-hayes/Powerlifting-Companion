package com.example.fishfreshnewengland.models

import android.net.Uri
import androidx.compose.runtime.Immutable
import com.example.fishfreshnewengland.external.StorageRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.update
import javax.inject.Inject
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.fishfreshnewengland.external.AuthRepository
import com.example.fishfreshnewengland.processors.UriConverter
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

@Immutable
data class UploadPicUIState(
    val isLoading : Boolean = false,
    val avatarURI : Uri? = null,
    val avatarUploaded : Boolean = false,
    val avatarURL : String? = null,
    val createSuccess : Boolean = false,
    val errorMessage : String? = null
)

@HiltViewModel
class UploadPicViewModel @Inject constructor(
    private val authRepository: AuthRepository,
    private val storageRepository: StorageRepository,
    private val uriConverter: UriConverter
) : ViewModel() {

    private var _uiState = MutableStateFlow(UploadPicUIState())
    val uiState = _uiState.asStateFlow()

    fun onAvatarChanged(uri: Uri) {
        _uiState.update {
            it.copy(
                avatarURI = uri
            )
        }
    }

    suspend fun uploadAvatar(uri: Uri) {
        try {
            val bytes = uriConverter.getBytesFromUri(uri)

            if (bytes == null) {
                _uiState.update {
                    it.copy(
                        errorMessage = "Issue converting image to bytes, please try again.",
                        isLoading = false
                    )

                }

            }
            else {

                val path = "${authRepository.getCurrentUserId()}"
                val avatarURL = storageRepository.uploadAvatar(path, bytes)

                if (avatarURL.isSuccess) {
                    _uiState.update {
                        it.copy(
                            avatarUploaded = true,
                            avatarURL = avatarURL.getOrNull(),
                            createSuccess = true,
                            errorMessage = null
                        )
                    }
                } else {
                    _uiState.update {
                        it.copy(
                            errorMessage = "Issue uploading avatar, please try again. ${avatarURL.exceptionOrNull()}",
                            isLoading = false,
                            createSuccess = false
                        )
                    }
                }
            }
        } catch (e: Exception) {
            _uiState.update {
                it.copy(
                    errorMessage = e.localizedMessage,
                    isLoading = false,
                    createSuccess = false
                )
            }

        }
    }

    fun submitUpload(){
        _uiState.update { it.copy(isLoading = true, errorMessage = null) }

        viewModelScope.launch {

            val avatarURI = _uiState.value.avatarURI
            if(avatarURI != null) {
                uploadAvatar(avatarURI)
            }

        }

    }

}