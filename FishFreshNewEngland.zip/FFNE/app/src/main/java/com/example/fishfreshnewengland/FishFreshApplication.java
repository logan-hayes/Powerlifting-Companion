package com.example.fishfreshnewengland;

/**
 * @author Ashton Gabbeitt
 */
import android.app.Application;
import android.content.Context;
import android.util.Log;

import androidx.annotation.NonNull;

import com.google.android.gms.maps.MapsInitializer;

import coil3.ImageLoader;
import coil3.SingletonImageLoader;
import coil3.util.DebugLogger;
import dagger.hilt.android.HiltAndroidApp;
import jakarta.inject.Inject;


/***
 * Creates app instance when launched by user
 */
@HiltAndroidApp
public class FishFreshApplication extends Application{

    @Inject
    ImageLoader imageLoader;

    @Override
    public void onCreate() {
        super.onCreate();
        SingletonImageLoader.setSafe(context -> imageLoader);
    }

}


