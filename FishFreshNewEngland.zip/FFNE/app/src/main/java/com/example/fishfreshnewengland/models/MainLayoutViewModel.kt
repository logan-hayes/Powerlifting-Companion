package com.example.fishfreshnewengland.models

/**
 * @author Ashton Gabbeitt
 */
import android.util.Log
import androidx.compose.runtime.Immutable
import androidx.lifecycle.ViewModel
import com.example.fishfreshnewengland.external.AuthRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import javax.inject.Inject
import androidx.lifecycle.viewModelScope
import io.github.jan.supabase.auth.status.SessionStatus
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

@Immutable
data class MainLayoutUIState (
    val signedIn : Boolean = false,
    val isLoading : Boolean = false,
    val error : String? = null,
    val resetPWTriggered : Boolean = false,
    val emailConfirming: Boolean = false
)

@HiltViewModel
class MainLayoutViewModel @Inject constructor(
    private val authenticationRepository: AuthRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(MainLayoutUIState(isLoading = true))
    val uiState: StateFlow<MainLayoutUIState> = _uiState.asStateFlow()

    init {
        authState()
    }

    fun handleDeepLink(url: String) {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            try {

                authenticationRepository.handleDeeplink(url)

                when {
                    url.contains("type=signup") || url.contains("signup") -> {
                        _uiState.update { it.copy(emailConfirming = true, isLoading = false) }
                        Log.d("signup","Confirming email")
                    }
                    url.contains("type=recovery") || url.contains("recovery") -> {
                        _uiState.update { it.copy(resetPWTriggered = true, isLoading = false) }
                    }
                    else -> {
                            _uiState.update { it.copy(isLoading = false) }
                    }
                }


            } catch (e: Exception) {
                _uiState.update { it.copy(error = e.message, isLoading = false) }
            }
        }
    }

    fun resetEmailConfirming() {
        _uiState.update { it.copy(emailConfirming = false) }
    }

    fun signOut() {
        viewModelScope.launch {

            try {
                authenticationRepository.signOut()
                _uiState.update { it.copy(signedIn = false) }
            }
            catch (e: Exception) {
                _uiState.update { it.copy(error = e.message) }
            }

        }
    }

    fun authState() {
        viewModelScope.launch {
            authenticationRepository.sessionStatus.collect { status ->
                when (status) {
                    is SessionStatus.Initializing -> {
                        _uiState.update { it.copy(isLoading = true) }
                    }

                    is SessionStatus.Authenticated -> {
                        _uiState.update { it.copy(signedIn = true, isLoading = false) }
                    }

                    is SessionStatus.NotAuthenticated -> {
                        _uiState.update { it.copy(signedIn = false, isLoading = false) }
                    }

                    is SessionStatus.RefreshFailure -> {
                        // Handle case where user was logged in but token refresh failed
                        _uiState.update {
                            it.copy(
                                signedIn = false,
                                isLoading = false,
                                error = "Session expired"
                            )
                        }
                    }
                }
            }
        }
    }
}