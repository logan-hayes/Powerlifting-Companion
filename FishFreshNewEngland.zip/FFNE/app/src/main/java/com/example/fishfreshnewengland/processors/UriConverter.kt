package com.example.fishfreshnewengland.processors

/**
 * @author Ashton Gabbeitt
 */

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class UriConverter @Inject constructor(
    @ApplicationContext private val context: Context
) {

    private val MAX_FILE_SIZE = 2 * 1024 * 1024 // 2MB
    private val TARGET_WIDTH = 1920
    private val TARGET_HEIGHT = 1080
    suspend fun getBytesFromUri(uri: Uri): ByteArray? = withContext(Dispatchers.IO) {
        try {

            val options = BitmapFactory.Options().apply {
                inJustDecodeBounds = true
            }
            context.contentResolver.openInputStream(uri)?.use {
                BitmapFactory.decodeStream(it, null, options)
            }

            options.inSampleSize = calculateInSampleSize(options, TARGET_WIDTH, TARGET_HEIGHT)
            options.inJustDecodeBounds = false

            val downsampledBitmap = context.contentResolver.openInputStream(uri)?.use {
                BitmapFactory.decodeStream(it, null, options)
            } ?: return@withContext null

            var quality = 100
            var resultByteArray: ByteArray
            val outputStream = ByteArrayOutputStream()

            do {
                outputStream.reset()
                downsampledBitmap.compress(Bitmap.CompressFormat.JPEG, quality, outputStream)
                resultByteArray = outputStream.toByteArray()
                quality -= 10
            } while (resultByteArray.size > MAX_FILE_SIZE && quality > 10)

            downsampledBitmap.recycle()
            return@withContext resultByteArray

        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    /**
     * Calculates a power-of-two scale factor.
     * 1 = original size, 2 = half size, 4 = quarter size, etc.
     */
    private fun calculateInSampleSize(options: BitmapFactory.Options, reqWidth: Int, reqHeight: Int): Int {
        val (height: Int, width: Int) = options.outHeight to options.outWidth
        var inSampleSize = 1

        if (height > reqHeight || width > reqWidth) {
            val halfHeight = height / 2
            val halfWidth = width / 2

            while (halfHeight / inSampleSize >= reqHeight && halfWidth / inSampleSize >= reqWidth) {
                inSampleSize *= 2
            }
        }
        return inSampleSize
    }
}



