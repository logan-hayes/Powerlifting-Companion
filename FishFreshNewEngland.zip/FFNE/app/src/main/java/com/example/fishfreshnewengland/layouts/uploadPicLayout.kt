package com.example.fishfreshnewengland.layouts


/**
 * @author Ashton Gabbeitt
 */

import android.net.Uri
import androidx.activity.compose.ManagedActivityResultLauncher
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddAPhoto
import androidx.compose.material3.Button
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.fishfreshnewengland.models.UploadPicUIState


@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UploadPicLayoutContent(
    navigateToMain: () -> Unit,
    uiState: UploadPicUIState,
    onAvatarChanged: (Uri) -> Unit = {},
    submitUpload: () -> Unit = {}
) {

    val launcher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            onAvatarChanged(uri)
        }
    }

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = {
                    Text(
                        "Fish Fresh New England",
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth()
                    )
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = MaterialTheme.colorScheme.onPrimary,
                )
            )
        },
        content = { innerPadding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    "User Setup",
                    textAlign = TextAlign.Center,
                    style = MaterialTheme.typography.headlineLarge,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(top = 30.dp, bottom = 16.dp)
                )
                UploadPicForm(

                    launcher = launcher,
                    avatarUri = uiState.avatarURI,
                    submitUpload = submitUpload,
                    isLoading = uiState.isLoading
                )
                Text(uiState.errorMessage ?: "", color = MaterialTheme.colorScheme.error)


                LaunchedEffect(uiState.createSuccess) {
                    if (uiState.createSuccess) {
                        navigateToMain()
                    }
                }
            }
        }
    )
}

@Composable
fun UploadPicForm(
    launcher : ManagedActivityResultLauncher<PickVisualMediaRequest, Uri?>,
    avatarUri : Uri?,
    submitUpload: () -> Unit = {},
    isLoading: Boolean,
) {
    Column (
        horizontalAlignment = Alignment.CenterHorizontally
    ) {

        Button(onClick = {
            launcher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
        }) {
            Icon(
                Icons.Default.AddAPhoto,
                contentDescription = "Select profile picture",

                )
            Text(if (avatarUri == null) "Select Profile Picture" else "Change Profile Picture")

        }

        Button(
            onClick = submitUpload,
            modifier = Modifier.padding(top = 32.dp),
            enabled = avatarUri != null && !isLoading
        ) {
            Text(if (isLoading) "Submitting..." else "Submit")
        }
    }

}

