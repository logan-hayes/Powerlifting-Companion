package com.example.fishfreshnewengland.processors
/**
 * @author Ashton Gabbeitt
 */
import android.location.Location

fun isWithinRadius(
    userLat: Double,
    userLon: Double,
    locationLat: Double,
    locationLon: Double,
    radiusMiles: Double
): Boolean {
    val userLocation = Location("user")
    userLocation.latitude = userLat
    userLocation.longitude = userLon

    val targetLocation = Location("target")
    targetLocation.latitude = locationLat
    targetLocation.longitude = locationLon

    val distanceInMeters = userLocation.distanceTo(targetLocation)

    //1 mile = 1609.34 meters
    val radiusInMeters = radiusMiles * 1609.34

    return distanceInMeters <= radiusInMeters
}