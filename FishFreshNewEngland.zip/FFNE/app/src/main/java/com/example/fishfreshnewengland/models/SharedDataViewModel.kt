package com.example.fishfreshnewengland.models

import android.util.Log
import androidx.compose.runtime.Immutable
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.fishfreshnewengland.external.AuthRepository
import com.example.fishfreshnewengland.external.DatabaseRepository
import com.example.fishfreshnewengland.external.StorageRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

@Immutable
data class SharedData(
    val userID: String? = null,
    val username: String? = null,
    val error: String? = null,
    val profilePicURL: String? = null,
)

@HiltViewModel
class SharedDataViewModel @Inject constructor(
    private val authRepository: AuthRepository,
    private val databaseRepository: DatabaseRepository,
    private val storageRepository: StorageRepository
) : ViewModel() {
    private val _sharedData = MutableStateFlow(SharedData())
    val sharedData: StateFlow<SharedData> = _sharedData.asStateFlow()


    init {
        initializeUserData()
    }

    private fun initializeUserData() {
        val uid = authRepository.getCurrentUserId()
        _sharedData.update { it.copy(userID = uid) }

        uid?.let { id ->
            fetchUsername(id)
            fetchProfilePic(id)
        }

        if (_sharedData.value.profilePicURL != null){
            Log.d("SharedDataViewModel", "Profile pic URL: ${_sharedData.value.profilePicURL}")
        }
        else {
            Log.d("SharedDataViewModel", "Profile pic URL is null")
        }
    }

    private fun fetchUsername(userID: String) {
        viewModelScope.launch {
            val usernameResult = databaseRepository.getCurrentUserName(userID)
            if (usernameResult.isSuccess) {
                _sharedData.update { it.copy(username = usernameResult.getOrNull()?.username) }
            }
            if (usernameResult.isFailure) {
                _sharedData.update { it.copy(error = usernameResult.exceptionOrNull()?.message) }
            }
        }
    }

    private fun fetchProfilePic(userID: String) {
        viewModelScope.launch {
            val profilePicResult = databaseRepository.getUserProfilePicPath(userID)
            if (profilePicResult.isSuccess) {
                Log.d("SUPABASE", "Profile pic result is success")
                val profilePicPath = profilePicResult.getOrNull()?.profilePicPath
                if (profilePicPath != null) {
                    Log.d("SUPABASE", "Trying URL")
                    val profilePicURL = storageRepository.getAvatarURL(profilePicPath)
                    if (profilePicURL.isSuccess) {
                        Log.d("SUPABASE", "Profile URL result is success")
                        Log.d("SUPABASE", "Profile URL: ${profilePicURL.getOrNull()}")
                        _sharedData.update { it.copy(profilePicURL = profilePicURL.getOrNull()) }

                    }
                    else{
                        _sharedData.update { it.copy(error = "Failed to fetch profile pic : ${profilePicURL.exceptionOrNull()?.message}") }
                    }
                }
                else {
                    _sharedData.update { it.copy(error = "Failed to fetch profile pic path : ${profilePicResult.exceptionOrNull()?.message}") }
                }

            }
            else {
                Log.d("SUPABASE", "Profile pic result is failure")
                _sharedData.update { it.copy(error = profilePicResult.exceptionOrNull()?.message) }
            }
        }
    }

}