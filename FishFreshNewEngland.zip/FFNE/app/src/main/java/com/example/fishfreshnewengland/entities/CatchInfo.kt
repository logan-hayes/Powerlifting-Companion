package com.example.fishfreshnewengland.entities

/**
 * @author Logan Hayes
 */
//Helper class for holding Catch related data for use in forum post creation
class CatchInfo {
    var fishID: Int? = null
    var catchLengthIn: Float? = null
    var catchWeightlbs: Float? = null
    var lureUsed: String? = null

    constructor()
    constructor(
        fishID: Int?,
        catchLengthIn: Float?,
        catchWeightlbs: Float?,
        lureUsed: String?
    ) {
        this.fishID = fishID
        this.catchLengthIn = catchLengthIn
        this.catchWeightlbs = catchWeightlbs
        this.lureUsed = lureUsed
    }
}
