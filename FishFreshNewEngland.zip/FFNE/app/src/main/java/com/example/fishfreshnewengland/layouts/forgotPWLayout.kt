package com.example.fishfreshnewengland.layouts

/**
 * @author Ashton Gabbeitt
 */

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import com.example.fishfreshnewengland.models.ForgotPasswordUIState

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ForgotPasswordLayoutContent(
    uiState : ForgotPasswordUIState,
    navigateBackStack : () -> Unit,
    onEmailChanged : (String) -> Unit,
    requestPasswordResetEmail : () -> Unit,
    navigateToSignIn : (Boolean?) -> Unit,
    ) {

    LaunchedEffect(uiState.requestSuccess, uiState.needConfirm) {
        if (uiState.requestSuccess && uiState.needConfirm) {
            navigateToSignIn(true)
        }
        if (uiState.requestSuccess && !uiState.needConfirm) {
            navigateToSignIn(false)
        }
    }


    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Forgot Password", textAlign = TextAlign.Center) },
                navigationIcon = {
                    IconButton(onClick = {
                        navigateBackStack()
                    }) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Go Back"
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = MaterialTheme.colorScheme.onPrimary,
                    navigationIconContentColor = MaterialTheme.colorScheme.onPrimary
                )
            )
        },
        content = { innerPadding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                ForgotPasswordForm(
                    email = uiState.email,
                    onEmailChanged = { onEmailChanged(it) },
                )
                Button(
                    onClick = { requestPasswordResetEmail() },
                    enabled = uiState.formReady
                ){
                    Text(if (uiState.isLoading) "Submitting..." else "Request Reset Email")
                }
                if (uiState.errorMessage != null) {
                    Text(uiState.errorMessage, color = MaterialTheme.colorScheme.error)
                }
            }
        }

    )

}




@Composable
fun ForgotPasswordForm(
    email: String,
    onEmailChanged: (String) -> Unit,
) {

    Column {
        OutlinedTextField(
            value = email,
            onValueChange = onEmailChanged,
            label = { Text("Email") },
            modifier = Modifier.fillMaxWidth()
        )
    }

}