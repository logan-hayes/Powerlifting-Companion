package com.example.fishfreshnewengland.internal.entities;
import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.PrimaryKey;

@Entity(
        tableName = "fish_waterbodies",
        foreignKeys = {
                @ForeignKey(
                        entity = WaterBodies.class,
                        parentColumns = "id",
                        childColumns = "waterbodyID"
                ),
                @ForeignKey(
                        entity = Fish.class,
                        parentColumns = "id",
                        childColumns = "fishID"
                )
        }
)
public class FishWaterBodies {

    @PrimaryKey
    public int id;

    @NonNull
    public Integer waterbodyID;
    @NonNull
    public Integer fishID;


    public Integer fish_rating_count;
    public Integer fish_rating_points;

    public FishWaterBodies(@NonNull Integer id,
                           @NonNull Integer waterbodyID,
                           @NonNull Integer fishID,
                           Integer fish_rating_count,
                           Integer fish_rating_points) {

        this.id = id;
        this.waterbodyID = waterbodyID;
        this.fishID = fishID;
        this.fish_rating_count = fish_rating_count;
        this.fish_rating_points = fish_rating_points;
    }
}