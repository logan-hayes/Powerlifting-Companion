package com.example.fishfreshnewengland.security

// Quick Note: S.M. is the masterclass, the rest are subclasses being used here //

class SecurityManager(private val seaport: Seaport){

    interface IAuthenticator {
        fun loginWithCredentials(username: String, password: String): AuthResult
        fun loginWithBiometrics(): AuthResult
        fun refreshAccessToken(refreshToken: String): Token?
    }

    interface ISessionManager {
        fun createSession(userId: String, token: Token): Session
        fun invalidateCurrent()
        fun getCurrentSession(): Session?
        fun renewIfExpiring(): Session?
    }

    interface IPermissionManager {
        fun hasPermission(userId: String, resource: String, action: String): Boolean
    }

    interface ISecureStorage {
        fun putSecret(key: String, value: String)
        fun getSecret(key: String): String?
        fun removeSecret(key: String)
    }

    interface IAuditLogger {
        fun log(event: AuditEvent)
        fun flush()
    }

    // Minimal domain types (use your existing classes if available)
    data class Token(val value: String, val type: String, val expiry: java.time.LocalDateTime, val scopes: List<String>) {
        fun isExpired(): Boolean = java.time.LocalDateTime.now().isAfter(expiry)
    }
    data class Session(val sessionId: String, val userId: String, val token: Token, val issuedAt: java.time.LocalDateTime, val expiry: java.time.LocalDateTime) {
        fun isExpired(): Boolean = java.time.LocalDateTime.now().isAfter(expiry)
    }
    data class AuditEvent(val eventId: String, val userId: String?, val action: String, val timestamp: java.time.LocalDateTime = java.time.LocalDateTime.now(), val details: String? = null)

    sealed class AuthResult {
        data class Success(val userId: String, val token: Token, val refreshToken: String? = null) : AuthResult()
        data class Failure(val error: AuthError) : AuthResult()
    }
    enum class AuthError { INVALID_CREDENTIALS, RATE_LIMITED, BIOMETRIC_FAILED, UNKNOWN }

    // The SecurityManager itself
    class SecurityManager(
        private val authenticator: IAuthenticator,
        private val sessionManager: ISessionManager,
        private val permissionManager: IPermissionManager,
        private val secureStorage: ISecureStorage,
        private val auditLogger: IAuditLogger
    ) {

        fun authenticate(context: android.content.Context): AuthResult {
            // Default behavior: delegate to biometric flow if available
            val result = authenticator.loginWithBiometrics()
            when (result) {
                is AuthResult.Success -> {
                    createAndLogSession(result)
                }
                is AuthResult.Failure -> {
                    auditLogger.log(AuditEvent(eventId = generateId(), userId = null, action = "biometric_auth_failed", details = result.error.name))
                }
            }
            return result
        }

        fun authenticate(username: String, password: String): AuthResult {
            val result = authenticator.loginWithCredentials(username, password)
            when (result) {
                is AuthResult.Success -> {
                    createAndLogSession(result)
                    result.refreshToken?.let { secureStorage.putSecret(refreshKeyFor(result.userId), it) }
                }
                is AuthResult.Failure -> {
                    auditLogger.log(AuditEvent(eventId = generateId(), userId = null, action = "login_failed", details = result.error.name))
                }
            }
            return result
        }

        fun authenticateWithBiometrics(): AuthResult {
            val result = authenticator.loginWithBiometrics()
            when (result) {
                is AuthResult.Success -> createAndLogSession(result)
                is AuthResult.Failure -> auditLogger.log(AuditEvent(eventId = generateId(), userId = null, action = "biometric_failed", details = result.error.name))
            }
            return result
        }

        @Synchronized
        fun logout() {
            val current = sessionManager.getCurrentSession()
            current?.let {
                secureStorage.removeSecret(refreshKeyFor(it.userId))
                sessionManager.invalidateCurrent()
                auditLogger.log(AuditEvent(eventId = generateId(), userId = it.userId, action = "logout", details = "session invalidated"))
                auditLogger.flush()
            }
        }

        fun authorize(userId: String, resource: String, action: String): Boolean {
            val allowed = permissionManager.hasPermission(userId, resource, action)
            val actionName = if (allowed) "authorize_granted" else "authorize_denied"
            auditLogger.log(AuditEvent(eventId = generateId(), userId = userId, action = actionName, details = "$resource:$action"))
            return allowed
        }

        @Synchronized
        fun getActiveToken(): Token? {
            val session = sessionManager.getCurrentSession() ?: return null
            if (!session.token.isExpired()) return session.token

            // Try refresh flow
            val refreshToken = secureStorage.getSecret(refreshKeyFor(session.userId))
            if (refreshToken != null) {
                val newToken = authenticator.refreshAccessToken(refreshToken)
                if (newToken != null) {
                    val newSession = sessionManager.createSession(session.userId, newToken)
                    auditLogger.log(AuditEvent(eventId = generateId(), userId = session.userId, action = "token_refreshed"))
                    return newSession.token
                } else {
                    // refresh failed: invalidate session
                    sessionManager.invalidateCurrent()
                    auditLogger.log(AuditEvent(eventId = generateId(), userId = session.userId, action = "refresh_failed"))
                    return null
                }
            } else {
                // no refresh token: invalidate
                sessionManager.invalidateCurrent()
                auditLogger.log(AuditEvent(eventId = generateId(), userId = session.userId, action = "no_refresh_token"))
                return null
            }
        }

        private fun createAndLogSession(success: AuthResult.Success) {
            val session = sessionManager.createSession(success.userId, success.token)
            auditLogger.log(AuditEvent(eventId = generateId(), userId = success.userId, action = "login_success", details = "session:${session.sessionId}"))
        }

        private fun refreshKeyFor(userId: String) = "refresh_token_$userId"

        private fun generateId(): String = java.util.UUID.randomUUID().toString()
    }

}