package com.example.fishfreshnewengland.models

/**
 * @author Ashton Gabbeitt
 */
import androidx.compose.runtime.Immutable
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.navigation.toRoute
import com.example.fishfreshnewengland.external.AuthRepository
import com.example.fishfreshnewengland.navigation.SignInFormRoute
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject
import kotlin.math.sign


/**
 * Data class for sign in data retrieval
 * feeds state to sign in view model
 * @param email: String containing email
 * @param password: String containing password
 * @param isLoading: Boolean indicating if data is loading
 * @param errorMessage: String containing error message
 * @param formReady: Boolean indicating if form is ready to submit
 * @param loginSuccess: Boolean indicating if login was successful
 */
@Immutable
data class SignInUIState(
    val email: String = "",
    val password: String = "",
    val isLoading: Boolean = false,
    val errorMessage: String? = null,
    val formReady: Boolean = false,
    val loginSuccess: Boolean = false,
    val needConfirm: Boolean = false,
    val showSnackbar: Boolean = false,
    val newSignUp: Boolean = false
)


/**
 * ViewModel for sign in data retrieval
 */
@HiltViewModel
class SignInViewModel @Inject constructor(
    private val authenticationRepository: AuthRepository,
    savedStateHandle: SavedStateHandle
    ) : ViewModel() {

    private val route = savedStateHandle.toRoute<SignInFormRoute>()

    private val _uiState = MutableStateFlow(SignInUIState(
        needConfirm = route.needConfirm,
        newSignUp = route.newSignUp
    ))
    val uiState = _uiState.asStateFlow()

    fun onEmailChanged(emailChange: String) {
        _uiState.update {
            it.copy(
                email = emailChange,
            )
        }
        updateFormReady()
    }

    fun onPasswordChanged(passwordChanged: String) {
        _uiState.update {
            it.copy(
                password = passwordChanged,
            )
        }
        updateFormReady()
    }

    private fun updateFormReady() {
        _uiState.update {
            it.copy(formReady = it.email.isNotBlank() && it.password.isNotBlank())
        }
    }

    fun onSnackbarDismissed(){
        _uiState.update {
            it.copy(showSnackbar = false)
        }
    }

    fun clearNeedConfirm(){
        _uiState.update {
            it.copy(needConfirm = false)
        }
    }

    fun clearNewUser(){
        _uiState.update {
            it.copy(newSignUp = false)
        }
    }

    fun signInUser() {
        if (_uiState.value.isLoading) return

        viewModelScope.launch {

            _uiState.update { it.copy(isLoading = true, errorMessage = null) }

            val userEmail = _uiState.value.email
            val userPassword = _uiState.value.password

            try {

                    val signInSuccess = authenticationRepository.signIn(
                        userEmail,
                        userPassword
                    )

                   if (signInSuccess.success) {

                           _uiState.update {
                               it.copy(
                                   isLoading = false,
                                   loginSuccess = true,
                                   errorMessage = null,
                                   needConfirm = false,
                               )
                           }
                       } else {

                           if(!signInSuccess.confirmedUser) {
                               if(signInSuccess.emailSent){
                                   _uiState.update {
                                       it.copy(
                                           isLoading = false,
                                           loginSuccess = false,
                                           errorMessage = null,
                                           needConfirm = true,
                                           showSnackbar = true
                                       )
                                   }
                               }
                               else {
                                   _uiState.update {
                                       it.copy(
                                           isLoading = false,
                                           loginSuccess = false,
                                           errorMessage = signInSuccess.errorMessage,
                                           needConfirm = true,
                                           showSnackbar = true
                                       )
                                   }
                               }

                           }
                       else {
                               _uiState.update {
                                   it.copy(
                                       isLoading = false,
                                       loginSuccess = false,
                                       errorMessage = signInSuccess.errorMessage,
                                       needConfirm = false,
                                       showSnackbar = true
                                   )
                               }
                           }

                       }










            } catch (e: Exception) {
                _uiState.update {
                    it.copy(
                        isLoading = false,
                        errorMessage = e.localizedMessage,
                        loginSuccess = false
                    )
                }
            }
        }
    }
}

