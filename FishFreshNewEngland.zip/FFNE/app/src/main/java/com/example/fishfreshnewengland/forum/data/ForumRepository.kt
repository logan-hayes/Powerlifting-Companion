package com.example.fishfreshnewengland.forum.data


    import com.example.fishfreshnewengland.entities.CatchInfo
    import com.example.fishfreshnewengland.entities.Post
    import com.example.fishfreshnewengland.entities.Comment
    import com.example.fishfreshnewengland.entities.PostLocation
    import com.example.fishfreshnewengland.forum.models.FeedFilteringMode
    import kotlinx.coroutines.flow.Flow

    interface ForumRepository {
        fun observePosts(sortMode: FeedFilteringMode): Flow<List<Post>>
        fun observeComments(postId: Long): Flow<List<Comment>>

        suspend fun createPost(
            content: String,
            AuthorID: String,
            imageUrl: String? = null,
            catchInfo: CatchInfo? = null,
            postLocation: PostLocation? = null
            ): Boolean
        suspend fun createComment(postId: Long, content: String): Boolean

        suspend fun likePost(postId: Long): Boolean
        suspend fun likeComment(commentId: Long): Boolean
    }
