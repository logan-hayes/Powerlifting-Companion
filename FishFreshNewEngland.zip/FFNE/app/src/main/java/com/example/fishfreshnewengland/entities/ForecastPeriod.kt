package com.example.fishfreshnewengland.entities

/**
 * @author Ashton Gabbeitt
 */
import kotlinx.datetime.TimeZone
import kotlinx.datetime.toLocalDateTime
import kotlinx.serialization.Serializable
import kotlin.time.ExperimentalTime
import kotlin.time.Instant

@Serializable
data class DewPoint (
    val unitCode: String,
    val value: Int? = null
)

@Serializable
data class RelativeHumidity (
    val unitCode: String? = null,
    val value: Int? = null
)

@Serializable
data class ProbabilityOfPrecipitation (
    val unitCode: String? = null,
    val value: Int? = null
)

@Serializable
@OptIn(ExperimentalTime::class)
data class ForecastPeriod(
    val number: Int,
    val startTime: String?,
    val endTime: String?,
    val isDaytime: Boolean,
    val temperature: Int,
    val temperatureUnit: String?,
    val probabilityOfPrecipitation: ProbabilityOfPrecipitation? = null,
    val dewPoint: DewPoint? = null,
    val relativeHumidity: RelativeHumidity? = null,
    val windSpeed: String?,
    val windDirection: String?,
    val icon: String?,
    val shortForecast: String?,
    val detailedForecast: String?
) {


   var startTimeConverted: Instant? = null
    var startTimeHour: Int? = null

    init {
        if (startTime != null) {
            startTimeConverted = Instant.parse(startTime)
            startTimeHour = startTimeConverted?.toLocalDateTime(TimeZone.currentSystemDefault())?.hour
            }
    }
}
