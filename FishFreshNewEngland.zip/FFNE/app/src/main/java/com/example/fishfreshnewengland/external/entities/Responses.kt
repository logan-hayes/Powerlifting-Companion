package com.example.fishfreshnewengland.external.entities

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class UsernameResponse(
    val username: String,
)

@Serializable
data class ProfilePicResponse(
    @SerialName("profile_picture")
    val profilePicPath: String,
)