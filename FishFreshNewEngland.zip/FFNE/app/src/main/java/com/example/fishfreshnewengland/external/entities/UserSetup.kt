package com.example.fishfreshnewengland.external.entities

/**
 * @author Ashton Gabbeitt
 */

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlin.uuid.ExperimentalUuidApi
import kotlin.uuid.Uuid

@Serializable
data class UserSetup @OptIn(ExperimentalUuidApi::class) constructor(
    @SerialName("user_id")
    val userID : Uuid,
    val username : String,
    @SerialName("birth_date")
    val dateOfBirth : String,
    @SerialName("profile_picture")
    val avatarURL : String?
)