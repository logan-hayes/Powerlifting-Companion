package com.example.fishfreshnewengland.external.entities;

import com.google.gson.annotations.SerializedName;
import java.util.List;
import java.util.ArrayList;

public class UserProfileSettings {

    @SerializedName("user_id")
    private int userId;

    @SerializedName("email_notifications")
    private boolean emailNotifications;

    @SerializedName("private_profile")
    private boolean isPrivate;

    // preferred species stored as list of fish IDs matching users_preferred_species table
    @SerializedName("preferred_species")
    private List<Integer> preferredSpecies;

    public UserProfileSettings() {
        this.emailNotifications = true;
        this.isPrivate = false;
        this.preferredSpecies = new ArrayList<>();
    }

    public int getUserId() { return userId; }
    public void setUserId(int userId) { this.userId = userId; }

    public boolean isEmailNotifications() { return emailNotifications; }
    public void setEmailNotifications(boolean emailNotifications) { this.emailNotifications = emailNotifications; }

    public boolean isPrivate() { return isPrivate; }
    public void setPrivate(boolean isPrivate) { this.isPrivate = isPrivate; }

    public List<Integer> getPreferredSpecies() { return preferredSpecies; }
    public void setPreferredSpecies(List<Integer> preferredSpecies) { this.preferredSpecies = preferredSpecies; }
}