package com.example.fishfreshnewengland.entities;

/**
 * @author Ashton Gabbeitt
 */
import java.util.Date;

public class ModeratorUser extends StandardUser {

    public ModeratorUser(String userID) {
        super(userID);
    }

//    public ArrayList<Post> getReportedPosts() {
//        //TODO: get reported posts from database
//        return new ArrayList<Post>();
//    }

    public boolean suspendUser(int userID) {
        //TODO: change user status to suspended in database
        return true;
    }

    public boolean unsuspendUser(int userID) {
        //TODO: change user status to active in database
        return true;
    }


}
