package com.example.fishfreshnewengland.map.entities

/**
 * @author Ashton Gabbeitt
 */
data class LocationData (
    val latitude: Double,
    val longitude: Double,
) 