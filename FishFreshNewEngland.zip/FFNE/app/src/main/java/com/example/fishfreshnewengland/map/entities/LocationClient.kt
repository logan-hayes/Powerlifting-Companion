package com.example.fishfreshnewengland.map.entities

/**
 * @author Ashton Gabbeitt
 */
import android.annotation.SuppressLint
import android.content.Context
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import com.google.android.gms.tasks.CancellationTokenSource
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.tasks.await

import javax.inject.Inject

class LocationClient @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private val client = LocationServices.getFusedLocationProviderClient(context)

    @SuppressLint("MissingPermission")
    suspend fun getUserLocation(): LocationData? {
        return try {
            val location = client.getCurrentLocation(
                Priority.PRIORITY_BALANCED_POWER_ACCURACY,
                CancellationTokenSource().token
            ).await()

            location?.let { LocationData(it.latitude, it.longitude) }
        } catch (e: Exception) {
            null
        }


    }
}