package com.example.fishfreshnewengland.forum.ui


import java.time.LocalDateTime
import java.time.Duration
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.ChatBubbleOutline
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.ThumbUp
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.ui.Alignment
import androidx.compose.ui.unit.dp
import androidx.constraintlayout.compose.ConstraintLayout
import com.example.fishfreshnewengland.forum.viewmodel.ForumViewModel
import com.example.fishfreshnewengland.entities.Post
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.SetMeal
import androidx.compose.ui.graphics.Color
import androidx.navigation.NavController
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.getValue
import androidx.constraintlayout.compose.Dimension
import com.example.fishfreshnewengland.entities.CatchInfo
import com.example.fishfreshnewengland.entities.PostLocation
import com.example.fishfreshnewengland.forum.models.FeedFilteringMode
import com.example.fishfreshnewengland.internal.entities.AccessPoints
import com.example.fishfreshnewengland.internal.entities.Fish
import com.example.fishfreshnewengland.navigation.ForumPostCommentRoute


@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ForumFeedScreen(
    viewModel: ForumViewModel,
    navController: NavController
) {

    val posts by viewModel.posts.collectAsState()
    val uiState by viewModel.UIState.collectAsState()
    val fishSpecies by viewModel.fishOptions.collectAsState()
    val locations by viewModel.locationOptions.collectAsState()
    val usernames by viewModel.usernames.collectAsState()
    var selectedCatchInfo by remember {mutableStateOf<CatchInfo?>(null)}
    val speciesName = selectedCatchInfo?.fishID?.let { id ->
        fishSpecies.firstOrNull {it.id == id}?.species

    }

    var catchLengthText by remember {mutableStateOf("")}
    var catchWeightText by remember {mutableStateOf("")}
    var lureUsed by remember {mutableStateOf("")}
    var showDialog by remember {mutableStateOf(false)}
    var showFilterMenu by remember {mutableStateOf(false)}
    var selectedPostLocation by remember { mutableStateOf<PostLocation?>(null)}



    Scaffold(
        topBar = {
            TopAppBar(
                title = {Text("Community Forum")},
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack()})
                            {

                        Icon(
                            imageVector = Icons.Filled.ArrowBack,
                            contentDescription = "Back",
                                tint = MaterialTheme.colorScheme.onPrimary)

                        }
                },

                actions = {
                    IconButton(onClick = { showFilterMenu = true})
                    {
                        Icon(
                            imageVector = Icons.Filled.FilterList,
                            contentDescription = "filter",
                        )
                    }

                    DropdownMenu(
                        expanded = showFilterMenu,
                        onDismissRequest = { showFilterMenu = false})
                    {
                        DropdownMenuItem(
                            text = {Text("Most Recent")},
                            onClick = {
                                viewModel.setSortMode(FeedFilteringMode.RECENT)
                                showFilterMenu = false
                            }
                        )

                        DropdownMenuItem(
                            text = {Text("Most popular")},
                            onClick = {
                                viewModel.setSortMode(FeedFilteringMode.ENGAGEMENT)
                                showFilterMenu = false
                            }
                        )

                    }
                },

                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = MaterialTheme.colorScheme.onPrimary))
                }

    ) { innerPadding ->

        if (showDialog){
            NewPostContent(
                fishSpecies = fishSpecies,
                locations = locations,
                errorMessage = uiState.errorMessage,
                onDismiss = {showDialog = false},
                onPost = { content, catchInfo, postLocation ->
                    viewModel.createPost(content, catchInfo, postLocation)

                    showDialog = false
                }
            )
        }

        if (selectedCatchInfo != null || selectedPostLocation != null){
            InfoDialog(
                catchInfo = selectedCatchInfo,
                postLocation = selectedPostLocation,
                speciesName = speciesName,
                onDismiss = {
                    selectedCatchInfo = null
                    selectedPostLocation = null
                }
            )
        }

        LazyColumn(
            modifier = Modifier
            .fillMaxSize()
            .padding(innerPadding),
            contentPadding = PaddingValues(16.dp))
        {
            item{
                NewPost(
                    onClick = {showDialog = true}
                )
                Spacer(modifier = Modifier.height(12.dp))
            }

            items(posts) { post ->
                val authorName = usernames[post.getAuthorID()] ?: post.getAuthorID()

                PostCard(
                    post = post,
                    authorName = authorName,
                    onLike = {
                    viewModel.likePost(post.getPostID())
                },
                onComment = {
                    viewModel.selectPost(post.getPostID())
                    navController.navigate(ForumPostCommentRoute(post.getPostID()))
            },
                onInfo = {
                    selectedCatchInfo = post.getCatchInfo()
                    selectedPostLocation = post.getPostLocation()
                }
                )
                Spacer(modifier = Modifier.height(12.dp))
            }
        }
    }
}

@Composable
fun NewPost(
    onClick: () -> Unit)
{
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable{onClick()},
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant),

        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp))
    {
        Row(
            modifier = Modifier.fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically)
        {
            Icon(
                imageVector = Icons.Default.AccountCircle,
                contentDescription = "Profile",
                modifier = Modifier.size(40.dp),
                tint = MaterialTheme.colorScheme.onSurfaceVariant)

            Spacer(modifier = Modifier.width(12.dp))

            Text(
                text = "Share tips and recent catches",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                style = MaterialTheme.typography.bodyMedium)
        }
    }
}

@Composable
fun PostCard(
    post: Post,
    authorName: String,
    onLike: () -> Unit,
    onComment: () -> Unit,
    onInfo: () -> Unit)
 {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF82B4EA)),
        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp))
    {

    ConstraintLayout(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 16.dp))
    {
        val (avatar, userName, moreOptions, content, image, like, comment, send, likeCount, commentCount, badge, timeStamp) = createRefs()
        val headerBottom =  createBottomBarrier(avatar, userName, badge, timeStamp, moreOptions)
        val hasImage = post.getImageURL() != null

        Icon(
            imageVector = Icons.Default.AccountCircle,
            contentDescription = "Profile",
            modifier = Modifier
                .size(44.dp)
                .clip(CircleShape)
                .constrainAs(avatar) {
                    top.linkTo(parent.top)
                    start.linkTo(parent.start, margin = 16.dp)
                }
        )
        Text(
            text = authorName,
            style = MaterialTheme.typography.titleSmall,
            modifier = Modifier.constrainAs(userName) {
                top.linkTo(parent.top, margin = 3.dp)
                start.linkTo(avatar.end, margin = 8.dp)
            }
        )

        IconButton(
            onClick = {},
            modifier = Modifier.constrainAs(moreOptions) {
                end.linkTo(parent.end, margin = 16.dp)
                top.linkTo(avatar.top)
                bottom.linkTo(avatar.bottom)
            }
        ) {
            Icon(
                imageVector = Icons.Default.MoreVert,
                contentDescription = "More options")
        }

        Text(
            text = post.getContent(),
            modifier = Modifier.constrainAs(content) {
                top.linkTo(headerBottom, margin = 12.dp)
                start.linkTo(parent.start, margin = 16.dp)
                end.linkTo(parent.end, margin = 16.dp)
                width = Dimension.fillToConstraints
            }
        )

    if (hasImage){
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(300.dp)
                .background(MaterialTheme.colorScheme.surfaceVariant)
                .constrainAs(image) {
                    top.linkTo(content.bottom, margin = 12.dp)
                    start.linkTo(parent.start)
                    end.linkTo(parent.end)
                },
            contentAlignment = Alignment.Center)
        {
            Icon(
                imageVector = Icons.Default.Image,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(64.dp))
        }
    }
        IconButton(
            onClick = onLike,
            modifier = Modifier.constrainAs(like) {
                top.linkTo(
                    if (hasImage) image.bottom
                            else content.bottom,
                    margin = 16.dp)
                start.linkTo(parent.start, margin = 16.dp)
            }
        ) {
            Icon(
                imageVector = Icons.Default.ThumbUp,
                contentDescription = "Like",
                modifier = Modifier.size(24.dp))
        }

        IconButton(
            onClick = onComment,
            modifier = Modifier.constrainAs(comment) {
                top.linkTo(like.top)
                bottom.linkTo(like.bottom)
                start.linkTo(like.end, margin = 16.dp)
            }
        ) {
            Icon(
                imageVector = Icons.Default.ChatBubbleOutline,
                contentDescription = "comment",
                modifier = Modifier.size(24.dp))
        }

        if (post.catchInfo != null){
            IconButton(onClick = onInfo) {
                Icon(Icons.Default.SetMeal, contentDescription = "Catch Info")
            }
        }

        if (post.postLocation != null) {
            IconButton(
                onClick = onInfo,
                modifier = Modifier.constrainAs(send) {
                    top.linkTo(comment.top)
                    bottom.linkTo(comment.bottom)
                    start.linkTo(comment.end, margin = 16.dp)
                }
            ){
                Icon(Icons.Default.SetMeal, contentDescription = "Location")
            }

            Icon(
                imageVector = Icons.Default.SetMeal,
                contentDescription = "Catch Info",
                modifier = Modifier.size(24.dp))
        }

        Text(
            text = "${post.getLikes()} likes",
            style = MaterialTheme.typography.titleSmall,
            color = MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.constrainAs(likeCount) {
                top.linkTo(like.bottom, margin = 8.dp)
                start.linkTo(parent.start, margin = 16.dp)
            }
        )

        Text(
            text = "${post.getCommentCount()} comments",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.constrainAs(commentCount) {
                top.linkTo(likeCount.bottom, margin = 4.dp)
                start.linkTo(parent.start, margin = 16.dp)
            }

                .clickable{onComment()}
        )

        Icon(
            imageVector = Icons.Default.Verified,
            contentDescription = "badge",
            tint = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier
                .size(16.dp)
                .constrainAs(badge){
                    start.linkTo(userName.end, margin = 4.dp)
                    top.linkTo(userName.top)
                    bottom.linkTo(userName.bottom)
                }
        )

        Text(
            text = formatTimestamp(post.getTimeStamp()),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.constrainAs(timeStamp){
                top.linkTo(userName.bottom, margin = 2.dp)
                start.linkTo(userName.start)
            }
        )
    }
    }
}
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NewPostContent(
    fishSpecies: List<Fish>,
    locations: List<AccessPoints>,
    errorMessage: String?,
    onDismiss: () -> Unit,
    onPost: (String, CatchInfo?, PostLocation?) -> Unit
){
    var text by remember {mutableStateOf("")}
    var catchField by remember { mutableStateOf(false)}
    var locationField by remember {mutableStateOf(false)}
    var photoField by remember { mutableStateOf(false)}

    var locationQuery by remember {mutableStateOf("")}
    var selectedLocation by remember {mutableStateOf<AccessPoints?>(null)}
    var locationMenuExpanded by remember {mutableStateOf(false)}
    val filteredLocations = locations.filter { loc ->
        (loc.name ?: "").contains(locationQuery, ignoreCase = true)
    }

    var catchLengthText by remember {mutableStateOf("")}
    var catchWeightText by remember {mutableStateOf("")}
    var lureUsed by remember {mutableStateOf("")}
    var fishQuery by remember {mutableStateOf("")}
    var selectedFish by remember {mutableStateOf<Fish?>(null)}
    var fishMenuExpanded by remember {mutableStateOf(false)}
    var locationName by remember {mutableStateOf("")}
    var latitudeText by remember {mutableStateOf("")}
    var longitudeText by remember {mutableStateOf("")}
    val filteredFish = fishSpecies.filter {fish ->
        fish.species.contains(fishQuery, ignoreCase = true)
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss)
    {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .verticalScroll(rememberScrollState())
        ) {
            Text(
                text = "Create Post",
                style = MaterialTheme.typography.titleLarge
            )

            Spacer(modifier = Modifier.height(12.dp))

            TextField(
                value = text,
                   onValueChange = { text = it },
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("Share tips or a recent catch") }
            )

            if (errorMessage != null) {
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = errorMessage,
                    color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.bodySmall
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            )
            {
                AssistChip(
                    onClick = { photoField = !photoField },
                    label = { Text("Add Photo") })

                AssistChip(
                    onClick = { catchField = !catchField },
                    label = { Text("Add Catch Info") })

                AssistChip(
                    onClick = { locationField = !locationField },
                    label = { Text("Add Location Info") })
            }

            if (photoField) {
                Spacer(modifier = Modifier.height(16.dp))
                Text("Upload Photo Here")
            }

            if (catchField) {
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = "Add Catch Info",
                    style = MaterialTheme.typography.titleMedium)

                Spacer(modifier = Modifier.height(8.dp))

                ExposedDropdownMenuBox(
                    expanded = fishMenuExpanded && filteredFish.isNotEmpty(),
                    onExpandedChange = {fishMenuExpanded = !fishMenuExpanded})
                {
                    TextField(
                        value = fishQuery,
                        onValueChange = {
                            fishQuery = it
                            selectedFish = null
                            fishMenuExpanded = true
                        },
                        modifier = Modifier
                            .menuAnchor()
                            .fillMaxWidth(),
                        label = {Text("Fish Species")},
                        trailingIcon = {
                            ExposedDropdownMenuDefaults.TrailingIcon(
                                expanded = fishMenuExpanded && filteredFish.isNotEmpty()
                            )
                        }
                    )

                    ExposedDropdownMenu(
                        expanded = fishMenuExpanded && filteredFish.isNotEmpty(),
                        onDismissRequest = {fishMenuExpanded = false})
                    {
                        filteredFish.forEach {fish ->
                            DropdownMenuItem(
                                text = {Text(fish.species)},
                                onClick = {
                                    selectedFish = fish
                                    fishQuery = fish.species
                                    fishMenuExpanded = false
                                }
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                ExposedDropdownMenuBox(
                    expanded = fishMenuExpanded && filteredFish.isNotEmpty(),
                    onExpandedChange = {fishMenuExpanded = !fishMenuExpanded})
                {
                    TextField(
                        value = fishQuery,
                        onValueChange = {
                            fishQuery = it
                            selectedFish = null
                            fishMenuExpanded = true
                        },
                        modifier = Modifier
                            .menuAnchor()
                            .fillMaxWidth(),
                        label = {Text("Fish Species")},
                        trailingIcon = {
                            ExposedDropdownMenuDefaults.TrailingIcon(
                                expanded = fishMenuExpanded && filteredFish.isNotEmpty()
                            )
                        }
                    )

                    ExposedDropdownMenu(
                        expanded = fishMenuExpanded && filteredFish.isNotEmpty(),
                        onDismissRequest = {fishMenuExpanded = false})
                    {
                        filteredFish.forEach {fish ->
                            DropdownMenuItem(
                                text = {Text(fish.species)},
                                onClick = {
                                    selectedFish = fish
                                    fishQuery = fish.species
                                    fishMenuExpanded = false
                                }
                            )
                        }
                    }
                }

                TextField(
                    value = catchLengthText,
                    onValueChange = {catchLengthText = it},
                    modifier = Modifier.fillMaxWidth(),
                    placeholder = {Text("Catch length in.")})

                Spacer(modifier = Modifier.height(8.dp))

                TextField(
                    value = catchWeightText,
                    onValueChange = {catchWeightText = it},
                    modifier = Modifier.fillMaxWidth(),
                    placeholder = {Text("Catch Weight lbs.")})

                Spacer(modifier = Modifier.height(8.dp))

                TextField(
                    value = lureUsed,
                    onValueChange = {lureUsed = it},
                    modifier = Modifier.fillMaxWidth(),
                    placeholder = {Text("lure/Bait Used")}
                )
            }

            if (locationField){
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = "Add Location Info",
                    style = MaterialTheme.typography.titleMedium)

                Spacer(modifier = Modifier.height(8.dp))

                ExposedDropdownMenuBox(
                    expanded = locationMenuExpanded && filteredLocations.isNotEmpty(),
                    onExpandedChange =  {locationMenuExpanded = !locationMenuExpanded})
                {
                    TextField(
                        value = locationQuery,
                        onValueChange = {
                            locationQuery = it
                            selectedLocation = null
                            locationMenuExpanded = true
                        },
                        modifier = Modifier
                            .menuAnchor()
                            .fillMaxWidth(),
                        label = {Text("Select Location")},
                        trailingIcon = {
                            ExposedDropdownMenuDefaults.TrailingIcon(
                                expanded = locationMenuExpanded && filteredLocations.isNotEmpty()
                            )
                        }
                    )

                    ExposedDropdownMenu(
                        expanded = locationMenuExpanded && filteredLocations.isNotEmpty(),
                        onDismissRequest = {locationMenuExpanded = false})
                    {
                        filteredLocations.forEach { locations ->
                            DropdownMenuItem(
                                text = { Text(locations.name) },
                                onClick = {
                                    selectedLocation = locations
                                    locationQuery = locations.name
                                    locationMenuExpanded = false
                                }
                            )
                        }
                    }    }
            }
        }
            Spacer(modifier = Modifier.height(16.dp))

            Button(
                onClick = {
                    val catchInfo =
                        if (
                            selectedFish != null ||
                            catchLengthText.isNotBlank() ||
                            catchWeightText.isNotBlank() ||
                            lureUsed.isNotBlank()
                        ) {
                            CatchInfo(
                                selectedFish?.id,
                                catchLengthText.toFloatOrNull(),
                                catchWeightText.toFloatOrNull(),
                                lureUsed.ifBlank { null })
                        } else {
                            null
                        }
                    val postLocation =
                        if (
                            locationName.isNotBlank() ||
                            latitudeText.isNotBlank() ||
                            longitudeText.isNotBlank()
                        ) {
                            PostLocation(
                                null,
                                locationName.ifBlank { null },
                                latitudeText.toDoubleOrNull(),
                                longitudeText.toDoubleOrNull()
                            )
                        } else {
                            null
                        }

                    onPost(text.trim(), catchInfo, postLocation)
                },
                modifier = Modifier.fillMaxWidth(),
                enabled = text.isNotBlank()
            ) {
                Text("Post")
            }

            Spacer(modifier = Modifier.height(12.dp))
        }
    }

fun formatTimestamp(timestamp: LocalDateTime): String {
    val now = LocalDateTime.now()
    val duration = Duration.between(timestamp, now)

    val minutes = duration.toMinutes()
    val hours = duration.toHours()
    val days = duration.toDays()

    return when {
        minutes < 1 -> "Just now"
        minutes < 60 -> "${minutes}m ago"
        hours < 24 -> "${hours}h ago"
        days < 7 -> "${days}d ago"
        else -> timestamp.toLocalDate().toString()
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun InfoDialog(
    catchInfo: CatchInfo?,
    postLocation: PostLocation?,
    speciesName: String?,
    onDismiss: () -> Unit) {
    ModalBottomSheet(
        onDismissRequest = onDismiss
    )
    {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        )
        {
            Text(
                text = "Catch/LocationInfo",
                style = MaterialTheme.typography.titleLarge
            )

            Spacer(modifier = Modifier.height(16.dp))

            catchInfo?.let {
                Text("Species: ${speciesName ?: "Unknown"}")
                Text("Catch Length: ${it.catchLengthIn ?: "placeholder"}")
                Text("Catch Weight: ${it.catchWeightlbs ?: "placeholder"}")
                Text("Lure/Bait: ${it.lureUsed ?: "placeholder"}")
                Spacer(modifier = Modifier.height(12.dp))
            }

            postLocation?.let {
                Spacer(modifier = Modifier.height(8.dp))
                Text("Location: ${it.locationName ?: "placeholder"}")
                it.latitude?.let { latitude ->
                    Text("Latitude: $latitude")
                }
                it.longitude?.let { longitude ->
                    Text("Longitude: $longitude")
                }
            }

            if (catchInfo == null && postLocation == null) {
                Text("No additional information available.")
                Spacer(modifier = Modifier.height(12.dp))
            }

            Button(
                onClick = onDismiss,
                modifier = Modifier.fillMaxWidth()
            )
            {
                Text("Close")
            }

            Spacer(modifier = Modifier.height(12.dp))
        }
    }
}