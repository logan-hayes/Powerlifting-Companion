package com.example.fishfreshnewengland.external

/**
 * @author Ashton Gabbeitt
 */
import android.content.Context
import androidx.compose.ui.platform.LocalContext
import com.example.fishfreshnewengland.BuildConfig
import com.russhwolf.settings.SharedPreferencesSettings
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import io.github.jan.supabase.SupabaseClient
import io.github.jan.supabase.auth.Auth
import io.github.jan.supabase.auth.SettingsSessionManager
import io.github.jan.supabase.auth.auth
import io.github.jan.supabase.createSupabaseClient
import io.github.jan.supabase.postgrest.Postgrest
import io.github.jan.supabase.postgrest.postgrest
import io.github.jan.supabase.storage.Storage
import io.github.jan.supabase.storage.storage
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object SupabaseModule {

    private val BASE_URL = BuildConfig.SUPABASE_URL
    private val API_KEY = BuildConfig.SUPABASE_KEY

    @Provides
    @Singleton
    fun provideSupabaseClient(
        @ApplicationContext context: Context
    ): SupabaseClient {

        val sharedPreferences = context.getSharedPreferences("supabase", Context.MODE_PRIVATE)
        val settings = SharedPreferencesSettings(sharedPreferences)

        return createSupabaseClient(
            supabaseUrl = BASE_URL,
            supabaseKey = API_KEY
        ) {
            install(Auth) {
                sessionManager = SettingsSessionManager(settings)
            }
            install(Auth)
            install(Postgrest)
            install(Storage)
        }
    }

    @Provides
    @Singleton
    fun provideSupabaseDatabase(client: SupabaseClient): Postgrest {
        return client.postgrest
    }
    @Provides
    @Singleton
    fun provideSupabaseAuth(client: SupabaseClient): Auth {
        return client.auth
    }

    @Provides
    @Singleton
    fun provideSupabaseStorage(client: SupabaseClient): Storage {
        return client.storage
    }
}


//
//    @Provides
//    @Singleton
//    fun provideSupabaseService(): SupabaseService {
//        val client = OkHttpClient.Builder()
//            .addInterceptor { chain ->
//                val request = chain.request().newBuilder()
//                    .header("apikey", API_KEY)
//                    .header("Authorization", "Bearer " + API_KEY)
//                    .build()
//                chain.proceed(request)
//            }.build()
//
//
//        return Retrofit.Builder()
//            .baseUrl(BASE_URL)
//            .client(client)
//            .addConverterFactory(GsonConverterFactory.create())
//            .build()
//            .create(SupabaseService::class.java)
//    }
