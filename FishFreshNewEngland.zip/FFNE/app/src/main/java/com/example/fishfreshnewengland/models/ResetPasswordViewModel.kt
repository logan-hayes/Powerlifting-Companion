package com.example.fishfreshnewengland.models

/**
 * @author Ashton Gabbeitt
 */
import androidx.compose.runtime.Immutable
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.fishfreshnewengland.external.AuthRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

@Immutable
data class ResetPasswordUIState(
    val email: String = "",
    val password: String = "",
    val confirmPassword: String = "",
    val isLoading: Boolean = false,
    val formReady: Boolean = false,
    val resetSuccess: Boolean = false,
    val errorMessage: String? = null
)

@HiltViewModel
class ResetPasswordViewModel @Inject constructor(
    private val authenticationRepository: AuthRepository,
) : ViewModel() {

    private val _uiState = MutableStateFlow(ResetPasswordUIState())
    val uiState = _uiState.asStateFlow()

    fun onEmailChanged(emailChange: String) {
        _uiState.update {
            it.copy(
                email = emailChange,
                formReady = emailChange.isNotBlank() && _uiState.value.password.isNotBlank() && _uiState.value.confirmPassword.isNotBlank()
            )
        }
    }

    fun onPasswordChanged(passwordChanged: String) {
        _uiState.update {
            it.copy(
                password = passwordChanged,
                formReady = passwordChanged.isNotBlank() && _uiState.value.email.isNotBlank() && _uiState.value.confirmPassword.isNotBlank() && passwordChanged == _uiState.value.confirmPassword
            )
        }
    }

    fun onPasswordConfirmChanged(passwordConfirmChanged: String) {
        _uiState.update {
            it.copy(
                confirmPassword = passwordConfirmChanged,
                formReady = passwordConfirmChanged.isNotBlank() && _uiState.value.password.isNotBlank() && _uiState.value.email.isNotBlank() && passwordConfirmChanged == _uiState.value.password
            )
        }
    }


    fun resetPW() {
        viewModelScope.launch {

            _uiState.update { it.copy(isLoading = true, errorMessage = null) }

            val pw = _uiState.value.password
            val pwConfirm = _uiState.value.confirmPassword

            if(pw != pwConfirm){
                _uiState.update {
                    it.copy(
                        isLoading = false,
                        errorMessage = "Passwords do not match",
                        resetSuccess = false
                    )
                }
                return@launch
            }

            try {
                val resetSuccess =
                    authenticationRepository.submitPasswordUpdate(_uiState.value.password)
                if (resetSuccess) {
                    _uiState.update { it.copy(isLoading = false, resetSuccess = true) }
                } else {
                    _uiState.update {
                        it.copy(
                            isLoading = false,
                            resetSuccess = false,
                            errorMessage = "Reset rejected. Please try again.",
                        )
                    }
                }
            } catch (e: Exception) {
                _uiState.update {
                    it.copy(isLoading = false, errorMessage = e.message, resetSuccess = false)
                }

            }


        }
    }


}