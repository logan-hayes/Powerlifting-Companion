package com.example.fishfreshnewengland.entities;
/**
 * @author Ashton Gabbeitt
 */
public enum PROFILESTATUS {
    ACTIVE,
    INACTIVE,
    SUSPENDED,

}
