package com.example.fishfreshnewengland.layouts

/**
 * @author Ashton Gabbeitt
 */

import android.net.Uri
import androidx.activity.compose.ManagedActivityResultLauncher
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddAPhoto
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material3.Button
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.DisplayMode
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.fishfreshnewengland.models.UserSetupUIState
import com.example.fishfreshnewengland.processors.convertMillisToDateString

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UserSetupLayoutContent(
    navigateToMain: () -> Unit,
    uiState: UserSetupUIState,
    onUsernameChanged: (String) -> Unit = {},
    onBirthDateChanged: (Long) -> Unit = {},
    onAvatarChanged: (Uri) -> Unit = {},
    submitUserSetup: () -> Unit = {}
) {

    val launcher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            onAvatarChanged(uri)
        }
    }

    Scaffold(
    topBar = {
        CenterAlignedTopAppBar(
            title = {
                Text(
                    "Fish Fresh New England",
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            colors = TopAppBarDefaults.topAppBarColors(
                containerColor = MaterialTheme.colorScheme.primary,
                titleContentColor = MaterialTheme.colorScheme.onPrimary,
            )
        )
    },
    content = { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                "User Setup",
                textAlign = TextAlign.Center,
                style = MaterialTheme.typography.headlineLarge,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.padding(top = 30.dp, bottom = 16.dp)
            )
            UserSetupForm(
                username = uiState.username,
                onUsernameChanged = onUsernameChanged,
                dateOfBirthMillis = uiState.dateOfBirthMillis,
                onBirthDateChanged = onBirthDateChanged,
                launcher = launcher,
                avatarUri = uiState.avatarURI,
                submitUserSetup = submitUserSetup,
                isLoading = uiState.isLoading
            )
            Text(uiState.errorMessage ?: "", color = MaterialTheme.colorScheme.error)


            LaunchedEffect(uiState.createSuccess) {
                if (uiState.createSuccess) {
                    navigateToMain()
                }
            }
        }
    }
    )
}

@Composable
fun UserSetupForm(
    username: String,
    onUsernameChanged: (String) -> Unit,
    dateOfBirthMillis : Long?,
    onBirthDateChanged: (Long) -> Unit = {},
    launcher : ManagedActivityResultLauncher<PickVisualMediaRequest, Uri?>,
    avatarUri : Uri?,
    submitUserSetup: () -> Unit = {},
    isLoading: Boolean,
) {
    Column (
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        OutlinedTextField(
            value = username,
            onValueChange = onUsernameChanged,
            label = { Text("Username") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )
        DatePickerFieldToModal(
            modifier = Modifier.padding(top = 16.dp),
            selectedDateMillis = dateOfBirthMillis,
            onDateSelected = { millis ->
                if (millis != null) onBirthDateChanged(millis)
            }
        )
        Button(onClick = {
            launcher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
        }) {
            Icon(
                Icons.Default.AddAPhoto,
                contentDescription = "Select profile picture",

                )
            Text(if (avatarUri == null) "Select Profile Picture" else "Change Profile Picture")

        }

        Button(
            onClick = submitUserSetup,
            modifier = Modifier.padding(top = 32.dp),
            enabled = username.isNotBlank() && dateOfBirthMillis != null && !isLoading
        ) {
            Text(if (isLoading) "Submitting..." else "Submit")
        }
    }

}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DatePickerFieldToModal(
    modifier: Modifier = Modifier,
    selectedDateMillis: Long?,
    onDateSelected: (Long?) -> Unit
) {
    var showModal by remember { mutableStateOf(false) }
    val focusManager = LocalFocusManager.current

    Box(modifier = modifier.fillMaxWidth()) {
        OutlinedTextField(
            value = selectedDateMillis?.let { convertMillisToDateString(it) } ?: "",
            onValueChange = {  },
            label = { Text("Date of Birth") },
            placeholder = { Text("MM/DD/YYYY") },
            readOnly = true,
            modifier = Modifier.fillMaxWidth(),
            trailingIcon = {
                Icon(Icons.Default.DateRange, contentDescription = "Select date")
            }
        )
        Box(
            modifier = Modifier
                .matchParentSize()
                .clickable {
                    focusManager.clearFocus()
                    showModal = true
                }
        )
    }

    if (showModal) {
        DatePickerModal(
            initialDateMillis = selectedDateMillis,
            onDateSelected = {date ->
                onDateSelected(date)
                showModal = false
            },
            onDismiss = { showModal = false }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DatePickerModal(
    initialDateMillis: Long?,
    onDateSelected: (Long?) -> Unit,
    onDismiss: () -> Unit
) {

    val datePickerState = rememberDatePickerState(
        initialSelectedDateMillis = initialDateMillis,
        initialDisplayMode = DisplayMode.Input
    )

    DatePickerDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            TextButton(onClick = {
                onDateSelected(datePickerState.selectedDateMillis)
                onDismiss()
            }) {
                Text("OK")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    ) {
        DatePicker(state = datePickerState)
    }
}


