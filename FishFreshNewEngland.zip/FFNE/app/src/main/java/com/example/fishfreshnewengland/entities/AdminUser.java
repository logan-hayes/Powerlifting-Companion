package com.example.fishfreshnewengland.entities;

/**
 * @author Ashton Gabbeitt
 */
import java.util.Date;

public class AdminUser extends StandardUser {

    public AdminUser(String username) {
        super(username);
    }

    public boolean deleteUserAccount(StandardUser target){
        //TODO: delete user account from database
        return true;
    }

    public boolean markUserInactive(StandardUser target){
        //TODO: change user status to inactive in database
        return true;
    }

    public boolean markUserActive(StandardUser target){
        //TODO: change user status to active in database
        return true;
    }
}
