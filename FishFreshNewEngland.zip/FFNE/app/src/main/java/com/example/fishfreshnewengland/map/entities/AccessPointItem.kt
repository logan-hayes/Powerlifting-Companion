package com.example.fishfreshnewengland.map.entities

/**
 * @author Ashton Gabbeitt
 */
import com.example.fishfreshnewengland.internal.entities.AccessPoints
import com.google.android.gms.maps.model.LatLng
import com.google.maps.android.clustering.ClusterItem

data class AccessPointItem (
    val item: AccessPoints
) : ClusterItem {
    override fun getPosition(): LatLng = LatLng(item.latitude, item.longitude)

    override fun getTitle(): String = item.name

    override fun getSnippet(): String = item.name

    override fun getZIndex(): Float? = null
}