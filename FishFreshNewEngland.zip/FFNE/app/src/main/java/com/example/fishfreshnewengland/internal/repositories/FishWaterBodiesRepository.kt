package com.example.fishfreshnewengland.internal.repositories


import com.example.fishfreshnewengland.internal.entities.FishWaterBodies
import com.example.fishfreshnewengland.internal.Dao.FishWaterBodiesDao
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import javax.inject.Inject

class FishWaterBodiesRepository @Inject constructor(
    private val fishWaterBodiesDao : FishWaterBodiesDao,
)

{
    suspend fun fetchFishForWaterBody(waterbodyID: Int): List<FishWaterBodies>? {
        return withContext(Dispatchers.IO) {
            fishWaterBodiesDao.getFishForWaterBody(waterbodyID)
        }
    }
}