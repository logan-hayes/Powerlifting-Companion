package com.example.fishfreshnewengland.models

/**
 * @author Ashton Gabbeitt
 */

import android.net.Uri
import androidx.compose.runtime.Immutable
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.fishfreshnewengland.external.AuthRepository
import com.example.fishfreshnewengland.external.DatabaseRepository
import com.example.fishfreshnewengland.external.StorageRepository
import com.example.fishfreshnewengland.external.entities.UserSetup
import com.example.fishfreshnewengland.processors.UriConverter
import com.example.fishfreshnewengland.processors.convertMillisToDBDate
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlin.uuid.Uuid
import javax.inject.Inject
import kotlin.uuid.ExperimentalUuidApi


@Immutable
data class UserSetupUIState(
    val username : String = "",
    val dateOfBirthMillis : Long? = null,
    val dateOfBirth : String? = null,
    val isLoading : Boolean = false,
    val usernameValidated : Boolean = false,
    val formReady : Boolean = false,
    val errorMessage : String? = null,
    val avatarURI : Uri? = null,
    val avatarUploaded : Boolean = false,
    val avatarPath : String? = null,
    val createSuccess : Boolean = false
)

@HiltViewModel
class UserSetupViewModel @Inject constructor(
    private val databaseRepository: DatabaseRepository,
    private val storageRepository: StorageRepository,
    private val authRepository: AuthRepository,
    private val uriConverter: UriConverter
) : ViewModel() {
    private var _uiState = MutableStateFlow(UserSetupUIState())
    val uiState = _uiState.asStateFlow()


    fun onUsernameChanged(usernameChange: String) {
        _uiState.update {
            it.copy(
                username = usernameChange,
                formReady = usernameChange.isNotBlank() && it.dateOfBirth != null
            )
        }

        checkUsernameAvailable()
    }

    fun onBirthDateChanged(dateChange: Long) {

        val convertedDate = convertMillisToDBDate(dateChange)

        _uiState.update {
            it.copy(
                dateOfBirth = convertedDate,
                dateOfBirthMillis = dateChange,
                formReady = convertedDate.isNotBlank() && it.username.isNotBlank()
            )
        }
    }

    fun onAvatarChanged(uri: Uri) {
        _uiState.update {
            it.copy(
                avatarURI = uri
            )
        }
    }

    fun checkUsernameAvailable(){
        viewModelScope.launch {
            try {
                val result = databaseRepository.usernameValidator(_uiState.value.username)
                if (result.isSuccess) {
                    _uiState.value = _uiState.value.copy(usernameValidated = true, errorMessage = null)
            }
                else {
                    _uiState.value = _uiState.value.copy(usernameValidated = false, errorMessage = "Username taken, please choose another.")
                }
                }
            catch (e: Exception) {
                _uiState.value = _uiState.value.copy(usernameValidated = false, errorMessage = "Issue validating username, please try again.")
            }
        }

    }

    suspend fun uploadAvatar(uri: Uri) {
        try {
            val bytes = uriConverter.getBytesFromUri(uri)

            if (bytes == null) {
                _uiState.update {
                    it.copy(
                        errorMessage = "Issue converting image to bytes, please try again.",
                        isLoading = false
                    )

                }

            }
            else {

                val path = "${authRepository.getCurrentUserId()}"
                val avatarURL = storageRepository.uploadAvatar(path, bytes)

                if (avatarURL.isSuccess) {
                    _uiState.update {
                        it.copy(
                            avatarUploaded = true,
                            avatarPath = avatarURL.getOrNull(),
                            errorMessage = null
                        )
                    }
                } else {
                    _uiState.update {
                        it.copy(
                            errorMessage = "Issue uploading avatar, please try again. ${avatarURL.exceptionOrNull()}",
                            isLoading = false,
                            createSuccess = false
                        )
                    }
                }
            }
        } catch (e: Exception) {
            _uiState.update {
                it.copy(
                    errorMessage = e.localizedMessage,
                    isLoading = false,
                    createSuccess = false
                )
            }

        }
    }

    @OptIn(ExperimentalUuidApi::class)
    fun submitUserSetup() {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, errorMessage = null) }

            val avatarURI = _uiState.value.avatarURI
            if(avatarURI != null) {
                uploadAvatar(avatarURI)
            }
                    val userID = authRepository.getCurrentUserId()
                    val dob = _uiState.value.dateOfBirth

                    if (userID != null && dob != null) {

                        val parsedUuid = Uuid.parse(userID)

                        val user = UserSetup(
                            parsedUuid,
                            _uiState.value.username,
                            dob,
                            _uiState.value.avatarPath
                        )
                        val result = databaseRepository.submitUserSetup(user)

                        if(result.isSuccess) {
                            _uiState.update {
                                it.copy(
                                    isLoading = false,
                                    errorMessage = null,
                                    createSuccess = true
                                )
                            }
                        }
                        else {
                            _uiState.update {
                                it.copy(
                                    isLoading = false,
                                    errorMessage = "Issue submitting user setup, please try again. Error Code: 2",
                                    createSuccess = false
                                )
                            }
                        }
                    }
                    else {
                        _uiState.update {
                            it.copy(
                                isLoading = false,
                                errorMessage = "Issue submitting user setup, please try again. Error Code: 1",
                                createSuccess = false
                            )
                        }
                }
            }
        }

    }


