package com.example.fishfreshnewengland.internal;

/**
 * @author Ashton Gabbeitt
 */
import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

import com.example.fishfreshnewengland.internal.entities.AccessPoints;
import com.example.fishfreshnewengland.internal.entities.Counties;
import com.example.fishfreshnewengland.internal.entities.Fish;
import com.example.fishfreshnewengland.internal.entities.FishWaterBodies;
import com.example.fishfreshnewengland.internal.entities.States;
import com.example.fishfreshnewengland.internal.entities.Towns;
import com.example.fishfreshnewengland.internal.entities.UserUISettings;
import com.example.fishfreshnewengland.internal.entities.WaterBodies;
import com.example.fishfreshnewengland.internal.Dao.AccessPointDao;
import com.example.fishfreshnewengland.internal.Dao.CountyDao;
import com.example.fishfreshnewengland.internal.Dao.FishDao;
import com.example.fishfreshnewengland.internal.Dao.FishWaterBodiesDao;
import com.example.fishfreshnewengland.internal.Dao.StateDao;
import com.example.fishfreshnewengland.internal.Dao.TownDao;
import com.example.fishfreshnewengland.internal.Dao.UserUISettingsDao;
import com.example.fishfreshnewengland.internal.Dao.WaterBodyDao;

@Database(entities = {States.class, Counties.class, Towns.class, WaterBodies.class, AccessPoints.class, Fish.class, FishWaterBodies.class, UserUISettings.class}, version = 4)
public abstract class AppDatabase extends RoomDatabase {

    private static volatile AppDatabase INSTANCE;

    public abstract StateDao stateDao();
    public abstract CountyDao countyDao();
    public abstract TownDao townDao();
    public abstract WaterBodyDao waterBodyDao();
    public abstract AccessPointDao accessPointDao();

    public abstract FishDao fishDao();
    public abstract FishWaterBodiesDao fishWaterBodiesDao();

    public abstract UserUISettingsDao userUISettingsDao();



    public static AppDatabase getInstance(final Context context) {
        if (INSTANCE == null) {
            synchronized (AppDatabase.class) {
                if (INSTANCE == null) {
                    INSTANCE = Room.databaseBuilder(context.getApplicationContext(), AppDatabase.class, "app_database.db")
                            .createFromAsset("database/FFNE_Client.db")
                            .build();
                }
            }
        }
        return INSTANCE;
    }
}
