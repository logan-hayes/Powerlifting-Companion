package com.example.fishfreshnewengland.internal.entities;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.Index;
import androidx.room.PrimaryKey;

@Entity(
        tableName = "waterbodies",
        foreignKeys = @ForeignKey(
                entity = Towns.class,
                parentColumns = "id",
                childColumns = "townID"

        ),
        indices = {@Index("id")}
)
public class WaterBodies {


    @PrimaryKey(autoGenerate = true)
    @NonNull
    public Integer id;

    @NonNull
    public String name;


    public Integer townID;
    public Integer max_depth;
    public Integer surface_area;

    public WaterBodies(@NonNull Integer id, @NonNull String name, Integer townID, Integer max_depth, Integer surface_area) {
        this.id = id;
        this.name = name;
        this.townID = townID;
        this.max_depth = max_depth;
        this.surface_area = surface_area;
    }
}