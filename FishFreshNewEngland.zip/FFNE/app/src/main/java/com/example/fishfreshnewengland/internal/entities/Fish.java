package com.example.fishfreshnewengland.internal.entities;

/**
 * @author Ashton Gabbeitt
 */
import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "fish")
public class Fish {

    @PrimaryKey(autoGenerate = true)
    @NonNull
    public Integer id;
    @NonNull
    public String species;

    @ColumnInfo(name = "avg_length_min_in")
    public Float avgLengthMin;

    @ColumnInfo(name = "avg_length_max_in")
    public Float avgLengthMax;

    @ColumnInfo(name = "avg_weight_min_lb")
    public Float avgWeightMin;

    @ColumnInfo(name = "avg_weight_max_lb")
    public Float avgWeightMax;

    public Fish(@NonNull Integer id, @NonNull String species, Float avgLengthMin, Float avgLengthMax, Float avgWeightMin, Float avgWeightMax) {
        this.id = id;
        this.species = species;
        this.avgLengthMin = avgLengthMin;
        this.avgLengthMax = avgLengthMax;
        this.avgWeightMin = avgWeightMin;
        this.avgWeightMax = avgWeightMax;

    }


}


