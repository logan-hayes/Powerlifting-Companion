package com.example.fishfreshnewengland.internal.Dao;

import androidx.room.Dao;
import androidx.room.Query;
import com.example.fishfreshnewengland.internal.entities.FishWaterBodies;
import java.util.List;

@Dao
public interface FishWaterBodiesDao {

    @Query("SELECT * FROM fish_waterbodies WHERE waterbodyID = :id")
    List<FishWaterBodies> getFishForWaterBody(int id);

}
