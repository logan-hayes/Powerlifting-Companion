package com.example.fishfreshnewengland.external.entities

import com.example.fishfreshnewengland.entities.CatchInfo
import com.example.fishfreshnewengland.entities.PostLocation
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class ForumPostCreation(
    @SerialName("user_id")
    val userId: String,
    val content: String,
    @SerialName("content_image")
    val contentImage: String? = null,
    @SerialName("location_id")
    val locationId: Int? = null,
)
