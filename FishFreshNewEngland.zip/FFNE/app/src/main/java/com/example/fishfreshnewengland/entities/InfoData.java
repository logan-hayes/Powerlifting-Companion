package com.example.fishfreshnewengland.entities;

/**
 * @author Ashton Gabbeitt
 */
import com.google.gson.annotations.SerializedName;

public abstract class InfoData {

    @SerializedName("id")
    private int id;

    @SerializedName("name")
    private String name;


    //empty constructor for JSON deserialization
    public InfoData() {}
    public InfoData(int id, String name) {
        this.id = id;
        this.name = name;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

}
