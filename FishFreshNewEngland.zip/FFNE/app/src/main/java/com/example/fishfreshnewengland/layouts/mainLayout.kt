package com.example.fishfreshnewengland.layouts

/**
 * @author Ashton Gabbeitt
 */
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import coil3.compose.AsyncImage
import coil3.request.ImageRequest
import coil3.request.crossfade
import coil3.request.error
import coil3.request.fallback
import coil3.request.placeholder
import com.example.fishfreshnewengland.R
import com.example.fishfreshnewengland.models.MainLayoutUIState
import com.example.fishfreshnewengland.navigation.AppRoute
import com.example.fishfreshnewengland.navigation.ForumFeedRoute
import com.example.fishfreshnewengland.navigation.InfoCatalogMainRoute
import com.example.fishfreshnewengland.navigation.MapScreenRoute
import com.example.fishfreshnewengland.navigation.UploadPicRoute
import com.example.fishfreshnewengland.navigation.UserSettingsRoute
import com.example.fishfreshnewengland.navigation.UserSetupRoute
import kotlinx.coroutines.launch
import kotlinx.serialization.ExperimentalSerializationApi



/**
 * Definition of values for menu items.
 */
@OptIn(ExperimentalSerializationApi::class)
val menuItems = mapOf<String, AppRoute>("Fish Map" to MapScreenRoute, "Info Catalog" to InfoCatalogMainRoute, "Forum Feed" to ForumFeedRoute,  "Upload Profile Pic" to UploadPicRoute)

/**
 * Main Layout
 * @param navController: NavController for navigation
 */
@ExperimentalMaterial3Api
@Composable
fun MainLayoutContent(
    username : String?,
    error : String?,
    profilePicURL : String?,
    uiState : MainLayoutUIState,
    onNavigateToSignIn : () -> Unit,
    onNavigateToRoute : (route: AppRoute) -> Unit,
    signOut : () -> Unit,
) {

    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val scope = rememberCoroutineScope()



    LaunchedEffect(uiState.signedIn) {
        if (!uiState.signedIn) {
            onNavigateToSignIn()
        }
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet(

            ) {
                Column(
                    modifier = Modifier.padding(horizontal = 16.dp)
                ){
                    Spacer(Modifier.height(12.dp))
                    AsyncImage(
                            model = ImageRequest.Builder(LocalContext.current)
                                .data(profilePicURL)
                                .crossfade(true)

                                .fallback(R.drawable.ic_default_avatar)

                                .error(R.drawable.ic_error_image)

                                .placeholder(R.drawable.ic_placeholder_image)
                                .build(),
                            contentDescription = "Profile Picture",
                            modifier = Modifier
                                .padding(start = 8.dp)
                                .size(64.dp)
                                .clip(CircleShape),
                            contentScale = androidx.compose.ui.layout.ContentScale.Crop
                    )

                    Text(username ?: error ?: "", modifier = Modifier.padding(16.dp), style = MaterialTheme.typography.titleLarge)
                    HorizontalDivider()
                    NavigationDrawerItem(
                        label = { Text("User Settings") },
                        selected = false,
                        onClick = {
                            scope.launch { drawerState.close() }

                            onNavigateToRoute(UserSettingsRoute) }
                    )
                    NavigationDrawerItem(
                        label = { Text("User Setup") },
                        selected = false,
                        onClick = {
                            scope.launch { drawerState.close() }

                            onNavigateToRoute(UserSetupRoute) }
                    )
                    NavigationDrawerItem(
                        label = { Text("Sign Out") },
                        selected = false,
                        onClick = {

                            scope.launch { drawerState.close() }

                            signOut()}
                    )


                }



            }
        }
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Text(
                            "Fish Fresh New England"
                        )
                    },
                    navigationIcon = {
                        IconButton(
                            onClick = { scope.launch {
                                drawerState.apply{
                                    if (isClosed) open() else close()
                                }
                            } }) {
                            Icon(
                                imageVector = Icons.Filled.Menu,
                                contentDescription = "Localized description"
                            )
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.primary,
                        titleContentColor = MaterialTheme.colorScheme.onPrimary,
                        navigationIconContentColor = MaterialTheme.colorScheme.onPrimary

                    )
                )
            }
        )
        { innerPadding ->

            if (!uiState.isLoading && uiState.signedIn) {

                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding),
                    contentAlignment = Alignment.Center
                ) {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        items(menuItems.entries.toList()) { (label, route) ->
                            Button(onClick = {
                                onNavigateToRoute(route)
                            }) {
                                Text(label)
                            }

                        }


                    }

                }
            } else {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator()
                }
            }

        }
    }
}




