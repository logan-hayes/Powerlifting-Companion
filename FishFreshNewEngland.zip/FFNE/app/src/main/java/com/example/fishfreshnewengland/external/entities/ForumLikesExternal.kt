package com.example.fishfreshnewengland.external.entities

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class ForumLikesExternal(
    @SerialName("user_id")
    val userId: String,
    @SerialName("post_id")
    val postId: Long
)
