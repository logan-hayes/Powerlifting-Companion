package com.example.fishfreshnewengland.external

/**
 * @author Ashton Gabbeitt
 */

import io.github.jan.supabase.SupabaseClient
import io.github.jan.supabase.storage.Storage
import io.github.jan.supabase.storage.storage
import io.ktor.http.ContentType
import javax.inject.Inject

class StorageRepositoryImpl @Inject constructor(
    private val storage : Storage
) : StorageRepository {

    val profileAvatarBucket = "FFNE_Avatars"
    val postImageBucket = "FFNE_Post_Images"

    override suspend fun getAvatarURL(path: String): Result<String> {

        return try {
            val url = storage[profileAvatarBucket].publicUrl(path)
            Result.success(url)

        } catch (e: Exception) {
            Result.failure(Exception("URL Exception : ${e.localizedMessage}"))
        }
    }

    override suspend fun uploadAvatar(path: String, file: ByteArray?): Result<String> {
        if (file != null) {
            return try {
                val response = storage[profileAvatarBucket].upload(path, file) {
                    contentType = ContentType("image", "jpeg")
                    upsert = true
                }
                val key = response.path

                Result.success(key)

            } catch (e: Exception) {
                 Result.failure(Exception("Upload exception $e"))
            }
        } else {
             return Result.failure(Exception("File null"))
        }
    }

    override suspend fun deleteAvatar(path: String): Boolean {
        return try {
            storage[profileAvatarBucket].delete(path)
            true
    }
        catch (e: Exception) {
            false
        }
    }
}

