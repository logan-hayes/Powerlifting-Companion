package com.example.fishfreshnewengland.navigation

/**
 * @author Ashton Gabbeitt
 */
import android.os.Bundle
import androidx.navigation.NavType


/**
 * Custom navigation type for double values.
 */
val DoubleNavType = object : NavType<Double>(isNullableAllowed = false) {
    override fun get(bundle: Bundle, key: String): Double? = bundle.getDouble(key)
    override fun put(bundle: Bundle, key: String, value: Double) = bundle.putDouble(key, value)
    override fun parseValue(value: String): Double = value.toDouble()
    override fun serializeAsValue(value: Double): String = value.toString()
}