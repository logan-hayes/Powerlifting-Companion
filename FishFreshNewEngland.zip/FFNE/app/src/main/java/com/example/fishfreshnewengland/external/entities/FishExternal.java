package com.example.fishfreshnewengland.external.entities;

/**
 * @author Ashton Gabbeitt
 */
import com.google.gson.annotations.SerializedName;


public class FishExternal  {

    @SerializedName("species")
    private String species;
    @SerializedName("avg_length_min")
    private float avgLengthMin;
    @SerializedName("avg_length_max")
    private float avgLengthMax;
    @SerializedName("avg_weight_min")
    private float avgWeightMin;
    @SerializedName("avg_weight_max")
    private float avgWeightMax;
    @SerializedName("rating_points")
    private int ratingPoints;
    @SerializedName("rating_count")
    private int ratingCount;

    //empty constructor for JSON deserialization
    public FishExternal() {}

    public FishExternal(int id, String name, String species, float avgLengthMin, float avgLengthMax, float avgWeightMin, float avgWeightMax, int ratingPoints, int ratingCount) {
        this.species = species;
        this.avgLengthMin = avgLengthMin;
        this.avgLengthMax = avgLengthMax;
        this.avgWeightMin = avgWeightMin;
        this.avgWeightMax = avgWeightMax;
        this.ratingPoints = ratingPoints;
        this.ratingCount = ratingCount;
    }

    public int getRatingCount() {
        return ratingCount;
    }

    public void setRatingCount(int ratingCount) {
        this.ratingCount = ratingCount;
    }

    public int getRatingPoints() {
        return ratingPoints;
    }

    public void setRatingPoints(int ratingPoints) {
        this.ratingPoints = ratingPoints;
    }

    public float getAvgWeightMax() {
        return avgWeightMax;
    }

    public void setAvgWeightMax(float avgWeightMax) {
        this.avgWeightMax = avgWeightMax;
    }

    public float getAvgWeightMin() {
        return avgWeightMin;
    }

    public void setAvgWeightMin(float avgWeightMin) {
        this.avgWeightMin = avgWeightMin;
    }

    public float getAvgLengthMax() {
        return avgLengthMax;
    }

    public void setAvgLengthMax(float avgLengthMax) {
        this.avgLengthMax = avgLengthMax;
    }

    public float getAvgLengthMin() {
        return avgLengthMin;
    }

    public void setAvgLengthMin(float avgLengthMin) {
        this.avgLengthMin = avgLengthMin;
    }

    public String getSpecies() {
        return species;
    }

    public void setSpecies(String species) {
        this.species = species;
    }
}
