package com.example.fishfreshnewengland.internal.Dao;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import com.example.fishfreshnewengland.internal.entities.UserUISettings;

@Dao
public interface UserUISettingsDao {

    @Query("SELECT * FROM user_ui_settings LIMIT 1")
    UserUISettings getSettings();

    @Insert
    void insert(UserUISettings settings);

    @Update
    void update(UserUISettings settings);
}