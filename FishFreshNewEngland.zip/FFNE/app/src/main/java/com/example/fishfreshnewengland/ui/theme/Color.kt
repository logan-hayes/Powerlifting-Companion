package com.example.fishfreshnewengland.ui.theme

/**
 * @author Ashton Gabbeitt
 */
import androidx.compose.ui.graphics.Color

val white = Color(0xFFFFFFFF)
val black = Color(0xFF000000)
val baseBlue = Color(0xFF0076D6)
val baseBlueDark = Color(0xFF014F8F)
val baseBlueLight = Color(0xFF058DFC)

val error = Color.Red