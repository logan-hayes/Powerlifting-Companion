package com.example.fishfreshnewengland.entities;
/**
 * @author Ashton Gabbeitt
 */
public enum BADGETYPE {
    BRONZE,
    SILVER,
    GOLD
}
