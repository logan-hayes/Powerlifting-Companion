package com.example.fishfreshnewengland.internal.Dao;

import androidx.room.Dao;
import androidx.room.Query;

import com.example.fishfreshnewengland.internal.entities.AccessPoints;

import java.util.List;

@Dao
public interface AccessPointDao {

    @Query("SELECT * FROM accesses WHERE waterbodyID = :id")
    List<AccessPoints> getAllByWaterBody(int id);

    @Query("SELECT * FROM accesses")
    List<AccessPoints> getAllAccessPoints();
 }