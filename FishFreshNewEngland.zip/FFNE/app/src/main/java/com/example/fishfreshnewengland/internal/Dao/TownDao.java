package com.example.fishfreshnewengland.internal.Dao;

import androidx.room.Dao;
import androidx.room.Query;


import com.example.fishfreshnewengland.internal.entities.Towns;

import java.util.List;

@Dao
public interface TownDao {

    @Query("SELECT * FROM towns")
    List<Towns> getAll();

    @Query("SELECT * FROM towns WHERE countyID = :id")
    List<Towns> getAllByCounty(int id);

    @Query("SELECT * FROM towns WHERE id = :id")
    Towns getById(int id);

}