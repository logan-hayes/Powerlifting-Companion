package com.example.fishfreshnewengland.internal.repositories


import com.example.fishfreshnewengland.internal.entities.States
import com.example.fishfreshnewengland.internal.Dao.StateDao
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import javax.inject.Inject


/**
 * Repository for fetching states from the database
 */
class StateRepository @Inject constructor(
    private val stateDao : StateDao,
) {
    suspend fun fetchAllStates(): List<States> {
        return withContext(Dispatchers.IO) {
            stateDao.getAll()
        }
    }

    suspend fun fetchStateByID(id: Int): States? {
        return withContext(Dispatchers.IO) {
            stateDao.getById(id)
        }
    }
}