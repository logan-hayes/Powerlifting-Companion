package com.example.fishfreshnewengland.entities

import kotlinx.serialization.Serializable

/**
 * @author Logan Hayes
 */
//Helper class for holding water body location related data for use in forum post creation
@Serializable
class PostLocation {
    var waterBodyID: Int? = null
    var locationName: String? = null
    var latitude: Double? = null
    var longitude: Double? = null

    constructor()

    constructor(
        waterBodyID: Int?,
        locationName: String?,
        latitude: Double?,
        longitude: Double?
    ) {
        this.waterBodyID = waterBodyID
        this.locationName = locationName
        this.latitude = latitude
        this.longitude = longitude
    }
}