package com.example.fishfreshnewengland.entities;
/**
 * @author Ashton Gabbeitt
 */
import com.example.fishfreshnewengland.external.entities.UserProfileSettings;
import com.example.fishfreshnewengland.internal.entities.UserUISettings;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

abstract class User {

    private final String userID; //id for user, same as Supabase auth user id
    private String username; //handle for user
    private Date birthDate; //user birth date
    private String profilePicture; // link to user profile pic -- stored in Supabase
    private LocalDateTime createdDateTime;
    private LocalDateTime modifiedDateTime;
    private List<Badge> userBadges;
    private UserProfileSettings profileSettings;
    private UserUISettings uiSettings;
    private PROFILESTATUS status; //user profile status


    public User(String userID) {
        this.userID = userID;
        this.username = null;
        this.birthDate = null;
        this.createdDateTime = null;
        this.profilePicture = null;
        this.userBadges = new ArrayList<>();
        this.profileSettings = new UserProfileSettings();
        this.uiSettings = new UserUISettings();
        this.status = PROFILESTATUS.ACTIVE;
    }

    public String getUserID() {
        return userID;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public Date getBirthDate() {
        return birthDate;
    }

    public void setBirthDate(Date birthDate) {
        this.birthDate = birthDate;
    }

    public String getProfilePicture() {
        return profilePicture;
    }

    public void setProfilePicture(String profilePicture) {
        this.profilePicture = profilePicture;
    }

    public LocalDateTime getCreatedDateTime() {
        return createdDateTime;
    }

    public void setCreatedDateTime(LocalDateTime createdDateTime) {
        this.createdDateTime = createdDateTime;
    }

    public LocalDateTime getModifiedDateTime() {
        return modifiedDateTime;
    }

    public void setModifiedDateTime(LocalDateTime modifiedDateTime) {
        this.modifiedDateTime = modifiedDateTime;
    }

    public List<Badge> getUserBadges() {
        return userBadges;
    }

    public void setUserBadges(List<Badge> userBadges) {
        this.userBadges = userBadges;
    }

    public UserProfileSettings getProfileSettings() {
        return profileSettings;
    }

    public void setProfileSettings(UserProfileSettings profileSettings) {
        this.profileSettings = profileSettings;
    }

    public UserUISettings getUiSettings() {
        return uiSettings;
    }

    public void setUiSettings(UserUISettings uiSettings) {
        this.uiSettings = uiSettings;
    }

    public PROFILESTATUS getStatus() {
        return status;
    }

    public void setStatus(PROFILESTATUS status) {
        this.status = status;
    }
}
