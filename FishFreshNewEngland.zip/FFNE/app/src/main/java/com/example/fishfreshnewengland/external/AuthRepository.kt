package com.example.fishfreshnewengland.external
/**
 * @author Ashton Gabbeitt
 */

import io.github.jan.supabase.auth.status.SessionStatus
import io.github.jan.supabase.auth.user.UserInfo
import kotlinx.coroutines.flow.Flow

interface AuthRepository {
    val sessionStatus: Flow<SessionStatus>
    suspend fun handleDeeplink(url: String): Boolean
    suspend fun signIn(email: String, password: String): SignInProcessing
    suspend fun signUp(email: String, password: String): Result<UserInfo>
    suspend fun resendEmailConfirmation(email: String) : Boolean
    suspend fun signOut()
    suspend fun sendResetPasswordEmail(email: String): ResetPasswordProcessing
    suspend fun submitPasswordUpdate(newPassword: String): Boolean
    fun getCurrentUserId(): String?
}



