package com.example.fishfreshnewengland.security
import android.util.Base64
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec
// This class holds and starts the authentication process //
// Contents will include things like username, password, authentication tokens etc etc // ]

class Creds {
    data class UserCredentials(
        val userId: String,
        val passwordHash: String,
        val salt: String
    ) {
        companion object {
            private const val ITERATIONS = 100_000
            private const val KEY_LENGTH = 256 // bits
            private const val ALGORITHM = "PBKDF2WithHmacSHA256"
            private val secureRandom = SecureRandom()

            /** Generate a new random salt (Base64) */
            fun generateSalt(lengthBytes: Int = 16): String {
                val salt = ByteArray(lengthBytes)
                secureRandom.nextBytes(salt)
                return Base64.encodeToString(salt, Base64.NO_WRAP)
            }

            /** Hash a plain password with the provided Base64 salt and return Base64 hash */
            fun hashPassword(password: CharArray, base64Salt: String): String {
                val salt = Base64.decode(base64Salt, Base64.NO_WRAP)
                val spec = PBEKeySpec(password, salt, ITERATIONS, KEY_LENGTH)
                val skf = SecretKeyFactory.getInstance(ALGORITHM)
                val key = skf.generateSecret(spec).encoded
                spec.clearPassword()
                return Base64.encodeToString(key, Base64.NO_WRAP)
            }

            /** Create credentials from a plain password  */
            fun create(userId: String, password: CharArray): UserCredentials {
                val salt = generateSalt()
                val hash = hashPassword(password, salt)
                // Clear password array caller-side when possible
                return UserCredentials(userId = userId, passwordHash = hash, salt = salt)
            }
        }

        /** Validate a plain password against stored hash and salt */
        fun validate(password: CharArray): Boolean {
            val computed = Companion.hashPassword(password, salt)
            // Constant-time comparison to reduce timing attack surface
            return constantTimeEquals(Base64.decode(passwordHash, Base64.NO_WRAP), Base64.decode(computed, Base64.NO_WRAP))
        }

        private fun constantTimeEquals(a: ByteArray, b: ByteArray): Boolean {
            if (a.size != b.size) return false
            var result = 0
            for (i in a.indices) {
                result = result or (a[i].toInt() xor b[i].toInt())
            }
            return result == 0
        }
    }
}