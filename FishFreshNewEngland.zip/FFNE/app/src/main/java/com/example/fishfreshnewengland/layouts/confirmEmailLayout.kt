package com.example.fishfreshnewengland.layouts

/**
 * @author Ashton Gabbeitt
 */
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign


/**
 * Confirm Email Layout
 *
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ConfirmEmailLayoutContent(
    navigateToSetup : () -> Unit,
){

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Email Confirmed", textAlign = TextAlign.Center) },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = MaterialTheme.colorScheme.onPrimary,
                    navigationIconContentColor = MaterialTheme.colorScheme.onPrimary
                )
            )
        },
        content = { innerPadding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {

                Text("Email confirmed!", fontSize = MaterialTheme.typography.headlineLarge.fontSize)
                Button(
                    onClick = { navigateToSetup() },

                    ) {
                    Text("Setup User Profile")
                }
            }
        }

    )
}