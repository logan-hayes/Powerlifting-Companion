package com.example.fishfreshnewengland.internal.entities;

/**
 * @author Ashton Gabbeitt
 */
import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.PrimaryKey;


/**
 * Entity for states
 */
@Entity(tableName = "states")
public class States {
    @PrimaryKey(autoGenerate = true)
    @NonNull
    public Integer id;
    @NonNull
    public String name;
    @NonNull
    public String abbr;

    public States(@NonNull Integer id, @NonNull String name, @NonNull String abbr) {
        this.id = id;
        this.name = name;
        this.abbr = abbr;
    }
}
